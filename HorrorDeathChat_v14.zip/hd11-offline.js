/* ============================================================
   HD Chat v11 — العمل بلا إنترنت: شريط الحالة، فاحص الجاهزية،
   صور بديلة، وإعادة الاتصال تلقائياً عند عودة الشبكة.
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, section, button } = HD;
    const NEED = [
        ['https://cdn.tailwindcss.com', 'التنسيق (Tailwind)'], ['https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', 'الأيقونات (Font Awesome)'],
        ['https://fonts.googleapis.com/css2?family=Amiri:ital@1&family=Courier+Prime&family=Cinzel+Decorative:wght@700;900&display=swap', 'الخطوط'], ['https://unpkg.com/peerjs@1.5.2/dist/peerjs.min.js', 'مكتبة الاتصال (PeerJS)'],
        ['index.html', 'صفحة الموقع'], ['app.js?v=14', 'برنامج الموقع'], ['assets/music/endless-darkness.mp3', 'الموسيقى']
    ];
    async function status() {
        const out = []; for (const [u, label] of NEED) { let ok = false; try { ok = !!(await caches.match(u)); } catch (e) {} out.push({ u, label, ok }); }
        let fonts = 0; try { const c = await caches.open('hdc-cdn-v1'); fonts = (await c.keys()).filter((r) => /fonts\.gstatic|webfonts|\.woff2/.test(r.url)).length; } catch (e) {}
        return { items: out, fonts, ready: out.every((x) => x.ok) };
    }
    HD.offline = { status };

    /* ── شريط «بلا إنترنت» ── */
    function bar() { let b = g('hx11-offbar'); if (!b) { b = el('div', 'hx11-offbar'); b.id = 'hx11-offbar'; b.setAttribute('role', 'status'); b.appendChild(icon('globe', 15)); b.appendChild(el('span', '', '')); document.body.appendChild(b); } return b; }
    function paint() {
        const on = navigator.onLine !== false, b = bar(); b.classList.toggle('show', !on); document.body.classList.toggle('hx11-offline', !on);
        b.lastChild.textContent = ' أنت بلا إنترنت — الموقع يعمل: اقرأ رسائلك المحفوظة وغيّر المظهر والملف الشخصي. سيعود الاتصال بالأصدقاء تلقائياً.';
    }
    function reconnect() {
        try { if (typeof peer !== 'undefined' && peer && !peer.destroyed && (peer.disconnected || !peer.open)) peer.reconnect(); } catch (e) {}
        if (window.Peer && window.Peer.__offlineStub) { note('عاد الإنترنت — جارٍ تحميل مكتبة الاتصال...'); setTimeout(() => location.reload(), 1200); }
    }
    window.addEventListener('offline', () => { paint(); note('انقطع الإنترنت — الموقع يعمل بلا اتصال'); });
    window.addEventListener('online', () => { paint(); note('عاد الإنترنت ✓'); setTimeout(reconnect, 600); setTimeout(reconnect, 4000); });

    /* ── لو لم تُحمَّل مكتبة PeerJS (أول زيارة بلا شبكة): بديل لا يكسر الموقع ── */
    if (typeof window.Peer === 'undefined') {
        const Stub = function () { this._h = {}; this.destroyed = false; this.open = false; this.disconnected = true; this.id = null; setTimeout(() => { (this._h.error || []).forEach((f) => { try { f({ type: 'network', message: 'offline' }); } catch (e) {} }); }, 50); };
        Stub.prototype.on = function (ev, fn) { (this._h[ev] = this._h[ev] || []).push(fn); return this; }; Stub.prototype.reconnect = function () {}; Stub.prototype.destroy = function () { this.destroyed = true; }; Stub.prototype.connect = function () { return { on() {}, send() {}, close() {} }; }; Stub.prototype.call = function () { return { on() {}, close() {} }; };
        Stub.__offlineStub = true; window.Peer = Stub;
    }

    /* ── صور بديلة: أفاتار dicebear المفقود يُستبدل برسمة محلية ── */
    const PICS = ['skull', 'ghost', 'bat', 'owl', 'cat', 'spider'];
    function fallback(seed) {
        let h = 0; for (const c of String(seed)) h = (h * 31 + c.charCodeAt(0)) >>> 0; const name = PICS[h % PICS.length], st = HD.stickers && HD.stickers.ST[name]; if (!st) return null;
        const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-8 -8 80 80"><rect x="-8" y="-8" width="80" height="80" fill="hsl(' + (h % 360) + ',35%,16%)"/>' + st[1] + '</svg>'; return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    }
    document.addEventListener('error', (e) => {
        const t = e.target; if (!t || t.tagName !== 'IMG' || t.dataset.hxfb || !/dicebear\.com/.test(t.src || '')) return; t.dataset.hxfb = '1';
        let seed = 'x'; try { seed = new URL(t.src).searchParams.get('seed') || 'x'; } catch (x) {} const f = fallback(seed); if (f) t.src = f;
    }, true);

    /* ── التخزين الدائم + إشعار الجاهزية ── */
    async function persist() { try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (e) {} }
    let readyNoted = ls.get('hx11_off_ready', '') === '1';
    async function check() { const s = await status(); if (s.ready && !readyNoted) { readyNoted = true; ls.set('hx11_off_ready', '1'); note('الموقع جاهز للعمل بلا إنترنت ✓'); } return s; }
    function askPrecache() { try { navigator.serviceWorker.ready.then((r) => { if (r.active) r.active.postMessage({ type: 'precache' }); }); } catch (e) {} }

    /* ── بطاقة الجاهزية داخل مركز الخيارات ── */
    function panel(b) {
        section(b, 'العمل بلا إنترنت'); const box = el('div'); b.appendChild(box);
        const draw = async () => {
            box.textContent = ''; const s = await status(); const st = el('div', 'hx11-status ' + (s.ready ? 'ok' : 'warn')); st.appendChild(icon(s.ready ? 'check' : 'panic', 20)); const t = el('div');
            t.appendChild(el('b', '', s.ready ? 'الموقع جاهز للعمل بلا إنترنت' : 'الحزمة غير مكتملة بعد')); t.appendChild(el('small', '', s.ready ? 'افتحه في أي وقت دون شبكة. المحادثة المباشرة والمكالمات تحتاج إنترنت.' : 'افتح الموقع مرة وأنت متصل ثم اضغط «تحديث الحزمة».')); st.appendChild(t); box.appendChild(st);
            s.items.forEach((x) => { const r = el('div', 'hx11-row'); r.appendChild(el('span', '', x.label)); r.appendChild(el('span', 'hx11-badge ' + (x.ok ? 'ok' : 'bad'), x.ok ? 'محفوظ ✓' : 'غير محفوظ')); box.appendChild(r); });
            box.appendChild(el('p', 'hx-muted', 'الخطوط المحفوظة: ' + s.fonts + ' ملفاً.'));
            try { if (navigator.storage && navigator.storage.estimate) { const e = await navigator.storage.estimate(); box.appendChild(el('p', 'hx-muted', 'المساحة المستخدمة: ' + Math.round((e.usage || 0) / 1048576) + ' ميغابايت.')); } } catch (e) {}
        };
        draw(); button(b, 'تحديث الحزمة بلا إنترنت', () => { note('جارٍ التحديث...'); askPrecache(); setTimeout(draw, 3500); setTimeout(draw, 9000); }, 'flip');
    }
    HD.offline.panel = panel;
    function init() { paint(); persist(); setTimeout(check, 4000); setTimeout(check, 15000); if (navigator.onLine !== false) setTimeout(askPrecache, 3000); if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', (e) => { if (e.data && e.data.type === 'precache_done') check(); }); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
