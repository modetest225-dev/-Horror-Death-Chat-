/* ============================================================
   HD Chat v11 — إشعارات Push حقيقية (تصل والموقع مغلق)
   - كل جهاز يسجّل «صندوقاً» عشوائياً عند خادم الدفع الخاص بك.
   - تتبادل الأجهزة المتصلة صناديقها عبر القناة المشفّرة فقط.
   - الإيقاظ لا يحمل نص الرسالة: اسم المرسل فقط.
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, sheet, section, row, toggle, button } = HD;
    const K = { cfg: 'hx11_push_cfg', me: 'hx11_push_me', con: 'hx11_push_contacts', auto: 'hx11_push_auto' };
    const jget = (k, d) => { try { const v = JSON.parse(ls.get(k, '')); return v == null ? d : v; } catch (e) { return d; } };
    const jset = (k, v) => ls.set(k, JSON.stringify(v));
    const UB64 = (s) => { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
    const INBOX = /^[A-Za-z0-9_-]{22}$/, DAY = 86400000, THROTTLE = 5 * 60000;
    const keyOf = (n) => String(HD.guard ? HD.guard.cleanName(n) : n).toLowerCase();
    const supported = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
    const me = () => jget(K.me, null);

    function cfg() {
        const w = window.HDC_PUSH_CFG || {}, l = jget(K.cfg, {}); const url = String(w.url || l.url || '').trim().replace(/\/+$/, ''), vapid = String(w.vapid || l.vapid || '').trim();
        return { url, vapid, preset: !!(w.url && w.vapid), ok: /^https:\/\/[^\s/]+(\/[^\s]*)?$/.test(url) && /^[A-Za-z0-9_-]{87}$/.test(vapid) };
    }
    async function api(path, method, body) {
        const c = cfg(); const r = await fetch(c.url + path, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); let j = null; try { j = await r.json(); } catch (e) {} return { status: r.status, j };
    }
    const same = (a, b) => a.length === b.length && a.every((x, i) => x === b[i]);

    async function enable() {
        const c = cfg(); if (!c.ok) throw new Error('config'); if (!supported()) throw new Error('unsupported');
        if (Notification.permission !== 'granted') { const p = await Notification.requestPermission(); if (p !== 'granted') throw new Error('permission'); }
        try { saveSetting('notificationsEnabled', true); } catch (e) {}
        const reg = await navigator.serviceWorker.ready; let sub = await reg.pushManager.getSubscription(); const key = UB64(c.vapid);
        if (sub) { const cur = sub.options && sub.options.applicationServerKey; if (!cur || !same(new Uint8Array(cur), key)) { await sub.unsubscribe(); sub = null; } }
        if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
        const old = me(); if (old && old.inbox) { try { await api('/inbox', 'DELETE', { inbox: old.inbox, token: old.token }); } catch (e) {} }
        const r = await api('/register', 'POST', { sub: sub.toJSON() }); if (!r.j || !r.j.ok) throw new Error('register:' + r.status);
        jset(K.me, { inbox: r.j.inbox, token: r.j.token, t: Date.now() }); resetShare(); return r.j.inbox;
    }
    async function disable() {
        const m = me(); if (m) { try { await api('/inbox', 'DELETE', { inbox: m.inbox, token: m.token }); } catch (e) {} }
        try { const reg = await navigator.serviceWorker.ready; const s = await reg.pushManager.getSubscription(); if (s) await s.unsubscribe(); } catch (e) {} ls.del(K.me);
    }

    /* ── تبادل الصناديق بين المتصلين ── */
    const contacts = () => { const o = jget(K.con, {}), now = Date.now(), mi = (me() || {}).inbox; Object.keys(o).forEach((k) => { if (!o[k] || now - o[k].ts > 60 * DAY || !INBOX.test(o[k].inbox) || o[k].inbox === mi) delete o[k]; }); return o; };
    function resetShare() { try { Object.values(activeConnections).forEach((c) => { if (c.__hd) c.__hd.pushSent = false; }); } catch (e) {} }
    HD.on('pushbox', (p, conn) => {
        if (!p || typeof p.inbox !== 'string' || !INBOX.test(p.inbox)) return; const name = (typeof peerNames !== 'undefined' && peerNames[conn.peer]) || ''; if (!name) return;
        if (HD.guard && HD.guard.isBlocked(name)) return; const mine = me(); if (mine && mine.inbox === p.inbox) return; const k = keyOf(name) + '|' + ((conn.__hd && conn.__hd.idFp) || '-'), all = contacts();
        all[k] = Object.assign({}, all[k], { name, inbox: p.inbox, ts: Date.now() }); const ks = Object.keys(all); if (ks.length > 60) delete all[ks.sort((a, b) => all[a].ts - all[b].ts)[0]]; jset(K.con, all);
    });
    function shareTick() {
        const m = me(); if (!m || !m.inbox) return;
        Object.keys(activeConnections).forEach((pid) => { const c = activeConnections[pid]; if (!c || !c.open || !c.__hd || c.__hd.mode !== 'enc' || c.__hd.pushSent) return; c.__hd.pushSent = true; sendPacket(c, { type: 'pushbox', payload: { inbox: m.inbox } }); });
    }
    const online = (name) => Object.keys(activeConnections).some((pid) => activeConnections[pid] && activeConnections[pid].open && keyOf(peerNames[pid]) === keyOf(name));

    /* ── الإيقاظ ── */
    const lastAuto = {};
    async function notifyContact(key, kind) {
        const all = contacts(), c = all[key]; if (!c) return { ok: false, error: 'no-contact' }; if (!cfg().ok) return { ok: false, error: 'config' };
        let r; try { r = await api('/notify', 'POST', { inbox: c.inbox, kind, from: currentUser.username }); } catch (e) { return { ok: false, error: 'network' }; }
        if (r.j && r.j.gone) { delete all[key]; jset(K.con, all); }
        return r.j || { ok: false, status: r.status };
    }
    function autoNotify() {
        if (!me() || !cfg().ok || ls.get(K.auto, '1') !== '1') return; const all = contacts(), now = Date.now();
        Object.keys(all).forEach((k) => { if (online(all[k].name) || now - (lastAuto[k] || 0) < THROTTLE) return; lastAuto[k] = now; notifyContact(k, 'msg'); });
    }
    const _sb = sendBroadcastMessage;
    sendBroadcastMessage = function () { const i = g('msg-input'), had = !!(i && i.value.trim()); _sb(); if (had && i && i.value === '') autoNotify(); };
    async function test() { const m = me(); if (!m) throw new Error('not-enabled'); const r = await api('/notify', 'POST', { inbox: m.inbox, kind: 'msg', from: 'اختبار الدفع' }); return r.j || { ok: false }; }

    /* ── الواجهة (داخل تبويب الإشعارات) ── */
    const when = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'الآن' : m < 60 ? 'منذ ' + m + ' د' : m < 1440 ? 'منذ ' + Math.round(m / 60) + ' س' : 'منذ ' + Math.round(m / 1440) + ' يوم'; };
    function panel(b) {
        const c = cfg(), m = me(); section(b, 'إشعارات تصل والموقع مغلق (Push)');
        if (!supported()) { b.appendChild(el('p', 'hx-muted', 'هذا المتصفح لا يدعم Push. على iPhone ثبّت الموقع على الشاشة الرئيسية (iOS 16.4 فأعلى).')); return; }
        const st = el('div', 'hx11-status ' + (m ? 'ok' : (c.ok ? 'warn' : 'bad'))); st.appendChild(icon(m ? 'check' : 'panic', 20)); const t = el('div');
        t.appendChild(el('b', '', m ? 'الدفع مفعّل على هذا الجهاز' : c.ok ? 'جاهز للتفعيل' : 'خادم الدفع غير مضبوط')); t.appendChild(el('small', '', m ? 'يصلك إيقاظ من أصدقائك حتى لو أغلقت الموقع.' : c.ok ? 'اضغط تفعيل ثم اسمح بالإشعارات.' : 'انشر مجلد push-server وأدخل عنوانه أدناه (الخطوات في README-ar.md).')); st.appendChild(t); b.appendChild(st);
        if (!c.preset) {
            const l = jget(K.cfg, {}), f = (ph, key) => { const i = el('input', 'hx-input'); i.placeholder = ph; i.dir = 'ltr'; i.value = l[key] || ''; i.autocomplete = 'off'; i.oninput = () => { l[key] = i.value.trim(); jset(K.cfg, l); }; b.appendChild(i); };
            f('https://hd-push.yourname.workers.dev', 'url'); f('المفتاح العام VAPID (87 حرفاً)', 'vapid'); b.appendChild(el('p', 'hx-muted', 'لتعميم الإعداد على كل المستخدمين ضعه في push-config.js مرة واحدة.'));
        }
        if (!m) button(b, 'تفعيل الدفع على هذا الجهاز', async () => { try { await enable(); note('تم تفعيل الدفع'); } catch (e) { note(e.message === 'config' ? 'أكمل إعداد خادم الدفع أولاً' : e.message === 'permission' ? 'لم تسمح بالإشعارات' : 'تعذّر التفعيل: ' + e.message); } const w = g('hx-sheet'); if (w) { w.remove(); HD.hub.open('notif'); } }, 'check');
        else {
            button(b, 'إرسال إشعار دفع تجريبي لنفسي', async () => { try { const r = await test(); note(r.ok ? 'أُرسل — يصلك خلال ثوانٍ' : 'تعذّر: ' + (r.error || r.status || '')); } catch (e) { note('فعّل الدفع أولاً'); } }, 'send');
            row(b, 'إيقاظ أصدقائي عند إرسال رسالة', toggle(ls.get(K.auto, '1') === '1', (v) => ls.set(K.auto, v ? '1' : '0')), 'ينبّه مرة كل 5 دقائق لمن غادر؛ بلا نص الرسالة.');
            button(b, 'تجديد صندوقي (يلغي القديم)', async () => { try { await enable(); note('تم التجديد'); } catch (e) { note('تعذّر: ' + e.message); } }, 'flip');
            button(b, 'إيقاف الدفع على هذا الجهاز', async () => { await disable(); note('تم الإيقاف'); const w = g('hx-sheet'); if (w) { w.remove(); HD.hub.open('notif'); } }, 'ban', 'danger');
        }
        const all = contacts(), keys = Object.keys(all);
        section(b, 'أصدقاء يمكن إيقاظهم (' + keys.length + ')');
        if (!keys.length) b.appendChild(el('p', 'hx-muted', 'يظهر هنا من اتصلت به بعد تفعيل الدفع عنده وعندك.'));
        keys.sort((a, z) => all[z].ts - all[a].ts).forEach((k) => {
            const ct = all[k], r = el('div', 'hx11-row'), l = el('div', 'hx11-lbl'); l.appendChild(el('span', '', ct.name)); l.appendChild(el('small', '', (online(ct.name) ? 'متصل الآن' : 'آخر ظهور ' + when(ct.ts)))); r.appendChild(l);
            const acts = el('div', 'hx11-inline'); const mk = (label, kind) => { const x = el('button', 'hx11-chipbtn', label); x.type = 'button'; x.onclick = async () => { x.disabled = true; const res = await notifyContact(k, kind); note(res.ok ? 'تم إيقاظ ' + ct.name : res.error === 'too-soon' ? 'أرسلت له للتو' : res.gone ? 'لم يعد مسجلاً' : 'تعذّر الإرسال'); x.disabled = false; }; return x; };
            if (!online(ct.name)) { acts.appendChild(mk('إيقاظ', 'wake')); acts.appendChild(mk('اتصال', 'call')); }
            const d = el('button', 'hx11-chipbtn red', 'حذف'); d.type = 'button'; d.onclick = () => { const a = contacts(); delete a[k]; jset(K.con, a); r.remove(); }; acts.appendChild(d); r.appendChild(acts); b.appendChild(r);
        });
        b.appendChild(el('p', 'hx-muted', 'الخصوصية: خادم الدفع يعرف فقط «صندوقاً» عشوائياً واشتراك المتصفح، ولا يرى أي رسالة. الصندوق لا يُعطى إلا للمتصلين عبر قناة مشفّرة، ويمكنك تجديده أو حذفه.'));
    }
    HD.push = { enable, disable, panel, test, notifyContact, contacts, cfg, me, autoNotify };
    setInterval(shareTick, 2000);
})();
