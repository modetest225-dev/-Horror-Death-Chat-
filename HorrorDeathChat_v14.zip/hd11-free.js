/* ============================================================
   HD Chat v11 — إلغاء نظام العملات: كل الميزات مفتوحة مجاناً
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11 || {};
    const FREE = 999999999;
    /* الدوال الأصلية تُستبدل: لا خصم ولا رصيد ولا قفل مستوى */
    getCoins = function () { return FREE; };
    deductCoins = function () { /* مجاني */ };
    addCoins = function () { /* لا عملات */ };
    claimDailyReward = function () { try { showLiveUpdate('لم يعد هناك ذهب — كل الميزات مفتوحة لك مجاناً ✨'); } catch (e) {} };
    triggerPremiumFeaturePurchase = function (f) { try { showLiveUpdate('الميزة «' + ((f && f.name) || '') + '» مفتوحة لك مجاناً'); } catch (e) {} };
    renderPremiumFeatures = function () { const c = document.getElementById('level-features-buttons-container'); if (c) c.textContent = ''; };
    /* لا أحد يُقفل بسبب مستوى منخفض: نرفع المستوى المعروض داخلياً */
    function unlock() { try { if (typeof currentUser !== 'undefined' && currentUser && currentUser.level < 100) currentUser.level = 100; } catch (e) {} try { if (typeof currentUser !== 'undefined' && currentUser) currentUser.coins = FREE; } catch (e) {} }
    setInterval(unlock, 250);
    document.addEventListener('DOMContentLoaded', unlock);
    HD.free = true;
})();
