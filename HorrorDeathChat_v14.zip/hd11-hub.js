/* ============================================================
   HD Chat v11 — مركز الخيارات (زر صغير واحد) + الإشعارات الحقيقية + إصلاح الموسيقى
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, iconBtn, sheet, section, row, toggle, select, button } = HD;
    const ICON_N = 'assets/notif/hd-carved-192.png', BADGE_N = 'assets/notif/hd-badge-96.png';

    /* ============ إصلاح الموسيقى: لا تعود وحدها بعد إيقافها ============ */
    const musicVol = () => Math.max(0.05, Math.min(1, (+ls.get('hx11_music_vol', '45') || 45) / 100));
    function paintMusicBtn(on) { const b = g('music-toggle-btn'); if (!b) return; b.classList.toggle('text-red-700', !!on); b.classList.toggle('text-stone-600', !on); b.setAttribute('aria-pressed', String(!!on)); }
    initMelancholyAudio = function () {
        if (ls.get('hx11_music', '') === 'off') return;           /* اخترتَ الإيقاف: لا تشغيل تلقائي أبداً */
        const a = g('bg-sad-music'); if (!a || isMusicPlaying) return; a.volume = musicVol();
        a.play().then(() => { isMusicPlaying = true; paintMusicBtn(true); }).catch(() => {});
    };
    toggleMusicControl = function (ev) {
        if (ev && ev.stopPropagation) ev.stopPropagation(); const a = g('bg-sad-music'); if (!a) return;
        if (isMusicPlaying || !a.paused) { a.pause(); isMusicPlaying = false; ls.set('hx11_music', 'off'); paintMusicBtn(false); }
        else { ls.set('hx11_music', 'on'); a.volume = musicVol(); a.play().then(() => { isMusicPlaying = true; paintMusicBtn(true); }).catch(() => { note('تعذّر تشغيل الموسيقى'); }); }
    };
    document.addEventListener('DOMContentLoaded', () => { if (ls.get('hx11_music', '') === 'off') paintMusicBtn(false); });

    /* ============ الإشعارات الحقيقية (عبر Service Worker) ============ */
    const N = { msg: 'hx11_n_msg', priv: 'hx11_n_priv', men: 'hx11_n_men', call: 'hx11_n_call', join: 'hx11_n_join', vis: 'hx11_n_vis', pre: 'hx11_n_pre', vib: 'hx11_n_vib' };
    const DEF = { hx11_n_msg: '1', hx11_n_priv: '1', hx11_n_men: '1', hx11_n_call: '1', hx11_n_join: '0', hx11_n_vis: '0', hx11_n_pre: '1', hx11_n_vib: '1' };
    const nget = (k) => ls.get(k, DEF[k]) === '1';
    function permState() { return ('Notification' in window) ? Notification.permission : 'unsupported'; }
    function enabled() { let s = {}; try { s = getAppSettings(); } catch (e) {} return !!(s.notificationsEnabled && permState() === 'granted'); }
    let unread = 0;
    function classify(title, body, opts) {
        const t = (opts && opts.cat) || ''; if (t) return t; const tag = (opts && opts.tag) || '';
        if (tag === 'hdc-connect') return 'join'; if (/خاص|private/i.test(title + tag)) return 'priv';
        try { if (currentUser && body && body.toLowerCase().includes('@' + currentUser.username.toLowerCase())) return 'men'; } catch (e) {} return 'msg';
    }
    async function display(title, body, opts) {
        const o = { body, icon: ICON_N, badge: BADGE_N, tag: opts.tag || ('hdc-' + Date.now()), renotify: true, dir: 'rtl', lang: 'ar', silent: false, data: Object.assign({ url: './' }, opts.data || {}) };
        if (nget(N.vib)) o.vibrate = [140, 70, 220]; if (opts.actions) o.actions = opts.actions; if (opts.requireInteraction) o.requireInteraction = true; if (opts.image) o.image = opts.image;
        let reg = null; try { if ('serviceWorker' in navigator) reg = await Promise.race([navigator.serviceWorker.ready, new Promise((r) => setTimeout(() => r(null), 2500))]); } catch (e) {}
        if (reg && reg.showNotification) { try { await reg.showNotification(title, o); if (!opts.requireInteraction) setTimeout(() => reg.getNotifications({ tag: o.tag }).then((a) => a.forEach((n) => n.close())).catch(() => {}), opts.ttl || 8000); return true; } catch (e) { console.warn('SW notification', e); } }
        try { const n = new Notification(title, { body, icon: ICON_N, badge: BADGE_N, tag: o.tag, dir: 'rtl', lang: 'ar' }); n.onclick = () => { window.focus(); n.close(); }; setTimeout(() => n.close(), opts.ttl || 6000); return true; } catch (e) { return false; }
    }
    showBrowserNotification = function (title, body, opts) {
        opts = opts || {}; if (!enabled()) return;
        const cat = classify(title, body, opts), allow = { msg: N.msg, priv: N.priv, men: N.men, call: N.call, join: N.join }[cat]; if (allow && !nget(allow)) return;
        const visible = !document.hidden && (document.hasFocus ? document.hasFocus() : true); if (visible && !nget(N.vis) && !opts.force) return;
        if (!nget(N.pre) && (cat === 'msg' || cat === 'priv' || cat === 'men')) { body = cat === 'priv' ? 'رسالة خاصة جديدة' : cat === 'men' ? 'تمت الإشارة إليك' : 'رسالة جديدة'; }
        unread++; try { if (navigator.setAppBadge) navigator.setAppBadge(unread).catch(() => {}); } catch (e) {}
        display(title, body, opts);
    };
    const clearBadge = () => { unread = 0; try { if (navigator.clearAppBadge) navigator.clearAppBadge().catch(() => {}); } catch (e) {} };
    document.addEventListener('visibilitychange', () => { if (!document.hidden) clearBadge(); }); window.addEventListener('focus', clearBadge);
    if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', (e) => {
        const d = e.data || {}; if (d.type !== 'notif_action' || !HD.call) return;
        if (d.action === 'answer') HD.call.acceptPending(d.cid, d.kind); else if (d.action === 'decline') HD.call.declinePending(d.cid);
    });
    async function testNotification() {
        if (permState() === 'default' || !enabled()) { requestNotificationPermission(); setTimeout(() => { if (enabled()) testNotification(); }, 1500); return; }
        const ok = await display('☣ Horror Death Chat', 'هذا إشعار تجريبي — الشعار المنحوت يظهر هنا', { tag: 'hdc-test', ttl: 7000 }); note(ok ? 'أُرسل الإشعار التجريبي' : 'تعذّر عرض الإشعار');
    }
    const standalone = () => (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone;

    function panelNotif(b) {
        const st = permState(), on = enabled();
        const sbox = el('div', 'hx11-status ' + (on ? 'ok' : 'bad')); sbox.appendChild(icon(on ? 'check' : 'panic', 20)); const tx = el('div');
        tx.appendChild(el('b', '', on ? 'الإشعارات مفعّلة على هذا الجهاز' : st === 'denied' ? 'الإشعارات محظورة من المتصفح' : st === 'unsupported' ? 'المتصفح لا يدعم الإشعارات' : 'الإشعارات غير مفعّلة'));
        tx.appendChild(el('small', '', on ? 'تصلك مع شعار H D المنحوت عندما تكون النافذة مخفية.' : st === 'denied' ? 'افتح إعدادات الموقع في المتصفح واسمح بالإشعارات ثم أعد المحاولة.' : 'اضغط «تفعيل» ثم اسمح للمتصفح.')); sbox.appendChild(tx); b.appendChild(sbox);
        if (!on && st !== 'denied' && st !== 'unsupported') button(b, 'تفعيل الإشعارات', () => { requestNotificationPermission(); setTimeout(() => { const w = g('hx-sheet'); if (w) { w.remove(); HD.hub.open('notif'); } }, 1800); }, 'check');
        if (on) button(b, 'إرسال إشعار تجريبي', testNotification, 'send');
        section(b, 'أنواع الإشعارات');
        [['الرسائل العامة', N.msg], ['الرسائل الخاصة', N.priv], ['عند الإشارة إليك @', N.men], ['المكالمات الواردة', N.call], ['دخول وخروج المتصلين', N.join]].forEach(([l, k]) => row(b, l, toggle(nget(k), (v) => ls.set(k, v ? '1' : '0'))));
        section(b, 'السلوك');
        row(b, 'إظهار نص الرسالة في الإشعار', toggle(nget(N.pre), (v) => ls.set(N.pre, v ? '1' : '0')), 'أوقفه للخصوصية؛ سيظهر «رسالة جديدة» فقط.');
        row(b, 'الاهتزاز', toggle(nget(N.vib), (v) => ls.set(N.vib, v ? '1' : '0')));
        row(b, 'حتى والنافذة مفتوحة أمامي', toggle(nget(N.vis), (v) => ls.set(N.vis, v ? '1' : '0')));
        section(b, 'للوصول على الهاتف');
        const tip = el('div', 'hx11-tipbox');
        [standalone() ? 'التطبيق مثبّت على الشاشة الرئيسية ✓' : 'ثبّت الموقع على الشاشة الرئيسية (قائمة المتصفح ← تثبيت التطبيق) لتصلك الإشعارات بثبات، وهذا شرط على iPhone.', 'الإشعارات تعمل أثناء فتح الموقع أو بقائه في الخلفية. أما وهو مغلق تماماً فيلزمها خادم دفع (Push) منفصل لأن الدردشة بلا خوادم.'].forEach((t) => tip.appendChild(el('p', '', t))); b.appendChild(tip);
        if (HD.push) HD.push.panel(b);
    }

    /* ============ إعدادات النص ============ */
    const TK = { lh: 'hx11_lh', ls: 'hx11_ls', al: 'hx11_al', fw: 'hx11_fw', dir: 'hx11_dir' };
    function applyText() {
        const r = document.documentElement.style; r.setProperty('--msg-lh', ls.get(TK.lh, '1.6')); r.setProperty('--msg-ls', ls.get(TK.ls, '0') + 'px'); r.setProperty('--msg-fw', ls.get(TK.fw, '400')); r.setProperty('--msg-al', ls.get(TK.al, 'start'));
        document.body.classList.toggle('hx11-dir-rtl', ls.get(TK.dir, 'auto') === 'rtl'); document.body.classList.toggle('hx11-dir-ltr', ls.get(TK.dir, 'auto') === 'ltr');
    }
    function panelText(b) {
        const pv = el('div', 'hx11-textprev'); pv.appendChild(el('div', 'hx11-pv-body msg-body', 'هنا يسكن الظلام... Welcome to the dark side 123 ١٢٣')); b.appendChild(pv);
        const upd = () => { applyText(); if (HD.applyTheme) HD.applyTheme(); };
        const rg = (min, max, step, key, def) => { const i = el('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = ls.get(key, def); i.oninput = () => { ls.set(key, i.value); upd(); }; return i; };
        row(b, 'حجم الخط', rg(11, 24, 1, 'hx11_fs2', '13'));
        row(b, 'نوع الخط', select([['amiri', 'أميري (الافتراضي)'], ['system', 'خط النظام'], ['mono', 'آلة كاتبة'], ['cinzel', 'زخرفي'], ['tahoma', 'تاهوما']], ls.get('hx11_font', 'amiri'), (v) => { ls.set('hx11_font', v); upd(); }));
        row(b, 'المسافة بين السطور', rg(1.2, 2.4, 0.1, TK.lh, '1.6'));
        row(b, 'المسافة بين الحروف', rg(0, 3, 0.5, TK.ls, '0'));
        row(b, 'سماكة الخط', select([['400', 'عادي'], ['500', 'متوسط'], ['700', 'عريض']], ls.get(TK.fw, '400'), (v) => { ls.set(TK.fw, v); upd(); }));
        row(b, 'محاذاة النص', select([['start', 'تلقائي'], ['right', 'يمين'], ['left', 'يسار'], ['justify', 'ضبط الأطراف'], ['center', 'وسط']], ls.get(TK.al, 'start'), (v) => { ls.set(TK.al, v); upd(); }));
        row(b, 'اتجاه الكتابة', select([['auto', 'تلقائي حسب اللغة'], ['rtl', 'من اليمين لليسار'], ['ltr', 'من اليسار لليمين']], ls.get(TK.dir, 'auto'), (v) => { ls.set(TK.dir, v); upd(); }));
        row(b, 'التدقيق الإملائي في الكتابة', toggle(ls.get('hx11_spell', '1') === '1', (v) => { ls.set('hx11_spell', v ? '1' : '0'); const i = g('msg-input'); if (i) i.spellcheck = v; }));
        button(b, 'إعادة ضبط النص', () => { Object.values(TK).concat(['hx11_fs2', 'hx11_font']).forEach((k) => ls.del(k)); upd(); const w = g('hx-sheet'); if (w) { w.remove(); HD.hub.open('text'); } }, 'flip');
    }

    /* ============ الملصقات والإيموجي ============ */
    const EMO = '😀 😃 😄 😁 😆 😅 😂 🤣 😊 🙂 😉 😍 🥰 😘 😎 🤩 🥳 😏 😌 😴 🤔 🙄 😬 😮 😱 😨 😰 😢 😭 😤 😡 🤬 😈 👿 💀 ☠️ 👻 👽 🤖 🎃 🙈 🙉 🙊 👍 👎 👏 🙌 🙏 💪 👀 👁️ 🧠 🫀 🩸 🔪 ⚰️ 🪦 🕯️ 🔮 🧿 🕷️ 🕸️ 🦇 🐈‍⬛ 🌑 🌙 ⭐ ✨ 🔥 ⚡ 💥 🌫️ ❤️ 🖤 💔 💯 🎉 🎶'.split(' ');
    function insertAtCaret(t) { const i = g('msg-input'); if (!i) return; const a = i.selectionStart == null ? i.value.length : i.selectionStart, bnd = i.selectionEnd == null ? a : i.selectionEnd; const pre = i.value.slice(0, a), sp = pre && !/\s$/.test(pre) && t.startsWith(':') ? ' ' : ''; i.value = pre + sp + t + i.value.slice(bnd); const p = (pre + sp + t).length; i.setSelectionRange(p, p); i.focus(); i.dispatchEvent(new Event('input', { bubbles: true })); }
    function panelStickers(b, w) {
        const S = HD.stickers, packs = (S.PACKS || [{ id: 'base', name: 'ملصقات HD', keys: S.NAMES }]).concat([{ id: 'emoji', name: 'إيموجي' }]);
        const tabs = el('div', 'hx11-tabs sub scroll2'); b.appendChild(tabs); const grid = el('div', 'hx11-stgrid'); b.appendChild(grid); let cur = ls.get('hx11_pack', 'base');
        const draw = (id) => {
            cur = id; ls.set('hx11_pack', id); tabs.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x.dataset.p === id)); grid.textContent = '';
            if (id === 'emoji') { grid.className = 'hx11-stgrid emo'; EMO.forEach((e) => { const x = el('button', 'hx11-stbtn emo', e); x.type = 'button'; x.onclick = () => insertAtCaret(e); grid.appendChild(x); }); return; }
            grid.className = 'hx11-stgrid'; const pk = packs.find((p) => p.id === id) || packs[0];
            pk.keys.forEach((n) => { const x = el('button', 'hx11-stbtn'); x.type = 'button'; x.title = S.ST[n][0]; x.setAttribute('aria-label', S.ST[n][0]); x.appendChild(S.svg(n, 44)); x.onclick = () => { insertAtCaret(':hd_' + n + ':'); try { const c = +ls.get('hx11_stat_stk', '0'); ls.set('hx11_stat_stk', String(c + 1)); } catch (e) {} }; grid.appendChild(x); });
        };
        packs.forEach((p) => { const x = el('button', p.id === cur ? 'on' : '', p.name + (p.keys ? ' (' + p.keys.length + ')' : '')); x.type = 'button'; x.dataset.p = p.id; x.onclick = () => draw(p.id); tabs.appendChild(x); });
        draw(packs.some((p) => p.id === cur) ? cur : 'base');
        b.appendChild(el('p', 'hx-muted', 'اضغط على ملصق لإضافته لرسالتك. اترك الرسالة ملصقاً وحده ليظهر كبيراً. ' + S.NAMES.length + ' ملصقاً من رسمنا في 4 مجموعات.'));
        button(b, 'إغلاق وكتابة الرسالة', () => { w.remove(); const i = g('msg-input'); if (i) i.focus(); }, 'send');
    }

    /* ============ لوحات التبويبات ============ */
    const W = () => HD.write || {};
    const tile = (b, ico, label, fn, hint) => { let grid = b.querySelector(':scope > .hx11-tiles:last-child'); if (!grid) { grid = el('div', 'hx11-tiles'); b.appendChild(grid); } const t = el('button', 'hx11-tile2'); t.type = 'button'; t.appendChild(icon(ico, 22)); t.appendChild(el('b', '', label)); if (hint) t.appendChild(el('small', '', hint)); t.onclick = fn; grid.appendChild(t); return t; };
    const closeHub = () => { const w = g('hx-sheet'); if (w) w.remove(); };
    const legacy = (label) => () => { const b = document.querySelector('#hx-bar .hx-tb[aria-label="' + label + '"]'); if (b) { b.click(); } else note('هذه الأداة غير متاحة الآن'); };
    function panelWrite(b) {
        const w = W(); const fm = (fn) => () => { closeHub(); setTimeout(() => { const i = g('msg-input'); if (i) i.focus(); fn(); }, 40); };
        section(b, 'تنسيق النص (حدّد جزءاً من كتابتك أولاً)');
        tile(b, 'bold', 'غامق', fm(() => w.wrapSel && w.wrapSel('*')), '*نص*'); tile(b, 'italic', 'مائل', fm(() => w.wrapSel && w.wrapSel('_')), '_نص_'); tile(b, 'code', 'كود', fm(() => w.wrapSel && w.wrapSel('`')), '`نص`');
        tile(b, 'strike', 'مشطوب', fm(() => w.wrapSel && w.wrapSel('~')), '~نص~'); tile(b, 'eyeOff', 'نص مخفي', fm(() => w.wrapSel && w.wrapSel('||')), '||نص||'); tile(b, 'quote', 'اقتباس', fm(() => w.quoteSel && w.quoteSel()), '> نص');
        section(b, 'أدوات الكتابة');
        tile(b, 'wand', 'أنماط الحروف', () => { closeHub(); w.openStyles && w.openStyles(); }, 'مرعب · قوطي · مقلوب'); tile(b, 'template', 'القوالب', () => { closeHub(); w.openTemplates && w.openTemplates(); }, 'عباراتك المحفوظة');
        tile(b, 'clock', 'إرسال مؤجل', () => { closeHub(); w.openSchedule && w.openSchedule(); }, 'جدولة رسالة'); tile(b, 'mic2', 'إملاء صوتي', () => { closeHub(); w.dictate && w.dictate(document.createElement('i')); }, 'تحدّث لتكتب');
        tile(b, 'type', 'إعدادات الكتابة', () => { closeHub(); w.openWriteSettings && w.openWriteSettings(); }, 'Enter · الإملاء');
    }
    function panelCalls(b) {
        const live = HD.call && HD.call.state && HD.call.state.active;
        if (live) { const st = el('div', 'hx11-status ok'); st.appendChild(icon('phone', 20)); const t = el('div'); t.appendChild(el('b', '', 'أنت في مكالمة الآن')); st.appendChild(t); b.appendChild(st); button(b, 'العودة للمكالمة', () => { closeHub(); HD.call.start('video', []); }, 'video'); }
        section(b, 'ابدأ الآن');
        tile(b, 'video', 'مكالمة فيديو', () => { closeHub(); HD.call.openStart('video'); }, 'للجميع أو لمن تختار'); tile(b, 'phone', 'مكالمة صوتية', () => { closeHub(); HD.call.openStart('audio'); });
        tile(b, 'monitor', 'مشاركة الشاشة', () => { closeHub(); HD.call.openStart('screen'); }, 'سطح المكتب أو نافذة'); tile(b, 'sliders', 'إعدادات المكالمات', () => { closeHub(); HD.call.openSettings(); }, 'الأجهزة · المؤثرات · الجودة');
        b.appendChild(el('p', 'hx-muted', 'المكالمات مباشرة بين الأجهزة ومشفّرة. داخل المكالمة تجد: تأثيرات الفيديو، التسجيل، الدردشة، التقاط صورة، رفع اليد، التفاعلات.'));
    }
    function panelLook(b) {
        tile(b, 'palette', 'السمات والألوان', () => { closeHub(); HD.openTheme(); }, '11 سمة + ألوان مخصصة'); tile(b, 'type', 'إعدادات النص', () => { closeHub(); HD.hub.open('text'); }, 'الخط والمسافات');
        b.appendChild(el('p', 'hx-muted', 'السمة الحالية تُحفظ على جهازك وتُطبَّق تلقائياً عند الدخول.'));
    }
    function panelSecurity(b) {
        const s = HD.peersSummary(), sc = HD.guard ? HD.guard.score().pts : null; const st = el('div', 'hx11-status ' + (HD.e2e ? 'ok' : 'bad')); st.appendChild(icon(HD.e2e ? 'shield' : 'panic', 20)); const t = el('div'); t.appendChild(el('b', '', (HD.e2e ? 'التشفير الطرفي مفعّل' : 'التشفير غير متاح') + (sc != null ? ' — درجة الحماية ' + sc + '/100' : ''))); t.appendChild(el('small', '', s.total ? s.enc + ' من ' + s.total + ' اتصالات مشفّرة' : 'لا اتصالات حالياً')); st.appendChild(t); b.appendChild(st);
        tile(b, 'shield', 'مركز الحماية', () => { closeHub(); HD.openSecurity(); }, 'المستوى · الهويات · الحظر'); tile(b, 'panic', 'زر الطوارئ', () => { closeHub(); document.dispatchEvent(new KeyboardEvent('keydown', { key: 'X', ctrlKey: true, shiftKey: true })); }, 'مسح وقطع');
    }
    function panelTools(b) {
        [['search', 'بحث في الرسائل', 'بحث'], ['users', 'قائمة المتصلين', 'المتصلون'], ['sliders', 'أدوات وتصدير', 'الأدوات'], ['plus', 'استطلاع وأوامر', 'المزيد'], ['grid', 'كتم وإحصائيات', 'أدوات إضافية']].forEach(([ic, lb, ar]) => tile(b, ic, lb, legacy(ar)));
        section(b, 'الموسيقى'); const m = el('div', 'hx11-row'); m.appendChild(el('div', 'hx11-lbl', 'موسيقى الخلفية الحزينة')); m.appendChild(toggle(isMusicPlaying, (v) => { toggleMusicControl(); })); b.appendChild(m);
        const vol = el('input', 'hx11-vol'); vol.type = 'range'; vol.min = 5; vol.max = 100; vol.value = ls.get('hx11_music_vol', '45'); vol.oninput = () => { ls.set('hx11_music_vol', vol.value); const a = g('bg-sad-music'); if (a) a.volume = musicVol(); }; row(b, 'مستوى الصوت', vol);
        b.appendChild(el('p', 'hx-muted', '«ظلام لا ينتهي»: مقطوعة أصلية بطيئة بالبيانو والأوتار في مقام لا الصغير، تعمل بلا إنترنت. تبقى مغلقة بعد إيقافها حتى تشغّلها بنفسك.'));
        if (HD.offline) HD.offline.panel(b);
    }
    const TABS = [['write', 'الكتابة', 'type', panelWrite], ['stickers', 'ملصقات', 'smile', panelStickers], ['people', 'الأشخاص', 'users', null], ['calls', 'المكالمات', 'video', panelCalls], ['text', 'النص', 'bold', panelText], ['look', 'المظهر', 'palette', panelLook], ['notif', 'الإشعارات', 'volume', panelNotif], ['security', 'الأمان', 'shield', panelSecurity], ['tools', 'أدوات', 'sliders', panelTools]];
    function open(tab) {
        if (typeof currentUser === 'undefined' || !currentUser) { note('ادخل إلى الغرفة أولاً'); return; }
        tab = TABS.some((t) => t[0] === tab) ? tab : (ls.get('hx11_hubtab', 'write')); if (!TABS.some((t) => t[0] === tab)) tab = 'write';
        sheet('مركز الخيارات', (box, w) => {
            const bar = el('div', 'hx11-tabs scroll'); const body = el('div', 'hx11-hubbody'); box.appendChild(bar); box.appendChild(body);
            const show = (id) => {
                ls.set('hx11_hubtab', id); bar.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x.dataset.t === id)); body.textContent = '';
                const def = TABS.find((t) => t[0] === id); if (id === 'people') { const c = el('div'); c.id = 'hx11-people'; body.appendChild(c); HD.social.renderPeople(c); } else def[3](body, w);
            };
            TABS.forEach(([id, label, ic]) => { const x = el('button'); x.type = 'button'; x.dataset.t = id; x.appendChild(icon(ic, 15)); x.appendChild(el('span', '', label)); x.onclick = () => show(id); bar.appendChild(x); });
            show(tab); const on = bar.querySelector('button.on'); if (on && on.scrollIntoView) on.scrollIntoView({ block: 'nearest', inline: 'center' });
        }, { wide: true });
    }
    HD.hub = { open, tabs: TABS };

    /* ============ الزر الصغير بجانب خانة الكتابة ============ */
    function install() {
        const i = g('msg-input'); if (!i || g('hx11-hubbtn')) return !!g('hx11-hubbtn');
        const b = iconBtn('grid', 'مركز الخيارات (Ctrl+/)', () => open(), 'hx11-hubbtn'); b.id = 'hx11-hubbtn'; b.setAttribute('aria-haspopup', 'dialog');
        i.parentElement.insertBefore(b, i); return true;
    }
    function init() {
        applyText(); let n = 0; const iv = setInterval(() => { if (install() || ++n > 60) clearInterval(iv); }, 300);
        document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key === '/') { e.preventDefault(); open(); } });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
