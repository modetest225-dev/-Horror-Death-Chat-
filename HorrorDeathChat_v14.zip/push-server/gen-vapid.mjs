/* يولّد مفاتيح VAPID مرة واحدة:  node gen-vapid.mjs */
const b64u = (u) => Buffer.from(u).toString('base64url');
const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const jwk = await crypto.subtle.exportKey('jwk', kp.privateKey), pub = new Uint8Array(await crypto.subtle.exportKey('raw', kp.publicKey));
console.log('VAPID_PUBLIC  =', b64u(pub)); console.log('VAPID_PRIVATE =', jwk.d);
console.log('\nالعام (PUBLIC): ضعه في wrangler.toml وفي push-config.js.\nالخاص (PRIVATE): سرّي — نفّذ: npx wrangler secret put VAPID_PRIVATE');
