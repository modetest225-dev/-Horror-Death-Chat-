/* ============================================================
   HD Chat — خادم الدفع (Cloudflare Worker)
   يوصل إشعاراً حقيقياً لجهاز صديقك حتى والموقع مغلق.
   - لا يخزّن رسائل ولا أسماء: فقط «صندوق» عشوائي ↔ اشتراك الجهاز.
   - الحمولة مشفّرة بين الخادم وجهاز المستلم (RFC 8291) ويوقّعها VAPID (RFC 8292).
   ============================================================ */
const te = new TextEncoder();
const b64u = {
    enc(buf) { const u = buf instanceof Uint8Array ? buf : new Uint8Array(buf); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); },
    dec(s) { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
};
const concat = (...a) => { const n = a.reduce((x, y) => x + y.length, 0), o = new Uint8Array(n); let p = 0; a.forEach((x) => { o.set(x, p); p += x.length; }); return o; };
const subtle = crypto.subtle;

/* ── خوادم الدفع المسموحة فقط (منع استخدام الخادم كوسيط هجوم SSRF) ── */
const PUSH_HOSTS = [/(^|\.)fcm\.googleapis\.com$/, /(^|\.)push\.services\.mozilla\.com$/, /(^|\.)push\.apple\.com$/, /(^|\.)notify\.windows\.com$/, /(^|\.)push\.microsoft\.com$/];
export function okEndpoint(u) { try { const x = new URL(u); return x.protocol === 'https:' && !x.username && !x.password && x.port === '' && PUSH_HOSTS.some((r) => r.test(x.hostname)) && u.length < 600; } catch (e) { return false; } }
const okKey = (k, len) => { try { return typeof k === 'string' && /^[A-Za-z0-9_-]+$/.test(k) && b64u.dec(k).length === len; } catch (e) { return false; } };

/* ── تشفير الحمولة: aes128gcm (RFC 8291) ── */
export async function encryptPayload(plain, p256dh, auth, test) {
    const uaPub = b64u.dec(p256dh), authSecret = b64u.dec(auth);
    const kp = test && test.keyPair ? test.keyPair : await subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
    const asPub = new Uint8Array(await subtle.exportKey('raw', kp.publicKey));
    const uaKey = await subtle.importKey('raw', uaPub, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
    const ecdh = await subtle.deriveBits({ name: 'ECDH', public: uaKey }, kp.privateKey, 256);
    const salt = test && test.salt ? test.salt : crypto.getRandomValues(new Uint8Array(16));
    const hk = async (ikm, s, info, bits) => subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: s, info }, await subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']), bits);
    const keyInfo = concat(te.encode('WebPush: info\0'), uaPub, asPub);
    const ikm = new Uint8Array(await hk(new Uint8Array(ecdh), authSecret, keyInfo, 256));
    const cek = new Uint8Array(await hk(ikm, salt, te.encode('Content-Encoding: aes128gcm\0'), 128));
    const nonce = new Uint8Array(await hk(ikm, salt, te.encode('Content-Encoding: nonce\0'), 96));
    const data = typeof plain === 'string' ? te.encode(plain) : plain; if (data.length > 3800) throw new Error('payload too large');
    const ct = new Uint8Array(await subtle.encrypt({ name: 'AES-GCM', iv: nonce }, await subtle.importKey('raw', cek, 'AES-GCM', false, ['encrypt']), concat(data, new Uint8Array([2]))));
    const rs = new Uint8Array([0, 0, 0x10, 0]); /* 4096 */
    return concat(salt, rs, new Uint8Array([asPub.length]), asPub, ct);
}

/* ── توقيع VAPID (RFC 8292) ── */
export async function vapidAuth(endpoint, env, now) {
    const aud = new URL(endpoint).origin, exp = Math.floor((now || Date.now()) / 1000) + 12 * 3600;
    const head = b64u.enc(te.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' }))), body = b64u.enc(te.encode(JSON.stringify({ aud, exp, sub: env.VAPID_SUBJECT || 'mailto:admin@example.com' })));
    const pub = b64u.dec(env.VAPID_PUBLIC); const jwk = { kty: 'EC', crv: 'P-256', x: b64u.enc(pub.slice(1, 33)), y: b64u.enc(pub.slice(33, 65)), d: env.VAPID_PRIVATE, ext: true };
    const key = await subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
    const sig = new Uint8Array(await subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, te.encode(head + '.' + body)));
    return 'vapid t=' + head + '.' + body + '.' + b64u.enc(sig) + ', k=' + env.VAPID_PUBLIC;
}
export async function sendPush(sub, payload, env, opts) {
    opts = opts || {}; const body = await encryptPayload(JSON.stringify(payload), sub.keys.p256dh, sub.keys.auth);
    return fetch(sub.endpoint, { method: 'POST', headers: { 'Authorization': await vapidAuth(sub.endpoint, env), 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', 'TTL': String(opts.ttl || 3600), 'Urgency': opts.urgency || 'normal' }, body });
}

/* ── المسارات ── */
const cors = (env) => ({ 'Access-Control-Allow-Origin': (env && env.ALLOWED_ORIGIN) || '*', 'Access-Control-Allow-Methods': 'POST, DELETE, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Max-Age': '86400', 'Vary': 'Origin' });
const json = (o, status, env) => new Response(JSON.stringify(o), { status: status || 200, headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, cors(env)) });
const cleanLabel = (s) => String(s == null ? '' : s).normalize('NFKC').replace(/[\u0000-\u001f\u007f<>\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/g, '').replace(/\s+/g, ' ').trim().slice(0, 24);
const rnd = (n) => b64u.enc(crypto.getRandomValues(new Uint8Array(n)));
const sha = async (s) => b64u.enc(await subtle.digest('SHA-256', te.encode(s)));
async function hit(env, key, limit, ttl) {
    const raw = await env.KV.get(key); const n = (raw ? parseInt(raw, 10) : 0) || 0; if (n >= limit) return false;
    await env.KV.put(key, String(n + 1), { expirationTtl: Math.max(60, ttl) }); return true;
}
const KINDS = { msg: ['رسالة جديدة من', 'normal', 3600], wake: ['يريدك الآن في الغرفة:', 'high', 1800], call: ['يتصل بك:', 'high', 45] };

export default {
    async fetch(req, env) {
        const url = new URL(req.url);
        if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(env) });
        if (req.method === 'GET' && url.pathname === '/') return json({ ok: true, service: 'hd-push', vapid: env.VAPID_PUBLIC || null }, 200, env);
        if (!env.KV || !env.VAPID_PUBLIC || !env.VAPID_PRIVATE) return json({ ok: false, error: 'server-not-configured' }, 500, env);
        let body = null; if (req.method === 'POST' || req.method === 'DELETE') { try { const t = await req.text(); if (t.length > 4000) return json({ ok: false, error: 'too-large' }, 413, env); body = JSON.parse(t); } catch (e) { return json({ ok: false, error: 'bad-json' }, 400, env); } if (!body || typeof body !== 'object') return json({ ok: false, error: 'bad-json' }, 400, env); }
        const ip = req.headers.get('CF-Connecting-IP') || 'x';

        if (req.method === 'POST' && url.pathname === '/register') {
            const s = body.sub; if (!s || !okEndpoint(s.endpoint) || !s.keys || !okKey(s.keys.p256dh, 65) || !okKey(s.keys.auth, 16)) return json({ ok: false, error: 'bad-subscription' }, 400, env);
            if (!(await hit(env, 'reg:' + (await sha(ip)) + ':' + Math.floor(Date.now() / 3600000), 20, 3600))) return json({ ok: false, error: 'rate-limited' }, 429, env);
            const inbox = rnd(16), token = rnd(16);
            await env.KV.put('i:' + inbox, JSON.stringify({ sub: { endpoint: s.endpoint, keys: { p256dh: s.keys.p256dh, auth: s.keys.auth } }, th: await sha(token), t: Date.now() }), { expirationTtl: 60 * 24 * 3600 });
            return json({ ok: true, inbox, token }, 200, env);
        }
        if (req.method === 'POST' && url.pathname === '/notify') {
            const k = KINDS[body.kind]; if (!k || typeof body.inbox !== 'string' || !/^[A-Za-z0-9_-]{22}$/.test(body.inbox)) return json({ ok: false, error: 'bad-request' }, 400, env);
            const raw = await env.KV.get('i:' + body.inbox); if (!raw) return json({ ok: false, gone: true }, 404, env);
            const from = cleanLabel(body.from) || 'شخص ما';
            if (!(await hit(env, 'n:' + body.inbox + ':' + Math.floor(Date.now() / 3600000), 40, 3600))) return json({ ok: false, error: 'rate-limited' }, 429, env);
            if (!(await hit(env, 'f:' + body.inbox + ':' + (await sha(from + '|' + body.kind)), 1, 60))) return json({ ok: false, error: 'too-soon' }, 429, env);
            let rec; try { rec = JSON.parse(raw); } catch (e) { await env.KV.delete('i:' + body.inbox); return json({ ok: false, gone: true }, 404, env); }
            const payload = { t: '☣ Horror Death Chat', b: k[0] + ' ' + from, tag: 'hdc-' + body.kind + '-' + (await sha(from)).slice(0, 8), k: body.kind };
            let r; try { r = await sendPush(rec.sub, payload, env, { ttl: k[2], urgency: k[1] }); } catch (e) { return json({ ok: false, error: 'send-failed' }, 502, env); }
            if (r.status === 404 || r.status === 410) { await env.KV.delete('i:' + body.inbox); return json({ ok: false, gone: true }, 404, env); }
            return json({ ok: r.status >= 200 && r.status < 300, status: r.status }, r.ok ? 200 : 502, env);
        }
        if (req.method === 'DELETE' && url.pathname === '/inbox') {
            if (typeof body.inbox !== 'string' || !/^[A-Za-z0-9_-]{22}$/.test(body.inbox) || typeof body.token !== 'string') return json({ ok: false, error: 'bad-request' }, 400, env);
            const raw = await env.KV.get('i:' + body.inbox); if (!raw) return json({ ok: true }, 200, env);
            let rec; try { rec = JSON.parse(raw); } catch (e) { rec = null; }
            if (rec && rec.th !== (await sha(body.token))) return json({ ok: false, error: 'forbidden' }, 403, env);
            await env.KV.delete('i:' + body.inbox); return json({ ok: true }, 200, env);
        }
        return json({ ok: false, error: 'not-found' }, 404, env);
    }
};
