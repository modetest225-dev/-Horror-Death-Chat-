/* اختبار ذاتي لخادم الدفع:  node test.mjs  (بدون شبكة) */
import worker, { encryptPayload, okEndpoint } from './worker.js';
const b64u = { dec: (s) => new Uint8Array(Buffer.from(s, 'base64url')), enc: (u) => Buffer.from(u).toString('base64url') };
let pass = 0, fail = 0; const ok = (c, m) => { if (c) pass++; else { fail++; console.log('FAIL:', m); } };
/* 1) متجه RFC 8291 الرسمي */
{
    const asPub = b64u.dec('BP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A8');
    const priv = await crypto.subtle.importKey('jwk', { kty: 'EC', crv: 'P-256', x: b64u.enc(asPub.slice(1, 33)), y: b64u.enc(asPub.slice(33)), d: 'yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw', ext: true }, { name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
    const pub = await crypto.subtle.importKey('raw', asPub, { name: 'ECDH', namedCurve: 'P-256' }, true, []);
    const out = await encryptPayload('When I grow up, I want to be a watermelon', 'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4', 'BTBZMqHH6r4Tts7J_aSIgg', { keyPair: { privateKey: priv, publicKey: pub }, salt: b64u.dec('DGv6ra1nlYgDCS1FRnbzlw') });
    ok(b64u.enc(out) === 'DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN', 'RFC 8291 vector');
}
/* 2) بيئة وهمية */
const vk = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const vpub = new Uint8Array(await crypto.subtle.exportKey('raw', vk.publicKey)), vjwk = await crypto.subtle.exportKey('jwk', vk.privateKey);
const store = new Map(); const KV = { async get(k) { return store.get(k) ?? null; }, async put(k, v) { store.set(k, v); }, async delete(k) { store.delete(k); } };
const env = { KV, VAPID_PUBLIC: b64u.enc(vpub), VAPID_PRIVATE: vjwk.d, VAPID_SUBJECT: 'mailto:t@example.com', ALLOWED_ORIGIN: 'https://chat.example.com' };
const call = (method, path, body, headers) => worker.fetch(new Request('https://push.example.workers.dev' + path, { method, headers: Object.assign({ 'Content-Type': 'application/json', 'CF-Connecting-IP': '1.2.3.4' }, headers || {}), body: body === undefined ? undefined : JSON.stringify(body) }), env);
const ua = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']); const uaPub = b64u.enc(new Uint8Array(await crypto.subtle.exportKey('raw', ua.publicKey))); const authS = b64u.enc(crypto.getRandomValues(new Uint8Array(16)));
const goodSub = { endpoint: 'https://fcm.googleapis.com/fcm/send/abc123', keys: { p256dh: uaPub, auth: authS } };
let pushed = [], pushStatus = 201; const realFetch = globalThis.fetch; globalThis.fetch = async (u, init) => { pushed.push({ u, init }); return new Response('', { status: pushStatus }); };
/* GET / و CORS */
let r = await call('GET', '/'); ok(r.status === 200 && (await r.json()).ok, 'health'); r = await call('OPTIONS', '/register'); ok(r.status === 204 && r.headers.get('Access-Control-Allow-Origin') === 'https://chat.example.com', 'cors');
/* التسجيل: نقاط نهاية مرفوضة (SSRF) */
for (const ep of ['http://fcm.googleapis.com/x', 'https://evil.example.com/x', 'https://127.0.0.1/x', 'https://fcm.googleapis.com.evil.com/x', 'https://user:pw@fcm.googleapis.com/x', 'https://169.254.169.254/latest', 'https://fcm.googleapis.com:8443/x']) { r = await call('POST', '/register', { sub: { endpoint: ep, keys: goodSub.keys } }); ok(r.status === 400, 'reject ' + ep); }
ok(okEndpoint('https://updates.push.services.mozilla.com/wpush/v2/x') && okEndpoint('https://web.push.apple.com/x') && okEndpoint('https://wns2-par02p.notify.windows.com/w/?token=x'), 'allowed hosts');
r = await call('POST', '/register', { sub: { endpoint: goodSub.endpoint, keys: { p256dh: 'short', auth: authS } } }); ok(r.status === 400, 'bad key');
r = await call('POST', '/register', { sub: goodSub }); const reg = await r.json(); ok(r.status === 200 && /^[\w-]{22}$/.test(reg.inbox) && /^[\w-]{22}$/.test(reg.token), 'register ok');
r = await call('POST', '/register', 'x'); ok(r.status === 400, 'bad json');
/* الإشعار */
r = await call('POST', '/notify', { inbox: 'AAAAAAAAAAAAAAAAAAAAAA', kind: 'msg', from: 'x' }); ok(r.status === 404 && (await r.json()).gone, 'unknown inbox');
r = await call('POST', '/notify', { inbox: reg.inbox, kind: 'evil', from: 'x' }); ok(r.status === 400, 'bad kind');
r = await call('POST', '/notify', { inbox: '../../etc', kind: 'msg', from: 'x' }); ok(r.status === 400, 'bad inbox format');
pushed = []; r = await call('POST', '/notify', { inbox: reg.inbox, kind: 'wake', from: 'Al\u202Eice\u200b<b>' }); ok(r.status === 200, 'notify ok');
ok(pushed.length === 1 && pushed[0].u === goodSub.endpoint, 'pushed to endpoint');
const h = pushed[0].init.headers; ok(h['Content-Encoding'] === 'aes128gcm' && h['TTL'] === '1800' && h['Urgency'] === 'high', 'headers');
/* التوقيع VAPID */
{ const m = /^vapid t=([\w-]+)\.([\w-]+)\.([\w-]+), k=([\w-]+)$/.exec(h['Authorization']); ok(!!m, 'vapid format'); if (m) { const hd = JSON.parse(Buffer.from(m[1], 'base64url')), pl = JSON.parse(Buffer.from(m[2], 'base64url'));
    ok(hd.alg === 'ES256' && pl.aud === 'https://fcm.googleapis.com' && pl.exp > Date.now() / 1000 && pl.exp <= Date.now() / 1000 + 12 * 3600 + 5 && pl.sub === 'mailto:t@example.com' && m[4] === env.VAPID_PUBLIC, 'jwt claims');
    ok(await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, vk.publicKey, b64u.dec(m[3]), new TextEncoder().encode(m[1] + '.' + m[2])), 'jwt signature verifies'); } }
/* فك حمولة الإشعار كما يفعل الجهاز */
{ const body = new Uint8Array(pushed[0].init.body), salt = body.slice(0, 16), idl = body[20], asPub = body.slice(21, 21 + idl), ct = body.slice(21 + idl);
  const hk = async (ikm, s, info, bits) => crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: s, info }, await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']), bits);
  const asKey = await crypto.subtle.importKey('raw', asPub, { name: 'ECDH', namedCurve: 'P-256' }, false, []); const sh = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: asKey }, ua.privateKey, 256));
  const te = new TextEncoder(), cat = (...a) => { const o = new Uint8Array(a.reduce((x, y) => x + y.length, 0)); let p = 0; a.forEach((x) => { o.set(x, p); p += x.length; }); return o; };
  const ikm = new Uint8Array(await hk(sh, b64u.dec(authS), cat(te.encode('WebPush: info\0'), b64u.dec(uaPub), asPub), 256)); const cek = await hk(ikm, salt, te.encode('Content-Encoding: aes128gcm\0'), 128), nonce = await hk(ikm, salt, te.encode('Content-Encoding: nonce\0'), 96);
  const pt = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: new Uint8Array(nonce) }, await crypto.subtle.importKey('raw', cek, 'AES-GCM', false, ['decrypt']), ct)); const msg = JSON.parse(new TextDecoder().decode(pt.slice(0, -1)));
  ok(pt[pt.length - 1] === 2 && msg.k === 'wake' && msg.b.includes('Alice') && !/[\u202e\u200b<>]/.test(msg.b), 'device can decrypt; label sanitized: ' + msg.b); }
/* حدود المعدل */
r = await call('POST', '/notify', { inbox: reg.inbox, kind: 'wake', from: 'Al\u202Eice\u200b<b>' }); ok(r.status === 429, 'too soon (same sender+kind)');
let okN = 0; for (let i = 0; i < 60; i++) { r = await call('POST', '/notify', { inbox: reg.inbox, kind: 'msg', from: 'user' + i }); if (r.status === 200) okN++; } ok(okN > 0 && okN <= 40, 'hourly cap enforced (' + okN + ' delivered)');
/* اشتراك منتهٍ → يُحذف */
r = await call('POST', '/register', { sub: Object.assign({}, goodSub, { endpoint: 'https://fcm.googleapis.com/fcm/send/zzz' }) }); const reg2 = await r.json(); pushStatus = 410;
r = await call('POST', '/notify', { inbox: reg2.inbox, kind: 'call', from: 'Bob' }); ok(r.status === 404 && (await r.json()).gone && !store.has('i:' + reg2.inbox), '410 deletes inbox'); pushStatus = 201;
/* الحذف بالرمز */
r = await call('DELETE', '/inbox', { inbox: reg.inbox, token: 'wrong-token-wrong-tok' }); ok(r.status === 403 && store.has('i:' + reg.inbox), 'delete with wrong token forbidden');
r = await call('DELETE', '/inbox', { inbox: reg.inbox, token: reg.token }); ok(r.status === 200 && !store.has('i:' + reg.inbox), 'delete with token');
/* تحديد التسجيل لكل IP */
let reg429 = false; for (let i = 0; i < 25; i++) { r = await call('POST', '/register', { sub: goodSub }, { 'CF-Connecting-IP': '9.9.9.9' }); if (r.status === 429) reg429 = true; } ok(reg429, 'register rate limit per IP');
/* خادم غير مهيأ */
r = await worker.fetch(new Request('https://x.dev/notify', { method: 'POST', body: '{}' }), {}); ok(r.status === 500, 'unconfigured');
r = await call('POST', '/notify', { pad: 'x'.repeat(5000) }); ok(r.status === 413, 'oversized body');
globalThis.fetch = realFetch;
console.log(fail ? `❌ ${fail} فشل، ${pass} نجاح` : `✅ كل الاختبارات نجحت (${pass})`); process.exit(fail ? 1 : 0);
