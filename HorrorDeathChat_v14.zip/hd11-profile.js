/* ============================================================
   HD Chat v11 — الملف الشخصي الموسّع
   غلاف · إطارات صورة · ألوان وتدرجات · سمات بطاقة · نبذة واقتباس ·
   وسوم · هوايات · روابط (تُفحص) · معرض ملصقات · أوسمة · إحصاءات
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD || !HD.social) return;
    const { g, el, ls, note, icon, iconBtn, sheet, section, row, toggle, select, button } = HD;
    const SO = HD.social, me = SO.me, STATUS = SO.STATUS, clip = SO.clip;
    const IMG_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/, HEX = /^#[0-9a-fA-F]{6}$/;
    const hex = (v, d) => (typeof v === 'string' && HEX.test(v) ? v : d);
    const jget = (k, d) => { try { const v = JSON.parse(ls.get(k, '')); return v == null ? d : v; } catch (e) { return d; } };

    /* ── الأغلفة (12 تدرجاً/مشهداً مرسوماً بـ CSS) ── */
    const COVERS = [
        ['ليل القمر', 'radial-gradient(circle at 82% 24%, #fef9c3 0 5%, rgba(254,249,195,.25) 6% 11%, transparent 12%), linear-gradient(180deg,#0b1020,#312e81)'],
        ['دماء', 'radial-gradient(ellipse at 50% 120%, #dc2626, transparent 60%), linear-gradient(180deg,#1c0505,#450a0a)'],
        ['مقبرة الضباب', 'linear-gradient(180deg,#0c0a09 0%,#292524 55%,#57534e 100%)'],
        ['غابة سوداء', 'radial-gradient(ellipse at 20% 100%, #166534, transparent 55%), linear-gradient(180deg,#022c22,#052e16)'],
        ['سديم بنفسجي', 'radial-gradient(circle at 30% 30%, #a855f7, transparent 45%), radial-gradient(circle at 75% 70%, #ec4899, transparent 45%), #1e1b4b'],
        ['جمر', 'radial-gradient(ellipse at 50% 130%, #f97316, transparent 60%), linear-gradient(180deg,#1c0a02,#7c2d12)'],
        ['جليد', 'linear-gradient(135deg,#0c4a6e,#38bdf8 55%,#e0f2fe)'],
        ['فجر مظلم', 'linear-gradient(180deg,#1e1b4b,#9d174d 60%,#f97316)'],
        ['سم أخضر', 'radial-gradient(circle at 70% 30%, #84cc16, transparent 50%), linear-gradient(135deg,#1a2e05,#365314)'],
        ['فراغ', 'radial-gradient(circle at 50% 50%, #27272a, #000 70%)'],
        ['خطوط حمراء', 'repeating-linear-gradient(115deg,#0c0a09 0 14px,#450a0a 14px 17px)'],
        ['ذهب قديم', 'linear-gradient(135deg,#292524,#a16207 50%,#fde68a)']
    ];
    const THEMES = [
        ['ظلام', '#12100f', '#d6d3d1', '#292524'], ['دماء', '#1c0707', '#f1c9c9', '#4a1212'], ['ليل أزرق', '#0a1020', '#c7d2fe', '#1e2a52'], ['غابة', '#07140b', '#bbf7d0', '#14391d'],
        ['بنفسجي', '#120a1f', '#e9d5ff', '#35195e'], ['ورق قديم', '#f3ead3', '#44403c', '#d6c7a1'], ['جليد', '#e8f1f8', '#0f172a', '#b6cde0'], ['جمر', '#1c0f05', '#fed7aa', '#5a2e0a']
    ];
    const ACC = ['#b91c1c', '#dc2626', '#f97316', '#f59e0b', '#eab308', '#84cc16', '#22c55e', '#14b8a6', '#06b6d4', '#38bdf8', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899', '#e5e5e5'];
    const TITLES = ['حارس المقبرة', 'صائد الأرواح', 'ملك الظلام', 'راوي الليل', 'ساحر الضباب', 'الناجي الأخير', 'عين الغراب', 'صوت من الجحيم'];
    const FRAMES = ['بدون', 'حلقة', 'تدرّج', 'مزدوج', 'متقطع', 'توهّج', 'هالة دوّارة', 'نار'];
    const BADGES = [
        ['first', 'أول كلمة', 'ghost', 'أرسل رسالتك الأولى', (s) => s.msgs >= 1], ['talker', 'ثرثار الظلام', 'bat', 'أرسل 100 رسالة', (s) => s.msgs >= 100],
        ['legend', 'أسطورة الليل', 'skull', 'أرسل 1000 رسالة', (s) => s.msgs >= 1000], ['owl', 'بومة الليل', 'owl', 'اكتب بين منتصف الليل والخامسة فجراً', (s) => s.owl],
        ['story', 'راوي القصص', 'spellbook', 'انشر 3 ستوريات', (s) => s.storiesTotal >= 3], ['stk', 'عاشق الملصقات', 'mask', 'استخدم 25 ملصقاً', (s) => s.stk >= 25],
        ['vet', 'مقيم قديم', 'castle', 'ابقَ 7 أيام', (s) => s.days >= 7], ['caller', 'صوت الظلام', 'bell', 'ابدأ 5 مكالمات', (s) => s.calls >= 5],
        ['safe', 'محصَّن', 'tomb', 'درجة حماية 80 فأكثر', (s) => s.safe >= 80]
    ];
    const BADGE_IDS = new Set(BADGES.map((b) => b[0]));
    const DEF = { bio: '', mood: '', status: 'online', color: '#b91c1c', color2: '#7c3aed', av: '', cover: 0, coverImg: '', frame: 0, nameColor: '', title: '', quote: '', tags: [], links: [], fav: { song: '', game: '', movie: '', food: '' }, showcase: [], theme: 0, badges: [], shareStats: true, stats: null };

    /* ── التحقق من ملف قادم من الغير (لا نثق بأي حقل) ── */
    function cleanLink(l) {
        if (!l || typeof l !== 'object') return null; const t = clip(l.t, 20); let u; try { u = new URL(String(l.u || '')); } catch (e) { return null; }
        if (u.protocol !== 'https:' || u.username || u.password || String(l.u).length > 200) return null; return { t: t || u.hostname, u: u.href };
    }
    function clean(o) {
        const p = Object.assign({}, DEF); if (!o || typeof o !== 'object') return p;
        p.bio = clip(o.bio, 300); p.mood = clip(o.mood, 40); p.title = clip(o.title, 24); p.quote = clip(o.quote, 120);
        p.status = STATUS[o.status] ? o.status : 'online'; p.color = hex(o.color, DEF.color); p.color2 = hex(o.color2, DEF.color2); p.nameColor = hex(o.nameColor, '');
        p.av = (typeof o.av === 'string' && o.av.length < 32000 && IMG_RE.test(o.av)) ? o.av : '';
        p.coverImg = (typeof o.coverImg === 'string' && o.coverImg.length < 64000 && IMG_RE.test(o.coverImg)) ? o.coverImg : '';
        p.cover = Number.isInteger(o.cover) && o.cover >= 0 && o.cover < COVERS.length ? o.cover : 0; p.frame = Number.isInteger(o.frame) && o.frame >= 0 && o.frame < FRAMES.length ? o.frame : 0;
        p.theme = Number.isInteger(o.theme) && o.theme >= 0 && o.theme < THEMES.length ? o.theme : 0;
        p.tags = Array.isArray(o.tags) ? o.tags.slice(0, 8).map((x) => clip(x, 16)).filter(Boolean) : [];
        p.links = Array.isArray(o.links) ? o.links.slice(0, 4).map(cleanLink).filter(Boolean) : [];
        const f = o.fav && typeof o.fav === 'object' ? o.fav : {}; p.fav = { song: clip(f.song, 40), game: clip(f.game, 40), movie: clip(f.movie, 40), food: clip(f.food, 40) };
        p.showcase = Array.isArray(o.showcase) ? o.showcase.filter((k) => typeof k === 'string' && HD.stickers.ST[k]).slice(0, 6) : [];
        p.badges = Array.isArray(o.badges) ? o.badges.filter((k) => BADGE_IDS.has(k)).slice(0, 12) : []; p.shareStats = o.shareStats !== false;
        if (p.shareStats && o.stats && typeof o.stats === 'object') { const n = (v) => (Number.isFinite(v) ? Math.max(0, Math.min(9999999, Math.floor(v))) : 0); p.stats = { m: n(o.stats.m), d: n(o.stats.d), c: n(o.stats.c), k: n(o.stats.k) }; } else p.stats = null;
        return p;
    }
    HD.prof = { clean, COVERS, THEMES, BADGES };

    /* ── الإحصاءات المحلية ── */
    if (!ls.get('hx11_since', '')) ls.set('hx11_since', String(Date.now()));
    const num = (k) => +ls.get(k, '0') || 0;
    let lastStories = me.stories.length;
    function bump(k, n) { ls.set(k, String(num(k) + (n || 1))); }
    const _sb = sendBroadcastMessage;
    sendBroadcastMessage = function () { const i = g('msg-input'), had = !!(i && i.value.trim()); _sb(); if (had && i && i.value === '') { bump('hx11_stat_msgs'); const h = new Date().getHours(); if (h < 5) ls.set('hx11_owl', '1'); } };
    if (HD.call && HD.call.start) { const _cs = HD.call.start; HD.call.start = function () { try { if (!(HD.call.state && HD.call.state.active)) bump('hx11_stat_calls'); } catch (e) {} return _cs.apply(this, arguments); }; }
    setInterval(() => { const n = me.stories.length; if (n > lastStories) bump('hx11_stat_stories', n - lastStories); lastStories = n; }, 2000);
    function stats() {
        let safe = 0; try { safe = HD.guard ? HD.guard.score().pts : 0; } catch (e) {}
        return { msgs: num('hx11_stat_msgs'), stk: num('hx11_stat_stk'), calls: num('hx11_stat_calls'), storiesTotal: num('hx11_stat_stories'), days: Math.floor((Date.now() - num('hx11_since')) / 86400000) + 1, owl: ls.get('hx11_owl', '') === '1', safe };
    }
    const earned = () => { const s = stats(); return BADGES.filter((b) => b[4](s)).map((b) => b[0]); };

    /* ── حفظ وتحميل ── */
    function load() { const saved = jget('hx11_prof', {}); Object.assign(me.prof, clean(Object.assign({}, DEF, saved, { av: saved.av || me.prof.av }))); }
    function persist() {
        me.prof.badges = earned(); const s = stats(); me.prof.stats = me.prof.shareStats ? { m: s.msgs, d: s.days, c: s.calls, k: s.stk } : null;
        SO.saveProf(); return JSON.stringify(me.prof).length;
    }
    load();
    setInterval(() => { try { me.prof.badges = earned(); } catch (e) {} }, 15000);

    /* ── بطاقة الملف الشخصي (تُستخدم في المعاينة وعرض الآخرين) ── */
    function card(prof, name, opts) {
        opts = opts || {}; const p = prof, th = THEMES[p.theme] || THEMES[0], c = el('div', 'hx11-pcard'); c.style.setProperty('--pc-bg', th[1]); c.style.setProperty('--pc-tx', th[2]); c.style.setProperty('--pc-ln', th[3]); c.style.setProperty('--pc-ac', p.color);
        const cover = el('div', 'hx11-pcover'); cover.style.background = p.coverImg ? 'center / cover no-repeat url("' + p.coverImg + '")' : (COVERS[p.cover] || COVERS[0])[1]; c.appendChild(cover);
        const head = el('div', 'hx11-phead'); head.appendChild(SO.avatar(p, name, 92, { status: true, ring: opts.ring || null })); const id = el('div', 'hx11-pid');
        const nm = el('b', 'hx11-pname', name); if (p.nameColor) nm.style.color = p.nameColor; id.appendChild(nm);
        if (p.title) { const t = el('span', 'hx11-ptitle', p.title); t.style.background = 'linear-gradient(90deg,' + p.color + ',' + p.color2 + ')'; id.appendChild(t); }
        const stt = el('small', 'hx11-pstat', (STATUS[p.status] || STATUS.online)[0]); id.appendChild(stt); head.appendChild(id); c.appendChild(head);
        if (opts.idBadge) c.appendChild(opts.idBadge);
        if (p.mood) c.appendChild(el('div', 'hx11-pmood', '«' + p.mood + '»'));
        if (p.bio) { c.appendChild(el('div', 'hx11-plabel', 'نبذة')); c.appendChild(el('div', 'hx11-pbio', p.bio)); }
        if (p.quote) { const q = el('blockquote', 'hx11-pquote', p.quote); c.appendChild(q); }
        if (p.tags.length) { const w = el('div', 'hx11-ptags'); p.tags.forEach((t) => { const x = el('span', 'hx11-ptag', '#' + t); w.appendChild(x); }); c.appendChild(w); }
        const fv = [['song', 'أغنيتي'], ['game', 'لعبتي'], ['movie', 'فيلمي'], ['food', 'أكلتي']].filter(([k]) => p.fav[k]); if (fv.length) { c.appendChild(el('div', 'hx11-plabel', 'المفضّلات')); const gd = el('div', 'hx11-pfav'); fv.forEach(([k, l]) => { const r = el('div'); r.appendChild(el('small', '', l)); r.appendChild(el('b', '', p.fav[k])); gd.appendChild(r); }); c.appendChild(gd); }
        if (p.showcase.length) { c.appendChild(el('div', 'hx11-plabel', 'معرض ملصقاتي')); const sh = el('div', 'hx11-pshow'); p.showcase.forEach((k) => { const t = HD.stickers.node(k, 46); sh.appendChild(t); }); c.appendChild(sh); }
        if (p.badges.length) { c.appendChild(el('div', 'hx11-plabel', 'الأوسمة')); const bw = el('div', 'hx11-pbadges'); BADGES.filter((b) => p.badges.includes(b[0])).forEach((b) => { const x = el('div', 'hx11-pbadge'); x.title = b[3]; x.appendChild(HD.stickers.svg(b[2], 28)); x.appendChild(el('small', '', b[1])); bw.appendChild(x); }); c.appendChild(bw); }
        if (p.stats) { const s = el('div', 'hx11-pstats'); [['رسائل', p.stats.m], ['أيام', p.stats.d], ['مكالمات', p.stats.c], ['ملصقات', p.stats.k]].forEach(([l, v]) => { const x = el('div'); x.appendChild(el('b', '', String(v))); x.appendChild(el('small', '', l)); s.appendChild(x); }); c.appendChild(s); }
        if (p.links.length) { c.appendChild(el('div', 'hx11-plabel', 'روابطي')); const lw = el('div', 'hx11-plinks'); p.links.forEach((l) => { const a = el('a', 'hx11-plink'); a.href = l.u; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow'; a.appendChild(icon('link', 14)); a.appendChild(el('span', '', l.t)); lw.appendChild(a); }); c.appendChild(lw); }
        return c;
    }

    /* ── المحرّر الكبير ── */
    let draftTimer = null;
    function openEditor(startTab) {
        if (typeof currentUser === 'undefined' || !currentUser) return; load();
        const w = sheet('ملفي الشخصي', (b) => {
            const pv = el('div', 'hx11-pvwrap'); b.appendChild(pv); const repaint = () => { pv.textContent = ''; pv.appendChild(card(me.prof, currentUser.username, {})); };
            const touch = () => { clearTimeout(draftTimer); draftTimer = setTimeout(repaint, 120); };
            const tabs = el('div', 'hx11-tabs scroll'); const body = el('div', 'hx11-hubbody'); b.appendChild(tabs); b.appendChild(body);
            const P = me.prof, inp = (ph, key, max, mem) => { const i = el('input', 'hx-input'); i.placeholder = ph; i.maxLength = max; i.value = (mem || P)[key] || ''; i.oninput = () => { (mem || P)[key] = clip(i.value, max); touch(); }; return i; };
            const swatches = (list, cur, on, cls) => { const w2 = el('div', 'hx11-accs'); list.forEach((c) => { const x = el('button', 'hx11-acc' + (cur() === c ? ' on' : '')); x.type = 'button'; x.style.background = c; x.setAttribute('aria-label', c); x.onclick = () => { on(c); w2.querySelectorAll('.hx11-acc').forEach((y) => y.classList.remove('on')); x.classList.add('on'); touch(); }; w2.appendChild(x); }); return w2; };
            const colorIn = (get, on) => { const i = el('input'); i.type = 'color'; i.className = 'hx11-colorin'; i.value = hex(get(), '#b91c1c'); i.oninput = () => { on(i.value); touch(); }; return i; };
            const panels = {
                basic(x) {
                    const head = el('div', 'hx11-prof-head'); const avBox = el('div'); const drawAv = () => { avBox.textContent = ''; avBox.appendChild(SO.avatar(P, currentUser.username, 84, { status: true })); }; drawAv();
                    const side = el('div', 'hx11-prof-side'); const file = el('input'); file.type = 'file'; file.accept = 'image/*'; file.style.display = 'none';
                    file.onchange = () => { const f = file.files[0]; file.value = ''; if (!f) return; SO.squareAvatar(f, (d) => { if (!d) { note('تعذّر تجهيز الصورة'); return; } P.av = d; try { localStorage.setItem('horror_avatar_' + currentUser.username, d); } catch (e) {} drawAv(); touch(); }); };
                    const pick = el('button', 'hx11-chipbtn', 'تغيير الصورة'); pick.type = 'button'; pick.onclick = () => file.click(); const rm = el('button', 'hx11-chipbtn', 'إزالة'); rm.type = 'button'; rm.onclick = () => { P.av = ''; drawAv(); touch(); };
                    side.appendChild(el('b', '', currentUser.username)); const ac = el('div', 'hx11-inline'); ac.appendChild(pick); ac.appendChild(rm); side.appendChild(ac); head.appendChild(avBox); head.appendChild(side); x.appendChild(head); x.appendChild(file);
                    row(x, 'حالتي', select(Object.entries(STATUS).map(([k, v]) => [k, v[0]]), P.status, (v) => { P.status = v; drawAv(); touch(); }));
                    section(x, 'اللقب'); x.appendChild(inp('لقبك (مثال: حارس المقبرة)', 'title', 24)); const ch = el('div', 'hx11-chips'); TITLES.forEach((t) => { const c = el('button', 'hx11-chipbtn', t); c.type = 'button'; c.onclick = () => { P.title = t; panels.basic && go('basic'); touch(); }; ch.appendChild(c); }); x.appendChild(ch);
                    section(x, 'مزاجي الآن'); x.appendChild(inp('ماذا يدور في رأسك؟', 'mood', 40));
                    section(x, 'نبذة عني'); const bio = el('textarea', 'hx-input hx11-ta'); bio.rows = 4; bio.maxLength = 300; bio.placeholder = 'اكتب عن نفسك (حتى 300 حرف)'; bio.value = P.bio; const cn = el('small', 'hx-muted', P.bio.length + '/300'); bio.oninput = () => { P.bio = clip(bio.value, 300); cn.textContent = P.bio.length + '/300'; touch(); }; x.appendChild(bio); x.appendChild(cn);
                },
                look(x) {
                    section(x, 'الغلاف'); const cg = el('div', 'hx11-covers'); COVERS.forEach(([n, bg], i) => { const c = el('button', 'hx11-cvbtn' + (!P.coverImg && P.cover === i ? ' on' : '')); c.type = 'button'; c.style.background = bg; c.title = n; c.setAttribute('aria-label', n); c.appendChild(el('small', '', n)); c.onclick = () => { P.cover = i; P.coverImg = ''; cg.querySelectorAll('.hx11-cvbtn').forEach((y) => y.classList.remove('on')); c.classList.add('on'); touch(); }; cg.appendChild(c); }); x.appendChild(cg);
                    const file = el('input'); file.type = 'file'; file.accept = 'image/*'; file.style.display = 'none'; file.onchange = () => { const f = file.files[0]; file.value = ''; if (!f) return; SO.compress(f, 800, 58000, (d) => { if (!d) { note('الصورة كبيرة أو غير مدعومة'); return; } P.coverImg = d; go('look'); touch(); }); };
                    const up = el('button', 'hx11-chipbtn', P.coverImg ? 'تغيير صورة الغلاف' : 'رفع صورة غلاف خاصة'); up.type = 'button'; up.onclick = () => file.click(); x.appendChild(up); x.appendChild(file);
                    if (P.coverImg) { const rm = el('button', 'hx11-chipbtn red', 'إزالة الصورة'); rm.type = 'button'; rm.onclick = () => { P.coverImg = ''; go('look'); touch(); }; x.appendChild(rm); }
                    section(x, 'إطار الصورة'); const fg = el('div', 'hx11-frames'); FRAMES.forEach((n, i) => { const c = el('button', 'hx11-frbtn' + (P.frame === i ? ' on' : '')); c.type = 'button'; c.appendChild(SO.avatar({ av: P.av, color: P.color, color2: P.color2, frame: i }, currentUser.username, 40)); c.appendChild(el('small', '', n)); c.onclick = () => { P.frame = i; fg.querySelectorAll('.hx11-frbtn').forEach((y) => y.classList.remove('on')); c.classList.add('on'); touch(); }; fg.appendChild(c); }); x.appendChild(fg);
                    section(x, 'اللون الأساسي'); const a1 = swatches(ACC, () => P.color, (c) => { P.color = c; }); a1.appendChild(colorIn(() => P.color, (c) => { P.color = c; })); x.appendChild(a1);
                    section(x, 'اللون الثاني (للتدرّج)'); const a2 = swatches(ACC, () => P.color2, (c) => { P.color2 = c; }); a2.appendChild(colorIn(() => P.color2, (c) => { P.color2 = c; })); x.appendChild(a2);
                    section(x, 'لون اسمي'); const a3 = swatches(['#ffffff'].concat(ACC.slice(0, 15)), () => P.nameColor, (c) => { P.nameColor = c; }); const nn = el('button', 'hx11-chipbtn', 'الافتراضي'); nn.type = 'button'; nn.onclick = () => { P.nameColor = ''; a3.querySelectorAll('.hx11-acc').forEach((y) => y.classList.remove('on')); touch(); }; a3.appendChild(nn); x.appendChild(a3);
                    section(x, 'سمة البطاقة'); const tg = el('div', 'hx11-themes'); THEMES.forEach(([n, bg, tx, ln], i) => { const c = el('button', 'hx11-theme' + (P.theme === i ? ' on' : '')); c.type = 'button'; c.style.background = bg; c.style.borderColor = ln; const t = el('span', '', n); t.style.color = tx; c.appendChild(t); c.onclick = () => { P.theme = i; tg.querySelectorAll('.hx11-theme').forEach((y) => y.classList.remove('on')); c.classList.add('on'); touch(); }; tg.appendChild(c); }); x.appendChild(tg);
                },
                details(x) {
                    section(x, 'اقتباس يمثّلني'); x.appendChild(inp('جملة تحبها (120 حرفاً)', 'quote', 120));
                    section(x, 'وسوم (حتى 8)'); const tw = el('div', 'hx11-ptags edit'); const drawT = () => { tw.textContent = ''; P.tags.forEach((t, i) => { const c = el('button', 'hx11-ptag', '#' + t + ' ✕'); c.type = 'button'; c.onclick = () => { P.tags.splice(i, 1); drawT(); touch(); }; tw.appendChild(c); }); }; drawT(); x.appendChild(tw);
                    const ti = el('input', 'hx-input'); ti.placeholder = 'اكتب وسماً ثم Enter'; ti.maxLength = 16; ti.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); const v = clip(ti.value.replace(/^#/, ''), 16); if (v && P.tags.length < 8 && !P.tags.includes(v)) { P.tags.push(v); ti.value = ''; drawT(); touch(); } } }; x.appendChild(ti);
                    section(x, 'مفضّلاتي'); [['أغنيتي', 'song'], ['لعبتي', 'game'], ['فيلمي', 'movie'], ['أكلتي', 'food']].forEach(([l, k]) => { const i = inp(l, k, 40, P.fav); x.appendChild(i); });
                    section(x, 'روابطي (https فقط، حتى 4)'); x.appendChild(el('p', 'hx-muted', 'تُفحص الروابط قبل أن يفتحها أي شخص، وتُحجب الروابط المشبوهة.'));
                    for (let k = 0; k < 4; k++) { const r = el('div', 'hx11-linkrow'); const t = el('input', 'hx-input'); t.placeholder = 'العنوان'; t.maxLength = 20; t.value = (P.links[k] && P.links[k].t) || ''; const u = el('input', 'hx-input'); u.placeholder = 'https://...'; u.dir = 'ltr'; u.value = (P.links[k] && P.links[k].u) || '';
                        const sync = () => { const items = []; x.querySelectorAll('.hx11-linkrow').forEach((rw) => { const [a, bb] = rw.querySelectorAll('input'); const l = cleanLink({ t: a.value, u: bb.value }); bb.classList.toggle('bad', !!bb.value && !l); if (l) items.push(l); }); P.links = items; touch(); };
                        t.oninput = sync; u.oninput = sync; r.appendChild(t); r.appendChild(u); x.appendChild(r); }
                },
                showcase(x) {
                    x.appendChild(el('p', 'hx-muted', 'اختر حتى 6 ملصقات تظهر في بطاقتك (' + HD.stickers.NAMES.length + ' ملصقاً).'));
                    const cnt = el('b', 'hx11-count2', P.showcase.length + '/6'); x.appendChild(cnt); const gr = el('div', 'hx11-stgrid');
                    HD.stickers.NAMES.forEach((n) => { const bt = el('button', 'hx11-stbtn' + (P.showcase.includes(n) ? ' sel' : '')); bt.type = 'button'; bt.title = HD.stickers.ST[n][0]; bt.appendChild(HD.stickers.svg(n, 44));
                        bt.onclick = () => { const i = P.showcase.indexOf(n); if (i >= 0) P.showcase.splice(i, 1); else if (P.showcase.length < 6) P.showcase.push(n); else { note('الحد الأقصى 6 ملصقات'); return; } bt.classList.toggle('sel', P.showcase.includes(n)); cnt.textContent = P.showcase.length + '/6'; touch(); }; gr.appendChild(bt); }); x.appendChild(gr);
                },
                stats(x) {
                    const s = stats(), grid = el('div', 'hx11-pstats big'); [['رسائل', s.msgs], ['ملصقات', s.stk], ['مكالمات', s.calls], ['ستوريات', s.storiesTotal], ['أيام', s.days], ['حماية', s.safe]].forEach(([l, v]) => { const d = el('div'); d.appendChild(el('b', '', String(v))); d.appendChild(el('small', '', l)); grid.appendChild(d); }); x.appendChild(grid);
                    row(x, 'مشاركة إحصائياتي مع المتصلين', toggle(P.shareStats, (v) => { P.shareStats = v; touch(); }), 'يرى الآخرون رسائلك وأيامك ومكالماتك وملصقاتك.');
                    section(x, 'الأوسمة'); const have = new Set(earned()), bg = el('div', 'hx11-pbadges big');
                    BADGES.forEach((bd) => { const ok = have.has(bd[0]), d = el('div', 'hx11-pbadge' + (ok ? '' : ' lock')); d.appendChild(HD.stickers.svg(bd[2], 36)); d.appendChild(el('b', '', bd[1])); d.appendChild(el('small', '', ok ? '✓ حصلت عليه' : bd[3])); bg.appendChild(d); }); x.appendChild(bg);
                }
            };
            const TABS = [['basic', 'الأساسي', 'users'], ['look', 'المظهر', 'palette'], ['details', 'التفاصيل', 'quote'], ['showcase', 'المعرض', 'smile'], ['stats', 'الأوسمة والإحصاء', 'shield']];
            function go(id) { tabs.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x.dataset.t === id)); body.textContent = ''; panels[id](body); }
            TABS.forEach(([id, label, ic]) => { const x = el('button'); x.type = 'button'; x.dataset.t = id; x.appendChild(icon(ic, 15)); x.appendChild(el('span', '', label)); x.onclick = () => go(id); tabs.appendChild(x); });
            repaint(); go(startTab || 'basic');
            const bar = el('div', 'hx11-savebar'); bar.appendChild(el('span', 'hx-muted', 'التغييرات تُرى في المعاينة أعلاه، ولا تُنشر إلا بعد الحفظ.'));
            const sv = el('button', 'hx-btn hx11-btn'); sv.type = 'button'; sv.appendChild(icon('check', 16)); sv.appendChild(el('span', '', 'حفظ ونشر للمتصلين'));
            sv.onclick = () => { let n = persist(); if (n > 175000) { me.prof.coverImg = ''; n = persist(); note('الملف كبير جداً فأُزيلت صورة الغلاف'); } SO.sendAll('prof', me.prof); const sw = g('hx-sheet'); if (sw) sw.remove(); note('تم حفظ ملفك الشخصي ونشره'); if (g('hx11-people')) SO.renderPeople(g('hx11-people')); };
            bar.appendChild(sv); b.appendChild(bar);
        }, { wide: true });
        const bx = w.querySelector('.hx11-box'); if (bx) bx.classList.add('huge');
    }

    /* ── عرض ملف شخص آخر ── */
    function openPeer(pid) {
        const d = SO.peersData[pid], c = activeConnections[pid], name = (peerNames && peerNames[pid]) || 'مجهول'; if (!c) { note('هذا المستخدم غير متصل الآن'); return; }
        const prof = (d && d.prof && d.prof.bio !== undefined) ? clean(d.prof) : clean({}); if (d && d.prof && d.prof.av) prof.av = d.prof.av;
        const w = sheet(name, (b) => {
            let idb = null; const s = c.__hd || {}; if (s.idState) { const map = { trusted: ['هوية موثوقة ✓', 'ok'], new: ['هوية جديدة', 'warn'], changed: ['تغيّرت هويته!', 'bad'], none: ['بلا هوية موقَّعة', 'bad'] }[s.idState]; if (map) { idb = el('div', 'hx11-idb ' + map[1]); idb.appendChild(icon('shield', 14)); idb.appendChild(el('span', '', map[0])); } }
            const wrap = el('div', 'hx11-hubbody'); b.appendChild(wrap); const ring = d && d.stories && d.stories.length ? (SO.unseenCount(pid) ? 'new' : 'seen') : null; wrap.appendChild(card(prof, name, { ring, idBadge: idb }));
            const acts = el('div', 'hx11-pacts');
            if (d && d.stories.length) button(acts, 'ستوري (' + d.stories.length + ')', () => { const x = g('hx-sheet'); if (x) x.remove(); SO.openStories(pid); }, 'spot');
            button(acts, 'رسالة خاصة', () => { const x = g('hx-sheet'); if (x) x.remove(); try { openPrivateChatWith(name); } catch (e) {} }, 'send');
            button(acts, 'إشارة', () => { const x = g('hx-sheet'); if (x) x.remove(); const i = g('msg-input'); i.value += (i.value && !/\s$/.test(i.value) ? ' ' : '') + '@' + name + ' '; i.focus(); }, 'users');
            button(acts, 'فيديو', () => { const x = g('hx-sheet'); if (x) x.remove(); HD.call.start('video', [pid]); }, 'video'); button(acts, 'صوت', () => { const x = g('hx-sheet'); if (x) x.remove(); HD.call.start('audio', [pid]); }, 'phone');
            if (HD.guard) button(acts, 'حظر', () => { if (confirm('حظر «' + name + '» وقطع الاتصال به؟')) { HD.guard.block(name); try { c.close(); } catch (e) {} const x = g('hx-sheet'); if (x) x.remove(); note('تم الحظر'); } }, 'ban', 'danger');
            wrap.appendChild(acts);
        }, { wide: true });
        const bx = w.querySelector('.hx11-box'); if (bx) bx.classList.add('huge');
    }
    SO.openMyProfile = () => openEditor('basic'); SO.openPeerProfile = openPeer; SO.openProfileTab = openEditor; HD.prof.card = card;
})();
