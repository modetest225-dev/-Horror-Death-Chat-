/* ============================================================
   HD Chat — Service Worker v14: يعمل الموقع بلا إنترنت بعد أول زيارة
   - الملفات المحلية + الموسيقى: تُخزَّن عند التثبيت.
   - المكتبات الخارجية (Tailwind, Font Awesome, الخطوط, PeerJS): تُخزَّن مرة واحدة وتبقى.
   - الإشعارات: عبر showNotification + استقبال Push.
   ============================================================ */
const LOCAL = 'hdc-v14', CDN = 'hdc-cdn-v1';
const SHELL = ['./', 'index.html', 'style.css?v=14', 'hd11.css?v=14', 'app.js?v=14', 'hd11-core.js?v=14', 'hd11-guard.js?v=14', 'hd11-free.js?v=14', 'hd11-theme.js?v=14', 'hd11-stickers.js?v=14', 'hd11-stickers2.js?v=14', 'hd11-call.js?v=14', 'hd11-write.js?v=14', 'hd11-social.js?v=14', 'hd11-profile.js?v=14', 'push-config.js?v=14', 'hd11-hub.js?v=14', 'hd11-push.js?v=14', 'hd11-offline.js?v=14', 'manifest.json', 'assets/notif/hd-carved-192.png', 'assets/notif/hd-badge-96.png', 'assets/music/endless-darkness.mp3', 'assets/icons/icon-192.png'];
const CDN_URLS = [
    'https://cdn.tailwindcss.com',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
    'https://fonts.googleapis.com/css2?family=Amiri:ital@1&family=Courier+Prime&family=Cinzel+Decorative:wght@700;900&display=swap',
    'https://unpkg.com/peerjs@1.5.2/dist/peerjs.min.js',
    'https://api.dicebear.com/7.x/bottts/svg?seed=horror'
];
const CDN_HOSTS = ['cdn.tailwindcss.com', 'cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com', 'unpkg.com', 'api.dicebear.com'];
let notificationsEnabled = false;

/* ── تخزين مورد خارجي (نفضّل CORS لتجنّب الاستجابات المبهمة الثقيلة) ── */
async function putCdn(cache, url) {
    try { const r = await fetch(url, { mode: 'cors', credentials: 'omit' }); if (r && r.ok) { await cache.put(url, r.clone()); return r; } } catch (e) {}
    try { const r = await fetch(new Request(url, { mode: 'no-cors' })); if (r) { await cache.put(url, r.clone()); return r; } } catch (e) {}
    return null;
}
async function precacheCdn() {
    const cache = await caches.open(CDN), done = [];
    for (const u of CDN_URLS) {
        let r = await cache.match(u); if (!r) r = await putCdn(cache, u); if (!r) continue; done.push(u);
        if (/\.css(\?|$)|css2\?/.test(u) && r.type !== 'opaque') {
            let txt = ''; try { txt = await r.clone().text(); } catch (e) {}
            const fonts = [...new Set([...txt.matchAll(/url\(\s*['"]?([^)'"]+)['"]?\s*\)/g)].map((m) => { try { return new URL(m[1], u).href; } catch (e) { return ''; } }).filter((x) => /\.woff2(\?|$)/.test(x) || /fonts\.gstatic\.com/.test(x)))];
            for (const f of fonts) { if (!(await cache.match(f))) await putCdn(cache, f); }
        }
    }
    return done;
}
const FALLBACK_AVATAR = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#1c1917"/><path d="M32 12C21 12 15 20 15 29c0 6 2 9 6 11v6c0 2 1 3 3 3h16c2 0 3-1 3-3v-6c4-2 6-5 6-11 0-9-6-17-17-17z" fill="#e7e5e4"/><ellipse cx="25" cy="30" rx="4.5" ry="5.5" fill="#1c1917"/><ellipse cx="39" cy="30" rx="4.5" ry="5.5" fill="#1c1917"/><path d="M32 36l-3 5h6z" fill="#1c1917"/></svg>';

self.addEventListener('install', (e) => {
    e.waitUntil((async () => {
        const c = await caches.open(LOCAL); await Promise.allSettled(SHELL.map((u) => c.add(u)));
        precacheCdn().catch(() => {}); /* لا نعطّل التثبيت بانتظار الشبكة */
        await self.skipWaiting();
    })());
});
self.addEventListener('activate', (e) => {
    e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== LOCAL && k !== CDN).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

async function cdnHandler(req) {
    const cache = await caches.open(CDN); const hit = await cache.match(req.url);
    if (hit) { if (/cdn\.tailwindcss\.com/.test(req.url)) putCdn(cache, req.url).catch(() => {}); return hit; }
    const r = await putCdn(cache, req.url); if (r) return r;
    if (/api\.dicebear\.com/.test(req.url)) return new Response(FALLBACK_AVATAR, { headers: { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'no-store' } });
    return Response.error();
}
async function audioHandler(req, url) {
    const hit = await caches.match(url.pathname.slice(1)); if (!hit) return fetch(req);
    const buf = await hit.arrayBuffer(), rg = req.headers.get('range'), m = rg && /bytes=(\d+)-(\d*)/.exec(rg), H = { 'Content-Type': 'audio/mpeg', 'Accept-Ranges': 'bytes' };
    if (!m) return new Response(buf, { status: 200, headers: Object.assign({ 'Content-Length': String(buf.byteLength) }, H) });
    const a = +m[1], b = m[2] ? Math.min(+m[2], buf.byteLength - 1) : buf.byteLength - 1;
    return new Response(buf.slice(a, b + 1), { status: 206, headers: Object.assign({ 'Content-Range': 'bytes ' + a + '-' + b + '/' + buf.byteLength, 'Content-Length': String(b - a + 1) }, H) });
}
async function navHandler(req) {
    try {
        const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 4500);
        const r = await fetch(req, { signal: ctl.signal }); clearTimeout(t);
        if (r && r.ok) { const cp = r.clone(); caches.open(LOCAL).then((c) => c.put('index.html', cp)); return r; }
    } catch (e) {}
    return (await caches.match('index.html')) || (await caches.match('./')) || Response.error();
}
self.addEventListener('fetch', (e) => {
    const req = e.request; if (req.method !== 'GET') return; const url = new URL(req.url);
    if (url.origin === self.location.origin) {
        if (req.mode === 'navigate') { e.respondWith(navHandler(req)); return; }
        if (/\.mp3$/.test(url.pathname)) { e.respondWith(audioHandler(req, url)); return; }
        e.respondWith(caches.match(req).then((hit) => {
            const net = fetch(req).then((r) => { if (r && r.ok) { const cp = r.clone(); caches.open(LOCAL).then((c) => c.put(req, cp)); } return r; }).catch(() => hit);
            return hit || net;
        }));
        return;
    }
    if (CDN_HOSTS.includes(url.hostname)) e.respondWith(cdnHandler(req));
});
self.addEventListener('message', (e) => {
    const d = e.data || {};
    if (d.type === 'settings_update') notificationsEnabled = !!d.notificationsEnabled;
    else if (d.type === 'precache') { e.waitUntil(Promise.allSettled([caches.open(LOCAL).then((c) => Promise.allSettled(SHELL.map((u) => c.add(u)))), precacheCdn()]).then(() => { (e.source || { postMessage() {} }).postMessage({ type: 'precache_done' }); })); }
});
self.addEventListener('notificationclick', (e) => {
    const n = e.notification, action = e.action, data = n.data || {};
    n.close();
    e.waitUntil((async () => {
        const cs = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
        let c = cs.find((x) => 'focus' in x) || null;
        if (c) { try { await c.focus(); } catch (err) {} } else { try { c = await self.clients.openWindow(data.url || './'); } catch (err) {} }
        if (c && (action === 'answer' || action === 'decline')) c.postMessage({ type: 'notif_action', action, cid: data.cid, kind: data.kind });
    })());
});
self.addEventListener('push', (e) => {
    let d = {}; try { d = e.data ? e.data.json() : {}; } catch (err) { d = { b: e.data ? e.data.text() : '' }; }
    const title = d.t || d.title || '☣ Horror Death Chat', body = d.b || d.body || 'رسالة جديدة', kind = d.k || 'msg';
    e.waitUntil(self.registration.showNotification(title, { body, icon: 'assets/notif/hd-carved-192.png', badge: 'assets/notif/hd-badge-96.png', tag: d.tag || 'hdc-push', renotify: true, dir: 'rtl', lang: 'ar', vibrate: kind === 'call' ? [300, 150, 300, 150, 300] : [140, 70, 220], requireInteraction: kind === 'call', data: { url: './' } }));
});
