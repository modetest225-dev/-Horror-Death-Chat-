/* ============================================================
   HD Chat v11 — core: أدوات مشتركة + أيقونات SVG + تشفير طرفي كامل
   يُحمَّل بعد app.js. لا يعدّل app.js إلا عبر استبدال الدوال العامة.
   ============================================================ */
(function () {
    'use strict';
    const HD = (window.HD11 = window.HD11 || {});
    const g = (id) => document.getElementById(id);
    const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
    const ls = {
        get: (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
        set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} },
        del: (k) => { try { localStorage.removeItem(k); } catch (e) {} }
    };
    const note = (t) => { try { showLiveUpdate(t); } catch (e) { console.log(t); } };
    Object.assign(HD, { g, el, ls, note });

    /* ── أيقونات SVG مرسومة (بدل الإيموجي) ── */
    const P = {
        video: '<rect x="2" y="6" width="13" height="12" rx="2"/><path d="M15 10l6-3v10l-6-3z"/>',
        videoOff: '<path d="M3 3l18 18"/><path d="M7 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2v-1"/><path d="M15 10l6-3v10"/>',
        phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
        hangup: '<g transform="rotate(135 12 12)"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></g>',
        monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
        mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/>',
        micOff: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4M3 3l18 18"/>',
        shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
        lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
        palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 2-2s-1-1.5-1-2.5 1-1.5 2-1.5h2a4 4 0 0 0 4-4c0-4.5-4-8-9-8z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
        type: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
        x: '<path d="M5 5l14 14M19 5L5 19"/>',
        sliders: '<path d="M4 6h8M16 6h4M4 12h2M10 12h10M4 18h10M18 18h2"/><circle cx="14" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="18" r="2"/>',
        users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20a7 7 0 0 1 14 0"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14a5 5 0 0 1 5 5"/>',
        flip: '<path d="M20 11a8 8 0 0 0-14-4M4 4v4h4M4 13a8 8 0 0 0 14 4M20 20v-4h-4"/>',
        full: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
        pip: '<rect x="2" y="4" width="20" height="16" rx="2"/><rect x="12" y="12" width="8" height="6" rx="1" fill="currentColor"/>',
        rec: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.5" fill="currentColor"/>',
        hand: '<path d="M8 12V5.5a1.5 1.5 0 0 1 3 0V11M11 11V4a1.5 1.5 0 0 1 3 0v7M14 11V6a1.5 1.5 0 0 1 3 0v8a7 7 0 0 1-7 7c-3 0-4-2-6-5l-1-2a1.5 1.5 0 0 1 2.5-1.5L8 15"/>',
        grid: '<rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="3" width="8" height="8" rx="1"/><rect x="3" y="13" width="8" height="8" rx="1"/><rect x="13" y="13" width="8" height="8" rx="1"/>',
        spot: '<rect x="3" y="3" width="18" height="12" rx="1"/><rect x="3" y="17" width="5" height="4" rx="1"/><rect x="10" y="17" width="5" height="4" rx="1"/><rect x="17" y="17" width="4" height="4" rx="1"/>',
        mini: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M12 14h8v6h-8z" fill="currentColor"/>',
        smile: '<circle cx="12" cy="12" r="9"/><path d="M8 14a5 5 0 0 0 8 0M9 9.5h.01M15 9.5h.01"/>',
        search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
        plus: '<path d="M12 5v14M5 12h14"/>',
        check: '<path d="M5 12l5 5L20 7"/>',
        wand: '<path d="M4 20L16 8M14 6l4 4M19 3v4M17 5h4M6 4v3M4.5 5.5h3"/>',
        volume: '<path d="M4 10v4h4l5 4V6L8 10z"/><path d="M16 9a4 4 0 0 1 0 6"/>',
        key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>',
        clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
        bold: '<path d="M7 4h6a3.5 3.5 0 0 1 0 7H7zM7 11h7a3.5 3.5 0 0 1 0 9H7z"/>',
        italic: '<path d="M10 4h8M6 20h8M15 4L9 20"/>',
        code: '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5"/>',
        strike: '<path d="M4 12h16M8 7a4 4 0 0 1 8 0M8 17a4 4 0 0 0 8 0"/>',
        eyeOff: '<path d="M3 3l18 18M10.5 6.2A9 9 0 0 1 12 6c5 0 9 6 9 6a15 15 0 0 1-3 3.5M6.5 7.5A15 15 0 0 0 3 12s4 6 9 6a8 8 0 0 0 3-.6"/>',
        quote: '<path d="M5 17v-4a4 4 0 0 1 4-4M13 17v-4a4 4 0 0 1 4-4M5 17h4v-4H5zM13 17h4v-4h-4z"/>',
        mic2: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4M8 22h8"/>',
        panic: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
        link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
        send: '<path d="M3 11l18-8-8 18-2-8z"/>',
        template: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
        layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5M3 17.5l9 5 9-5"/>',
        globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
        ban: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
        camera: '<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="14" r="4"/>',
        chat: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/>',
        sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>'
    };
    function icon(name, size, cls) {
        const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size || 18); s.setAttribute('height', size || 18);
        s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.8');
        s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round'); s.setAttribute('aria-hidden', 'true');
        s.setAttribute('class', 'hx11-ico' + (cls ? ' ' + cls : ''));
        s.innerHTML = P[name] || ''; /* محتوى ثابت من الكود فقط */
        return s;
    }
    function iconBtn(name, title, onclick, cls) {
        const b = el('button', 'hx11-ib' + (cls ? ' ' + cls : '')); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title);
        b.appendChild(icon(name, 18)); if (onclick) b.addEventListener('click', (e) => { e.stopPropagation(); onclick(e); });
        return b;
    }
    Object.assign(HD, { icon, iconBtn, ICONS: P });

    /* ── نافذة سفلية/مركزية موحّدة ── */
    function sheet(title, build, opts) {
        const old = g('hx-sheet'); if (old) old.remove();
        const w = el('div', 'hx-sheet hx11-sheet'); w.id = 'hx-sheet';
        const box = el('div', 'hx-sheet-box hx11-box' + (opts && opts.wide ? ' wide' : ''));
        const head = el('div', 'hx-sheet-head'); head.appendChild(el('b', '', title));
        const x = el('button', 'hx-x'); x.type = 'button'; x.setAttribute('aria-label', 'إغلاق'); x.appendChild(icon('x', 16)); x.onclick = () => w.remove(); head.appendChild(x);
        box.appendChild(head); build(box, w); w.appendChild(box);
        w.addEventListener('click', (e) => { if (e.target === w) w.remove(); });
        document.body.appendChild(w); return w;
    }
    const section = (b, title) => { const h = el('div', 'hx11-sec', title); b.appendChild(h); return h; };
    const row = (b, label, ctrl, hint) => {
        const r = el('div', 'hx11-row'); const l = el('div', 'hx11-lbl'); l.appendChild(el('span', '', label)); if (hint) l.appendChild(el('small', '', hint));
        r.appendChild(l); r.appendChild(ctrl); b.appendChild(r); return r;
    };
    const toggle = (val, on) => {
        const t = el('button', 'hx11-tg' + (val ? ' on' : '')); t.type = 'button'; t.setAttribute('role', 'switch'); t.setAttribute('aria-checked', String(!!val));
        t.appendChild(el('i')); t.onclick = () => { const v = !t.classList.contains('on'); t.classList.toggle('on', v); t.setAttribute('aria-checked', String(v)); on(v); };
        return t;
    };
    const select = (opts, val, on) => {
        const s = el('select', 'hx11-sel'); opts.forEach(([v, t]) => { const o = el('option', '', t); o.value = v; if (String(v) === String(val)) o.selected = true; s.appendChild(o); });
        s.onchange = () => on(s.value); return s;
    };
    const button = (b, label, fn, ico, cls) => {
        const x = el('button', 'hx-btn hx11-btn' + (cls ? ' ' + cls : '')); x.type = 'button'; if (ico) x.appendChild(icon(ico, 16)); x.appendChild(el('span', '', label));
        x.onclick = fn; b.appendChild(x); return x;
    };
    Object.assign(HD, { sheet, section, row, toggle, select, button });

    /* ── مسجّل أنواع الحزم الجديدة (call_evt …) ── */
    const routes = {};
    HD.on = (type, fn) => { routes[type] = fn; };

    /* ============================================================
       التشفير الطرفي: ECDH P-256 (مفتاح مؤقت لكل اتصال) → HKDF → AES-256-GCM
       ============================================================ */
    const subtle = (window.crypto && crypto.subtle) || null;
    const te = new TextEncoder();
    const B64 = (buf) => { let s = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
    const UB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
    const JWK_RE = /^[A-Za-z0-9_-]{40,50}$/;
    const strict = () => ls.get('hx11_strict', '1') === '1';
    const MAX_CT = 200000;

    function newSess() {
        return { mode: 'pending', kp: null, pubJwk: null, theirKey: null, sendKey: null, recvKey: null, sendN: 0, recvN: 0, fp: null,
            queue: [], chain: Promise.resolve(), gotHello: false, helloSent: false, tokens: 600, last: Date.now(), viol: 0, verified: false, ready: null };
    }
    async function initKeys(s) {
        s.kp = await subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
        const j = await subtle.exportKey('jwk', s.kp.publicKey); s.pubJwk = { x: j.x, y: j.y };
    }
    function sess(conn) {
        if (!conn.__hd) { conn.__hd = newSess(); conn.__hd.ready = subtle ? initKeys(conn.__hd) : Promise.resolve(); }
        return conn.__hd;
    }
    async function derive(conn, s, theirJwk) {
        const pub = await subtle.importKey('jwk', { kty: 'EC', crv: 'P-256', x: theirJwk.x, y: theirJwk.y, ext: true }, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
        const bits = await subtle.deriveBits({ name: 'ECDH', public: pub }, s.kp.privateKey, 256);
        const mine = peer.id, theirs = conn.peer, lowIsMe = mine < theirs;
        const salt = await subtle.digest('SHA-256', te.encode([mine, theirs].sort().join('|')));
        const hk = await subtle.importKey('raw', bits, 'HKDF', false, ['deriveBits']);
        const okm = new Uint8Array(await subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info: te.encode('hdc11-e2e-v1') }, hk, 512));
        const k1 = okm.slice(0, 32), k2 = okm.slice(32);
        const imp = (k) => subtle.importKey('raw', k, 'AES-GCM', false, ['encrypt', 'decrypt']);
        s.sendKey = await imp(lowIsMe ? k1 : k2); s.recvKey = await imp(lowIsMe ? k2 : k1);
        const ks = [s.pubJwk.x + s.pubJwk.y, theirJwk.x + theirJwk.y].sort().join('');
        const h = new Uint8Array(await subtle.digest('SHA-256', te.encode('hdc11-fp|' + ks)));
        let big = 0n; for (let i = 0; i < 16; i++) big = (big << 8n) | BigInt(h[i]);
        const digits = big.toString().padStart(39, '0').slice(0, 30);
        s.fp = digits.match(/.{5}/g).join(' ');
    }
    HD._derive = derive; HD._sess = sess; HD._newSess = newSess;

    /* ── هوية الجهاز: مفتاح توقيع ECDSA ثابت (لا يُصدَّر) لكشف انتحال الأسماء ── */
    const idbOpen = () => new Promise((res, rej) => { const r = indexedDB.open('hdc11-id', 1); r.onupgradeneeded = () => r.result.createObjectStore('k'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
    HD.idFingerprint = async (pub) => {
        const h = new Uint8Array(await subtle.digest('SHA-256', te.encode('hdc11-ik|' + pub.x + '.' + pub.y))); let big = 0n; for (let i = 0; i < 16; i++) big = (big << 8n) | BigInt(h[i]);
        return big.toString().padStart(39, '0').slice(0, 25).match(/.{5}/g).join(' ');
    };
    async function loadIdentity(fresh) {
        if (!subtle) return; let kp = null, db = null; HD.idPersisted = false;
        try { db = await idbOpen(); if (!fresh) kp = await new Promise((res) => { const q = db.transaction('k').objectStore('k').get('id'); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); }); } catch (e) { db = null; }
        if (!kp || !kp.privateKey) {
            kp = await subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign', 'verify']);
            if (db) { try { await new Promise((res, rej) => { const tx = db.transaction('k', 'readwrite'); tx.objectStore('k').put(kp, 'id'); tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error); }); HD.idPersisted = true; } catch (e) { HD.idPersisted = false; } }
        } else HD.idPersisted = true;
        try { if (db) db.close(); } catch (e) {}
        const j = await subtle.exportKey('jwk', kp.publicKey); const pub = { x: j.x, y: j.y };
        HD.identity = { priv: kp.privateKey, pub, fp: await HD.idFingerprint(pub) };
    }
    HD.idReady = subtle ? loadIdentity(false).catch((e) => { console.warn('HD11 identity', e); }) : Promise.resolve();
    HD.resetIdentity = async () => { HD.idReady = loadIdentity(true); await HD.idReady; return HD.identity; };
    const sigMsg = (ekx, eky, from, to) => te.encode('hdc11-id|' + ekx + '.' + eky + '|' + from + '>' + to);
    HD.signHello = async (s, conn) => {
        await HD.idReady; if (!HD.identity) return {};
        const sg = await subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, HD.identity.priv, sigMsg(s.pubJwk.x, s.pubJwk.y, peer.id, conn.peer));
        return { ik: HD.identity.pub, sig: B64(sg) };
    };
    HD.verifyHello = async (s, conn, ek, ik, sigB64) => {
        const k = await subtle.importKey('jwk', { kty: 'EC', crv: 'P-256', x: ik.x, y: ik.y, ext: true }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
        return subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, UB64(sigB64), sigMsg(ek.x, ek.y, conn.peer, peer.id));
    };

    async function encryptSend(conn, s, packet) {
        try {
            const n = ++s.sendN, iv = crypto.getRandomValues(new Uint8Array(12));
            const aad = te.encode('hdc11|' + peer.id + '>' + conn.peer + '|' + n);
            const ct = await subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aad }, s.sendKey, te.encode(JSON.stringify(packet)));
            if (conn.open) conn.send({ type: 'enc', payload: { n, iv: B64(iv), ct: B64(ct) } });
        } catch (e) { console.warn('enc send', e); }
    }
    async function decryptPacket(conn, s, p) {
        if (!p || !Number.isSafeInteger(p.n) || p.n <= s.recvN || typeof p.iv !== 'string' || typeof p.ct !== 'string' || p.ct.length > MAX_CT || p.iv.length !== 16) return null;
        const aad = te.encode('hdc11|' + conn.peer + '>' + peer.id + '|' + p.n);
        const pt = await subtle.decrypt({ name: 'AES-GCM', iv: UB64(p.iv), additionalData: aad }, s.recvKey, UB64(p.ct));
        s.recvN = p.n;
        return JSON.parse(new TextDecoder().decode(pt));
    }
    function takeToken(conn, s) {
        const now = Date.now(); s.tokens = Math.min(600, s.tokens + (now - s.last) * 0.25); s.last = now;
        if (s.tokens < 1) { if (++s.viol > 80) { try { conn.close(); } catch (e) {} } return false; }
        s.tokens -= 1; return true;
    }
    function reject(conn, why) {
        if (why) { try { appendSystemMessage('🛡️ ' + why); } catch (e) {} }
        try { conn.close(); } catch (e) {}
    }
    async function flush(conn, s) {
        const q = s.queue.splice(0, s.queue.length);
        for (const pk of q) { if (s.mode === 'enc') await encryptSend(conn, s, pk); else if (s.mode === 'plain' && conn.open) { try { conn.send(pk); } catch (e) {} } }
    }

    if (subtle && typeof sendPacket === 'function' && typeof handleIncomingPacket === 'function') {
        const _send = sendPacket, _handle = handleIncomingPacket;

        sendPacket = function (conn, packet) {
            if (!conn || !conn.open || !packet) return;
            const s = sess(conn);
            if (packet.type === 'hello' && !s.helloSent) {
                s.helloSent = true;
                Promise.all([s.ready, HD.idReady]).then(async () => { let idp = {}; try { idp = await HD.signHello(s, conn); } catch (e) {} if (conn.open) { try { conn.send({ type: 'hello', payload: Object.assign({}, packet.payload, { v: 12, ek: s.pubJwk }, idp) }); } catch (e) {} } });
                return;
            }
            if (s.mode === 'enc') return void encryptSend(conn, s, packet);
            if (s.mode === 'plain') return _send(conn, packet);
            if (s.mode === 'pending' && s.queue.length < 300) s.queue.push(packet);
        };

        async function processOne(packet, conn, s) {
            if (!packet || typeof packet !== 'object' || typeof packet.type !== 'string') return;
            if (!takeToken(conn, s)) return;
            if (packet.type === 'hello' && !s.gotHello) {
                s.gotHello = true; await s.ready;
                const p = packet.payload || {};
                const ek = p.ek; let encOk = false;
                if (ek && typeof ek === 'object' && JWK_RE.test(String(ek.x)) && JWK_RE.test(String(ek.y))) {
                    try { await derive(conn, s, { x: ek.x, y: ek.y }); } catch (e) { return reject(conn, 'تعذّر إتمام التشفير مع أحد المتصلين — تم رفض الاتصال.'); }
                    encOk = true;
                } else if (strict()) {
                    return reject(conn, 'تم رفض اتصال من نسخة قديمة بدون تشفير طرفي (وضع الحماية الصارم مفعّل).');
                }
                s.idOk = false; s.idFp = null;
                const ik = p.ik;
                if (encOk && ik && typeof ik === 'object' && JWK_RE.test(String(ik.x)) && JWK_RE.test(String(ik.y)) && typeof p.sig === 'string' && p.sig.length < 200) {
                    try { s.idOk = await HD.verifyHello(s, conn, ek, ik, p.sig); if (s.idOk) s.idFp = await HD.idFingerprint({ x: ik.x, y: ik.y }); } catch (e) { s.idOk = false; }
                }
                const clean = Object.assign({}, p); delete clean.ek; delete clean.v; delete clean.ik; delete clean.sig;
                if (HD.guardHello) {
                    let r; try { r = await HD.guardHello(conn, s, clean, encOk); } catch (e) { console.warn('guard', e); r = { ok: false, why: 'تعذّر فحص الحماية — تم رفض الاتصال احتياطاً.' }; }
                    if (!r || r.ok === false) return reject(conn, (r && r.why) || 'رفض نظام الحماية هذا الاتصال.');
                }
                s.mode = encOk ? 'enc' : 'plain'; flush(conn, s);
                return _handle({ type: 'hello', payload: clean }, conn);
            }
            if (packet.type === 'enc') {
                if (!s.recvKey) return;
                let inner; try { inner = await decryptPacket(conn, s, packet.payload); } catch (e) { s.viol += 5; return; }
                if (!inner || typeof inner.type !== 'string' || inner.type === 'enc') return;
                if (HD.guardFilter && HD.guardFilter(inner, conn, s) === false) return;
                if (routes[inner.type]) return routes[inner.type](inner.payload, conn);
                return _handle(inner, conn);
            }
            if (s.mode === 'plain') { if (HD.guardFilter && HD.guardFilter(packet, conn, s) === false) return; if (routes[packet.type]) return routes[packet.type](packet.payload, conn); return _handle(packet, conn); }
            /* أي حزمة غير مشفّرة بعد إقامة جلسة مشفّرة تُهمَل (منع التخفيض) */
        }
        handleIncomingPacket = function (packet, conn) {
            const s = sess(conn);
            s.chain = s.chain.then(() => processOne(packet, conn, s)).catch((e) => console.warn('hd11 packet', e));
        };
        HD.e2e = true;
    } else {
        HD.e2e = false;
        console.warn('HD11: WebCrypto غير متاح — التشفير الطرفي معطّل (يلزم HTTPS).');
    }

    /* ── مؤشر التشفير + لوحة الأمان ── */
    function peersSummary() {
        const ids = Object.keys(activeConnections || {}).filter((p) => activeConnections[p] && activeConnections[p].open);
        const encN = ids.filter((p) => activeConnections[p].__hd && activeConnections[p].__hd.mode === 'enc').length;
        return { total: ids.length, enc: encN, ids };
    }
    HD.peersSummary = peersSummary;

    let idleTimer = null, lastAct = Date.now();
    function awayOn() { document.body.classList.add('hx11-away'); } function awayOff() { document.body.classList.remove('hx11-away'); }
    window.addEventListener('blur', awayOn); window.addEventListener('focus', awayOff);
    document.addEventListener('visibilitychange', () => { document.hidden ? awayOn() : awayOff(); });
    function applyBlurPref() { document.body.classList.toggle('hx11-privacy', ls.get('hx11_blur', '0') === '1'); }
    function idleCheck() {
        const mins = parseInt(ls.get('hx11_idle', '0')) || 0; if (!mins) return;
        let s = {}; try { s = getAppSettings(); } catch (e) {}
        if (!(s.lockEnabled && (s.lockHash || s.lockPassword))) return;
        if (Date.now() - lastAct > mins * 60000) { const l = g('lock-screen'); if (l && l.classList.contains('hidden')) l.classList.remove('hidden'); }
    }
    function panicWipe() {
        if (!confirm('سيتم مسح كل الرسائل المحفوظة على هذا الجهاز وقطع الاتصالات الآن. متابعة؟')) return;
        try { dbClearAll(); } catch (e) {}
        try { const b = g('chat-box'); if (b) b.textContent = ''; } catch (e) {}
        try { Object.values(activeConnections).forEach((c) => { try { c.close(); } catch (e) {} }); } catch (e) {}
        if (HD.call && HD.call.hangup) try { HD.call.hangup(); } catch (e) {}
        note('تم المسح والقطع.');
    }
    function openSecurity() {
        sheet('الأمان والخصوصية', (b) => {
            const sum = peersSummary();
            const st = el('div', 'hx11-status ' + (HD.e2e ? 'ok' : 'bad'));
            st.appendChild(icon(HD.e2e ? 'shield' : 'panic', 20));
            const tx = el('div'); tx.appendChild(el('b', '', HD.e2e ? 'التشفير الطرفي مفعّل' : 'التشفير الطرفي غير متاح'));
            tx.appendChild(el('small', '', HD.e2e ? 'ECDH P-256 + AES-256-GCM — مفاتيح مؤقتة تتجدد مع كل اتصال، ولا تمر عبر أي خادم.' : 'المتصفح لا يدعم WebCrypto أو الصفحة ليست على HTTPS.'));
            st.appendChild(tx); b.appendChild(st);

            section(b, 'الاتصالات الحالية (' + sum.enc + '/' + sum.total + ' مشفّرة)');
            if (!sum.ids.length) b.appendChild(el('p', 'hx-muted', 'لا يوجد متصلون الآن.'));
            sum.ids.forEach((pid) => {
                const c = activeConnections[pid], s = c.__hd || {}, card = el('div', 'hx11-peer');
                const top = el('div', 'hx11-peer-top'); top.appendChild(icon(s.mode === 'enc' ? 'lock' : 'panic', 16));
                top.appendChild(el('b', '', (peerNames && peerNames[pid]) || 'مجهول')); top.appendChild(el('span', 'hx11-badge ' + (s.mode === 'enc' ? 'ok' : 'bad'), s.mode === 'enc' ? 'مشفّر' : 'غير مشفّر'));
                card.appendChild(top);
                if (s.fp) {
                    card.appendChild(el('code', 'hx11-fp', s.fp));
                    card.appendChild(el('small', 'hx-muted', 'قارن هذا الرمز مع صديقك عبر وسيلة أخرى (صوت أو مكالمة). التطابق = لا يوجد وسيط يتنصت.'));
                    const vb = el('button', 'hx11-chipbtn' + (s.verified ? ' on' : ''), s.verified ? 'تم التحقق ✓' : 'تحقّقنا من الرمز');
                    vb.type = 'button'; vb.onclick = () => { s.verified = !s.verified; vb.classList.toggle('on', s.verified); vb.textContent = s.verified ? 'تم التحقق ✓' : 'تحقّقنا من الرمز'; };
                    card.appendChild(vb);
                }
                b.appendChild(card);
            });

            section(b, 'مستوى الحماية');
            row(b, 'وضع الحماية الصارم', toggle(strict(), (v) => ls.set('hx11_strict', v ? '1' : '0')), 'رفض أي اتصال لا يدعم التشفير الطرفي (يمنع التخفيض).');
            row(b, 'تمويه المحادثة عند مغادرة النافذة', toggle(ls.get('hx11_blur', '0') === '1', (v) => { ls.set('hx11_blur', v ? '1' : '0'); applyBlurPref(); }), 'يخفي المحتوى في معاينة التبديل بين التطبيقات.');
            row(b, 'قفل تلقائي عند الخمول', select([['0', 'معطّل'], ['1', 'دقيقة'], ['5', '5 دقائق'], ['15', '15 دقيقة']], ls.get('hx11_idle', '0'), (v) => ls.set('hx11_idle', v)), 'يعمل فقط إذا فعّلت قفل التطبيق من الإعدادات.');

            section(b, 'ما يحميه التشفير وما لا يحميه');
            b.appendChild(el('p', 'hx-muted', 'الرسائل والمرفقات والأوامر مشفّرة بين الأجهزة مباشرة، والمكالمات مشفّرة بـ DTLS-SRTP من المتصفح نفسه. لا يمنع التشفير لقطة الشاشة ولا أن يكون الطرف الآخر غير موثوق.'));
            button(b, 'زر الطوارئ: مسح الرسائل وقطع الاتصالات', panicWipe, 'panic', 'danger');
        });
    }
    HD.openSecurity = openSecurity;

    function installHeader() {
        const hdr = document.querySelector('#chat-main-area > header .flex.items-center.gap-3'); if (!hdr || g('hx11-sec-btn')) return;
        const b = iconBtn('shield', 'الأمان والتشفير', () => HD.openSecurity(), 'hx11-hdr'); b.id = 'hx11-sec-btn';
        const dot = el('span', 'hx11-dot'); dot.id = 'hx11-sec-dot'; b.appendChild(dot);
        hdr.insertBefore(b, hdr.firstChild);
    }
    function tick() {
        const d = g('hx11-sec-dot'); if (!d) return; const s = peersSummary();
        d.className = 'hx11-dot ' + (!s.total ? 'idle' : s.enc === s.total ? 'ok' : 'bad');
        d.title = s.total ? s.enc + ' من ' + s.total + ' اتصالات مشفّرة' : 'لا اتصالات';
    }
    function init() {
        applyBlurPref(); installHeader();
        ['pointerdown', 'keydown', 'touchstart', 'mousemove'].forEach((ev) => document.addEventListener(ev, () => { lastAct = Date.now(); }, { passive: true, capture: true }));
        idleTimer = setInterval(idleCheck, 15000); setInterval(tick, 2000); tick();
        document.addEventListener('keydown', (e) => { if (e.ctrlKey && e.shiftKey && (e.key === 'X' || e.key === 'x')) { e.preventDefault(); panicWipe(); } });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
