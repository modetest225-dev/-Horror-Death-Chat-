/* ============================================================
   Horror Death Chat v3 — app.js
   Full Packet-Driven Architecture with IndexedDB
   ============================================================ */

'use strict';

/* ── ضبط فوري لارتفاع الشاشة الحقيقي قبل أي شيء (يمنع قصّ نصف الشاشة على الموبايل) ── */
(function setAppHeightImmediate() {
    const h = (window.visualViewport ? window.visualViewport.height : window.innerHeight);
    document.documentElement.style.setProperty('--app-height', h + 'px');
})();

/* ══════════════════════════════════════════════════════════════
   § GLOBALS
══════════════════════════════════════════════════════════════ */
let peer = null;
let currentUser = null;
let authMode = 'visitor';
let currentLang = 'ar';
let viewOnceActive = false;
let selectedMsgId = null;
let currentRoom = null;
let isMusicPlaying = false;
let soundEffectsEnabled = true;
let isProfileOpen = true;
let isMuted = false;
let isCursed = false;
let curseTimer = null;

// Peer/connection management
let activeConnections = {}; // peerId -> DataConnection
let isHost = false;         // am I the room host?
let hostPeerId = null;      // who is the current host?
let joinTimestamp = Date.now();

// Private chat state
let activePrivateChatUser = null;
let privateChatMessages = {}; // { username: [{from,text,ts}] }
let isPrivateListOpen = false;
let unreadPrivateCount = 0;

// Notifications
let notifications = [];
let isNotificationPanelOpen = false;

// User popup
let selectedPopupUser = null;

// Moderation target
let modTargetUsername = null;

// Ouija state
let ouijaActive = false;
let ouijaLetterBuffer = '';
let ouijaLetterTimeout = null;

// Killer game state
let killerGameActive = false;

// Anti-spam rate limiter
let spamMessageTimestamps = [];
let isSpamFrozen = false;
let spamFreezeTimer = null;

// Ghost bot state
let ghostBotTimer = null;
let ghostBotActive = false;

// Voice call
let activeVoiceCall = null;
let voiceAudioContext = null;

/* ══════════════════════════════════════════════════════════════
   § OWNER / ADMIN CONFIG
══════════════════════════════════════════════════════════════ */
const OWNER_NAMES = ['☣Horror Death☠', 'Control-girl'];

function isOwner(name) {
    return OWNER_NAMES.includes(name || (currentUser && currentUser.username));
}
function isAdmin(name) {
    return isOwner(name);
}

/* ══════════════════════════════════════════════════════════════
   § PROFANITY FILTER
══════════════════════════════════════════════════════════════ */
const badWordsFilter = [
    'كلب', 'حمار', 'غبي', 'حيوان', 'شتيمة', 'عاهرة', 'قحبة',
    'زبالة', 'نذل', 'خنزير', 'كس', 'زب', 'طيز', 'شرموط', 'عير',
    'damn', 'fuck', 'shit', 'ass', 'bitch', 'bastard', 'cunt', 'dick',
    'whore', 'slut', 'faggot', 'retard'
];


/* ══════════════════════════════════════════════════════════════
   § ANTI-SPAM RATE LIMITER
══════════════════════════════════════════════════════════════ */
function checkSpamLimit() {
    if (isOwner()) return true; // owner exempt
    if (isSpamFrozen) return false;

    const now = Date.now();
    spamMessageTimestamps = spamMessageTimestamps.filter(t => now - t < 1000);
    if (spamMessageTimestamps.length >= 3) {
        activateSpamFreeze();
        return false;
    }
    spamMessageTimestamps.push(now);
    return true;
}

function activateSpamFreeze() {
    isSpamFrozen = true;
    let countdown = 10;

    const modal = document.getElementById('spam-warning-modal');
    modal.classList.remove('hidden');
    document.getElementById('spam-countdown').textContent = countdown;

    const timer = setInterval(() => {
        countdown--;
        const el = document.getElementById('spam-countdown');
        if (el) el.textContent = countdown;
        if (countdown <= 0) {
            clearInterval(timer);
            isSpamFrozen = false;
            modal.classList.add('hidden');
        }
    }, 1000);

    playHorrorAlertSound();
}

/* ══════════════════════════════════════════════════════════════
   § INDEXEDDB — STORAGE ENGINE
══════════════════════════════════════════════════════════════ */
const DB_NAME = 'HorrorDeathChatDB';
const DB_VERSION = 1;
let db = null;

function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = (e) => {
            const database = e.target.result;
            if (!database.objectStoreNames.contains('messages')) {
                const store = database.createObjectStore('messages', { keyPath: 'id', autoIncrement: true });
                store.createIndex('by_room', 'room', { unique: false });
                store.createIndex('by_ts', 'timestamp', { unique: false });
            }
            if (!database.objectStoreNames.contains('attachments')) {
                database.createObjectStore('attachments', { keyPath: 'msgId' });
            }
            if (!database.objectStoreNames.contains('settings')) {
                database.createObjectStore('settings', { keyPath: 'key' });
            }
        };
        req.onsuccess = (e) => { db = e.target.result; resolve(db); };
        req.onerror = (e) => { console.error('IndexedDB error:', e); reject(e); };
    });
}

function dbSaveMessage(msgObj) {
    if (!db) return;
    try {
        const tx = db.transaction('messages', 'readwrite');
        tx.onerror = (e) => console.warn('dbSaveMessage tx error:', e.target.error);
        tx.onabort = (e) => console.warn('dbSaveMessage tx aborted:', e.target.error);
        const store = tx.objectStore('messages');
        // Strip large attachmentData before storing in messages store
        const toStore = Object.assign({}, msgObj);
        const attachData = toStore.attachmentData || null;
        toStore.attachmentData = null;
        const req = store.put(toStore);
        req.onsuccess = (e) => {
            if (attachData) {
                dbSaveAttachment(e.target.result || msgObj.id, attachData);
            }
        };
        req.onerror = (e) => console.warn('dbSaveMessage put error:', e.target.error);
    } catch(e) { console.warn('dbSaveMessage exception:', e); }
}

function dbSaveAttachment(msgId, data) {
    if (!db) return;
    const tx = db.transaction('attachments', 'readwrite');
    tx.objectStore('attachments').put({ msgId: msgId, data: data });
}

function dbLoadMessages(roomId) {
    return new Promise((resolve) => {
        if (!db) { resolve([]); return; }
        const tx = db.transaction(['messages', 'attachments'], 'readonly');
        const store = tx.objectStore('messages');
        const idx = store.index('by_room');
        const req = idx.getAll(roomId || 'public');
        req.onsuccess = (e) => {
            const msgs = e.target.result || [];
            // Attach data for recent attachments
            const attStore = tx.objectStore('attachments');
            let pending = msgs.filter(m => m.attachmentType).length;
            if (pending === 0) { resolve(msgs); return; }
            msgs.forEach((m) => {
                if (!m.attachmentType) return;
                const ar = attStore.get(m.id);
                ar.onsuccess = (ae) => {
                    if (ae.target.result) m.attachmentData = ae.target.result.data;
                    pending--;
                    if (pending === 0) resolve(msgs);
                };
                ar.onerror = () => { pending--; if (pending === 0) resolve(msgs); };
            });
        };
        req.onerror = () => resolve([]);
    });
}

function dbClearAll() {
    if (!db) return;
    ['messages', 'attachments', 'settings'].forEach(s => {
        try {
            const tx = db.transaction(s, 'readwrite');
            tx.onerror = () => {};
            tx.objectStore(s).clear();
        } catch(e) {}
    });
}

function dbSaveSetting(key, value) {
    if (!db) return;
    const tx = db.transaction('settings', 'readwrite');
    tx.objectStore('settings').put({ key, value });
}

function dbGetSetting(key) {
    return new Promise((resolve) => {
        if (!db) { resolve(null); return; }
        const tx = db.transaction('settings', 'readonly');
        const req = tx.objectStore('settings').get(key);
        req.onsuccess = (e) => resolve(e.target.result ? e.target.result.value : null);
        req.onerror = () => resolve(null);
    });
}

/* ══════════════════════════════════════════════════════════════
   § VISUAL VIEWPORT — KEYBOARD FIX (single registration)
══════════════════════════════════════════════════════════════ */
let _viewportFixRegistered = false;


/* ══════════════════════════════════════════════════════════════
   § SOUND ENGINE
══════════════════════════════════════════════════════════════ */
function playClickSound() {
    if (!soundEffectsEnabled) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(120, ctx.currentTime);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.07);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(); osc.stop(ctx.currentTime + 0.07);
    } catch(e) {}
}

function playHorrorMsgSound() {
    // مرعب قصير - نبضة صوتية منخفضة مع صرير
    if (!soundEffectsEnabled) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const t = ctx.currentTime;

        // Low rumble
        const osc1 = ctx.createOscillator();
        const g1 = ctx.createGain();
        osc1.type = 'sawtooth';
        osc1.frequency.setValueAtTime(60, t);
        osc1.frequency.exponentialRampToValueAtTime(30, t + 0.4);
        g1.gain.setValueAtTime(0, t);
        g1.gain.linearRampToValueAtTime(0.12, t + 0.05);
        g1.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
        osc1.connect(g1); g1.connect(ctx.destination);
        osc1.start(t); osc1.stop(t + 0.5);

        // High creak
        const osc2 = ctx.createOscillator();
        const g2 = ctx.createGain();
        osc2.type = 'square';
        osc2.frequency.setValueAtTime(800, t + 0.1);
        osc2.frequency.exponentialRampToValueAtTime(300, t + 0.35);
        g2.gain.setValueAtTime(0.03, t + 0.1);
        g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
        osc2.connect(g2); g2.connect(ctx.destination);
        osc2.start(t + 0.1); osc2.stop(t + 0.4);
    } catch(e) {}
}

function playHorrorAlertSound() {
    if (!soundEffectsEnabled) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const t = ctx.currentTime;
        [0, 0.15, 0.3].forEach((delay, i) => {
            const osc = ctx.createOscillator();
            const g = ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(180 - i * 30, t + delay);
            g.gain.setValueAtTime(0.1, t + delay);
            g.gain.exponentialRampToValueAtTime(0.0001, t + delay + 0.12);
            osc.connect(g); g.connect(ctx.destination);
            osc.start(t + delay); osc.stop(t + delay + 0.12);
        });
    } catch(e) {}
}

function playPrivateMsgSound() {
    if (!soundEffectsEnabled) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const t = ctx.currentTime;
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, t);
        osc.frequency.exponentialRampToValueAtTime(820, t + 0.07);
        g.gain.setValueAtTime(0.08, t);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.15);
        osc.connect(g); g.connect(ctx.destination);
        osc.start(t); osc.stop(t + 0.15);
    } catch(e) {}
}

function playErrorSound() {
    if (!soundEffectsEnabled) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        osc.frequency.setValueAtTime(160, ctx.currentTime + 0.1);
        g.gain.setValueAtTime(0.08, ctx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.28);
        osc.connect(g); g.connect(ctx.destination);
        osc.start(); osc.stop(ctx.currentTime + 0.28);
    } catch(e) {}
}

function initMelancholyAudio() {
    const audio = document.getElementById('bg-sad-music');
    if (audio && !isMusicPlaying) {
        audio.volume = 0.25;
        audio.play().then(() => { isMusicPlaying = true; }).catch(() => {});
    }
}

function toggleMusicControl(event) {
    event.stopPropagation();
    const audio = document.getElementById('bg-sad-music');
    const btn = document.getElementById('music-toggle-btn');
    if (!audio) return;
    if (isMusicPlaying) {
        audio.pause();
        isMusicPlaying = false;
        btn.classList.add('text-stone-600');
        btn.classList.remove('text-red-700');
    } else {
        audio.play().then(() => {
            isMusicPlaying = true;
            btn.classList.remove('text-stone-600');
            btn.classList.add('text-red-700');
        }).catch(() => {});
    }
}

function toggleSoundEffectSetting() {
    soundEffectsEnabled = !soundEffectsEnabled;
    const btn = document.getElementById('sound-effect-btn');
    if (soundEffectsEnabled) {
        btn.innerText = 'صوت: مفعل';
        btn.className = 'bg-stone-900 border border-stone-800 rounded text-[9px] py-1 text-emerald-500';
        playClickSound();
    } else {
        btn.innerText = 'صوت: معطل';
        btn.className = 'bg-stone-900 border border-stone-800 rounded text-[9px] py-1 text-red-500';
    }
}

function toggleProfilePrivacySetting() {
    isProfileOpen = !isProfileOpen;
    const btn = document.getElementById('profile-privacy-btn');
    btn.innerText = isProfileOpen ? 'الملف: مفتوح' : 'الملف: مغلق';
    btn.className = 'bg-stone-900 border border-stone-800 rounded text-[9px] py-1 ' + (isProfileOpen ? 'text-emerald-500' : 'text-red-500');
}

/* ══════════════════════════════════════════════════════════════
   § DAILY GOLD REWARD
══════════════════════════════════════════════════════════════ */
function claimDailyReward() {
    if (isOwner()) {
        showLiveUpdate('👑 المالك محصّن من قواعد المكافأة اليومية - رصيدك لامحدود.');
        return;
    }
    const lastClaim = parseInt(localStorage.getItem('horror_daily_reward_ts') || '0');
    const now = Date.now();
    const diff = now - lastClaim;
    const msIn24h = 24 * 60 * 60 * 1000;

    if (diff < msIn24h) {
        const remaining = Math.ceil((msIn24h - diff) / 3600000);
        triggerFirewallModal(`لقد استلمت مكافأتك اليومية بالفعل! يمكنك المطالبة بها مجدداً بعد ${remaining} ساعة.`);
        return;
    }
    const currentCoins = parseInt(localStorage.getItem('horror_user_coins') || '0');
    const newCoins = currentCoins + 100;
    localStorage.setItem('horror_user_coins', newCoins);
    localStorage.setItem('horror_daily_reward_ts', now.toString());
    document.getElementById('user-coins').innerText = newCoins;
    if (currentUser) currentUser.coins = newCoins;

    const btn = document.getElementById('daily-reward-btn');
    btn.classList.add('claimed');
    btn.innerHTML = '<i class="fa-solid fa-check"></i> تم استلام 100 ذهبة!';

    appendSystemMessage('🎁 استلمت مكافأتك اليومية: 100 ذهبة! عد غداً للمزيد.');
    showLiveUpdate('🎁 ' + (currentUser ? currentUser.username : '?') + ' استلم مكافأته اليومية!');
}

function checkDailyRewardStatus() {
    const lastClaim = parseInt(localStorage.getItem('horror_daily_reward_ts') || '0');
    const diff = Date.now() - lastClaim;
    const msIn24h = 24 * 60 * 60 * 1000;
    const btn = document.getElementById('daily-reward-btn');
    if (!btn) return;
    if (diff < msIn24h && !isOwner()) {
        btn.classList.add('claimed');
        const rem = Math.ceil((msIn24h - diff) / 3600000);
        btn.innerHTML = `<i class="fa-solid fa-clock"></i> بعد ${rem}ساعة`;
    }
}

/* ══════════════════════════════════════════════════════════════
   § PEERJS SETUP
══════════════════════════════════════════════════════════════ */
function initPeer() {
    peer = new Peer(undefined, {
        debug: 0,
        config: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }, { urls: 'stun:stun.cloudflare.com:3478' }].concat(window.HDC_ICE_EXTRA || []), iceTransportPolicy: window.HDC_ICE_POLICY === 'relay' ? 'relay' : 'all' }
    });

    peer.on('open', (id) => {
        document.getElementById('my-peer-id').innerText = id;
        setupInvite(id);
        window.__legacyConnect = () => {
            const remoteId = document.getElementById('remote-peer-id').value.trim();
            if (remoteId && remoteId !== id) connectToPeer(remoteId);
        };
    });

    peer.on('disconnected', () => { setTimeout(() => { try { if (!peer.destroyed) peer.reconnect(); } catch(e) {} }, 2000); });

    peer.on('connection', (conn) => {
        setupDataConnection(conn);
    });

    peer.on('call', (call) => {
        handleIncomingVoiceCall(call);
    });

    peer.on('error', (err) => {
        console.warn('PeerJS error:', err.type, err.message);
        if (err.type === 'peer-unavailable') showLiveUpdate('⚠️ تعذر الوصول لهذا المعرّف — تأكد أنه متصل.');
        else if (['network','server-error','socket-error'].includes(err.type)) setTimeout(() => { try { peer.reconnect(); } catch(e) {} }, 3000);
    });
}



function buildRoomState() {
    return {
        roomName: currentRoom ? currentRoom.name : 'الغرفة العامة',
        hostPeerId: peer.id,
        messages: [] // omit heavy messages for now
    };
}

function handlePeerDisconnect(peerId) {
    showLiveUpdate('💀 روح غادرت الظلام...');
    broadcastPacket({ type: 'user_left', payload: { peerId } });

    // Host migration: if the host left, elect new host
    if (peerId === hostPeerId) {
        electNewHost();
    }

    stopGhostBotIfNeeded();
    startGhostBotIfAlone();
}

/* ══════════════════════════════════════════════════════════════
   § HOST MIGRATION
══════════════════════════════════════════════════════════════ */
function electNewHost() {
    const allPeerIds = Object.keys(activeConnections);

    if (allPeerIds.length === 0) {
        // I'm alone, become host
        becomeHost();
        return;
    }

    // Sort by joinTimestamp if available, else by peer ID lexicographically
    // Elect self as host if my ID is lexicographically smallest
    const candidates = [peer.id, ...allPeerIds].sort();
    const elected = candidates[0];

    if (elected === peer.id) {
        becomeHost();
        broadcastPacket({ type: 'host_migration', payload: { newHostPeerId: peer.id, newHostName: currentUser.username } });
    } else {
        // Someone else will become host
        hostPeerId = elected;
        document.getElementById('host-badge').classList.add('hidden');
        appendSystemMessage('🔄 تم نقل صلاحيات المضيف إلى مستخدم آخر آلياً.');
    }
}

function becomeHost() {
    isHost = true;
    hostPeerId = peer.id;
    document.getElementById('host-badge').classList.remove('hidden');
    appendSystemMessage('👑 أنت الآن مضيف الغرفة. تم نقل صلاحيات الـ Host إليك آلياً.');
    showLiveUpdate('👑 ' + currentUser.username + ' أصبح مضيف الغرفة.');
}

/* ══════════════════════════════════════════════════════════════
   § PACKET ENGINE — SEND / RECEIVE
══════════════════════════════════════════════════════════════ */
function sendPacket(conn, packet) {
    if (conn && conn.open) {
        try { conn.send(packet); } catch(e) { console.warn('Send error:', e); }
    }
}

function broadcastPacket(packet, excludePeerIds) {
    excludePeerIds = excludePeerIds || [];
    Object.keys(activeConnections).forEach(pid => {
        if (!excludePeerIds.includes(pid)) {
            sendPacket(activeConnections[pid], packet);
        }
    });
}


/* ══════════════════════════════════════════════════════════════
   § PACKET HANDLERS
══════════════════════════════════════════════════════════════ */

function handlePrivateMsgPacket(payload) {
    if (!payload) return;
    const { to, from, text, timestamp } = payload;
    if (!currentUser || to !== currentUser.username) return;

    if (!privateChatMessages[from]) privateChatMessages[from] = [];
    privateChatMessages[from].push({ from, text: filterProfanity(text), ts: timestamp });

    unreadPrivateCount++;
    updatePrivateNotificationBadge();
    playPrivateMsgSound();
    addNotification('🔒 رسالة خاصة من ' + from);
    showLiveUpdate('🔒 ' + from + ' أرسل لك رسالة خاصة!');

    // Activate private chat icon red neon pulse
    const dot = document.getElementById('private-notification-dot');
    const icon = document.getElementById('private-chat-icon');
    if (dot) dot.classList.add('active');
    if (icon) icon.classList.add('has-unread');

    // If private chat window is open with this user, append immediately
    if (activePrivateChatUser === from) {
        appendPrivateMsgBubble({ from, text: filterProfanity(text), ts: timestamp }, false);
    }

    updatePrivateList();

    // Browser notification for private message
    showBrowserNotification(
        '🔒 رسالة خاصة — Horror Death Chat',
        (from || '?') + ' أرسل لك رسالة خاصة',
        { tag: 'hdc-private', ttl: 7000 }
    );
}

function handleRoomState(payload) {
    if (!payload) return;
    hostPeerId = payload.hostPeerId;
    isHost = false;
    document.getElementById('host-badge').classList.add('hidden');
    appendSystemMessage('✅ تم استقبال بيانات الغرفة من المضيف.');
    showLiveUpdate('✅ تزامنت مع الغرفة: ' + (payload.roomName || 'عامة'));
}

function handleUserJoinedPacket(payload) {
    if (!payload) return;
    appendSystemMessage('👻 ' + payload.username + ' انضم إلى الظلام.');
    showLiveUpdate('👻 ' + payload.username + ' دخل الغرفة.');
    stopGhostBot();
}

function handleUserLeftPacket(payload) {
    appendSystemMessage('💨 روح غادرت...');
    showLiveUpdate('💨 مستخدم غادر الغرفة.');
    startGhostBotIfAlone();
}

function handleHostMigration(payload) {
    if (!payload) return;
    hostPeerId = payload.newHostPeerId;
    if (peer.id === payload.newHostPeerId) {
        becomeHost();
    } else {
        appendSystemMessage('🔄 مضيف جديد: ' + (payload.newHostName || 'مجهول'));
        showLiveUpdate('👑 تم انتخاب مضيف جديد: ' + (payload.newHostName || '?'));
    }
}

function handleForceBanSignal(payload) {
    if (!payload || !currentUser) return;
    if (payload.target === currentUser.username) {
        const expiry = payload.expiry === 'permanent' ? 'permanent' : Date.now() + payload.expiry * 60000;
        localStorage.setItem('banned_' + currentUser.username, expiry.toString());
        alert('🚫 تم حظرك من الغرفة بقرار من الإدارة!');
        window.location.reload();
    }
}

function handleOwnerWarning(payload) {
    if (!payload || !currentUser) return;
    if (payload.target === currentUser.username) {
        playHorrorAlertSound();
        appendSystemMessage('⚠️ إنذار رسمي من الإدارة: ' + payload.message);
        triggerFirewallModal('⚠️ تحذير رسمي صادر من المالك: ' + payload.message);
        showLiveUpdate('⚠️ صدر إنذار رسمي لـ ' + payload.target);
    }
}

function handleCursePacket(payload) {
    if (!payload || !currentUser) return;
    if (payload.target !== currentUser.username) return;
    if (isOwner()) return;
    payload.duration = Math.min(120, Math.max(10, parseInt(payload.duration) || 30));
    activateCurseOnSelf(payload.duration);
    appendSystemMessage('💀 لُعنت! شاتك معطل لـ ' + payload.duration + ' ثانية...');
    showLiveUpdate('💀 ' + payload.target + ' تعرض للعنة!');
}

function activateCurseOnSelf(seconds) {
    isCursed = true;
    const overlay = document.getElementById('cursed-msg-overlay');
    const inputArea = document.getElementById('input-area');
    overlay.classList.remove('hidden');
    inputArea.classList.add('cursed-chat-disabled');
    playHorrorAlertSound();

    if (curseTimer) clearTimeout(curseTimer);
    curseTimer = setTimeout(() => {
        isCursed = false;
        overlay.classList.add('hidden');
        inputArea.classList.remove('cursed-chat-disabled');
        appendSystemMessage('✨ انتهت اللعنة. عاد شاتك.');
    }, seconds * 1000);
}

function handleSeancePacket(payload) {
    activateSeanceEffect(payload ? payload.duration : 30);
}

function activateSeanceEffect(duration) {
    duration = duration || 30;
    const overlay = document.getElementById('seance-overlay');
    overlay.classList.remove('hidden');
    document.body.classList.add('screen-shaking');

    playHorrorAlertSound();
    let remaining = duration;
    const timerEl = document.getElementById('seance-timer-text');
    const countdownInterval = setInterval(() => {
        remaining--;
        if (timerEl) timerEl.textContent = String(remaining).padStart(2, '0') + ':00';
        if (remaining <= 0) {
            clearInterval(countdownInterval);
            endSeanceEffect();
        }
    }, 1000);
}

function endSeanceEffect() {
    document.getElementById('seance-overlay').classList.add('hidden');
    document.body.classList.remove('screen-shaking');
}

function handleOuijaMovePacket(payload) {
    if (!ouijaActive || !payload) return;
    const board = document.getElementById('ouija-board');
    const planchette = document.getElementById('ouija-planchette');
    if (!board || !planchette) return;

    const bRect = board.getBoundingClientRect();
    const x = payload.xRatio * bRect.width;
    const y = payload.yRatio * bRect.height;
    planchette.style.left = x + 'px';
    planchette.style.top = y + 'px';

    // Detect letter under planchette
    detectOuijaLetter(payload.xRatio, payload.yRatio);
}

function detectOuijaLetter(xRatio, yRatio) {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const cols = 9;
    const col = Math.floor(xRatio * cols);
    const row = Math.floor(yRatio * 4);
    const idx = row * cols + col;
    if (idx >= 0 && idx < letters.length) {
        const letter = letters[idx];
        const msgEl = document.getElementById('ouija-message');
        if (msgEl) {
            ouijaLetterBuffer += letter;
            msgEl.textContent = ouijaLetterBuffer.slice(-20);
        }
        clearTimeout(ouijaLetterTimeout);
        ouijaLetterTimeout = setTimeout(() => { ouijaLetterBuffer = ''; }, 3000);
    }
}

function handleKillerGameStart(payload) {
    if (!payload || !currentUser) return;
    // Whitelist valid roles — reject peer-injected role strings
    const rawRole = payload.roles ? (payload.roles[currentUser.username] || 'ضحية') : 'ضحية';
    const myRole = (rawRole === 'قاتل') ? 'قاتل' : 'ضحية';
    const isKiller = (myRole === 'قاتل');

    const modal = document.getElementById('killer-game-modal');
    const content = document.getElementById('killer-game-content');
    modal.classList.remove('hidden');
    content.innerHTML = ''; // clear safely first

    // Build DOM nodes — no innerHTML with user data
    const revealDiv = document.createElement('div');
    revealDiv.className = 'role-reveal p-4 rounded border ' +
        (isKiller ? 'border-red-900 bg-red-950/30' : 'border-stone-800 bg-stone-900/30');

    const labelP = document.createElement('p');
    labelP.className = 'text-sm font-black ' + (isKiller ? 'text-red-500' : 'text-stone-300');
    labelP.textContent = 'دورك في هذه الجولة:';

    const roleP = document.createElement('p');
    roleP.className = 'text-2xl font-black mt-2 ' + (isKiller ? 'text-red-400' : 'text-stone-400');
    roleP.textContent = (isKiller ? '🔪 قاتل' : '🫀 ضحية');

    const hintP = document.createElement('p');
    hintP.className = 'text-[10px] text-stone-500 mt-2';
    hintP.textContent = isKiller
        ? 'اقتل الضحايا واحداً بعد الآخر قبل أن يكتشفوك.'
        : 'اكتشف القاتل قبل أن يُصفّيك!';

    revealDiv.appendChild(labelP);
    revealDiv.appendChild(roleP);
    revealDiv.appendChild(hintP);

    // Participants list — escape each name
    const participantsP = document.createElement('p');
    participantsP.className = 'text-[9px] text-stone-600 mt-1';
    const names = payload.roles ? Object.keys(payload.roles).map(n => String(n).substring(0, 20)) : [];
    participantsP.textContent = 'المشاركون: ' + names.join('، ');

    content.appendChild(revealDiv);
    content.appendChild(participantsP);

    killerGameActive = true;
    showLiveUpdate('🎮 بدأت لعبة القاتل الخفي!');
    playHorrorAlertSound();
}

function handleReactionPacket(payload) {
    if (!payload) return;
    const el = document.getElementById('reactions-' + payload.msgId);
    if (!el) return;
    // Sanitize emoji: allow only short strings (real emoji are 1-4 chars)
    const safeEmoji = String(payload.emoji || '').substring(0, 8);
    const existing = el.querySelector('[data-emoji="' + CSS.escape(safeEmoji) + '"]');
    if (existing) {
        const cnt = existing.querySelector('.cnt');
        if (cnt) cnt.textContent = parseInt(cnt.textContent || '0') + 1;
    } else {
        const badge = document.createElement('span');
        badge.className = 'reaction-badge';
        badge.setAttribute('data-emoji', safeEmoji);
        // Use textContent for emoji + DOM-built counter span — no innerHTML injection
        badge.textContent = safeEmoji + ' ';
        const cntSpan = document.createElement('span');
        cntSpan.className = 'cnt';
        cntSpan.textContent = '1';
        badge.appendChild(cntSpan);
        el.appendChild(badge);
    }
}

function handleDeleteMsgPacket(payload) {
    if (!payload) return;
    const el = document.getElementById('msg-' + payload.msgId);
    if (el) {
        el.style.opacity = '0.3';
        el.style.textDecoration = 'line-through';
        const body = el.querySelector('.msg-body');
        if (body) body.innerHTML = '<em class="text-stone-600 text-[10px]">تم حذف هذه الرسالة</em>';
    }
}

function handleCoinsGiftPacket(payload) {
    if (!payload || !currentUser) return;
    if (payload.to !== currentUser.username) return;
    const cur = parseInt(localStorage.getItem('horror_user_coins') || '0');
    const newAmt = cur + payload.amount;
    localStorage.setItem('horror_user_coins', newAmt);
    document.getElementById('user-coins').innerText = newAmt;
    if (currentUser) currentUser.coins = newAmt;
    appendSystemMessage('🪙 استلمت ' + payload.amount + ' ذهبة هدية من ' + payload.from + '!');
}

/* ══════════════════════════════════════════════════════════════
   § BROADCAST MESSAGE (SEND)
══════════════════════════════════════════════════════════════ */
function sendBroadcastMessage() {
    if (!currentUser) return;
    if (isCursed) { appendSystemMessage('⛓️ لا يمكنك الإرسال. أنت ملعون حالياً.'); return; }
    if (!checkSpamLimit()) return;

    const input = document.getElementById('msg-input');
    const rawText = input.value.trim();
    if (!rawText) return;

    const text = filterProfanity(rawText.slice(0, 1000));
    const msgId = 'msg_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    const timestamp = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

    const msg = {
        id: msgId,
        sender: currentUser.username,
        role: currentUser.role,
        text: text,
        viewOnce: viewOnceActive,
        timestamp,
        level: currentUser.level,
        room: currentRoom ? currentRoom.name : 'public'
    };

    seenMsgIds.add(msg.id);
    persistMessage(msg);
    renderSingleMessage(msg);
    scrollChatToBottom();

    broadcastPacket({
        type: 'chat',
        payload: msg
    });

    input.value = '';
    if (viewOnceActive) toggleViewOnce();
}

/* ══════════════════════════════════════════════════════════════
   § PRIVATE MESSAGING
══════════════════════════════════════════════════════════════ */
function openPrivateChatWith(targetUsername) {
    activePrivateChatUser = targetUsername;
    document.getElementById('private-chat-target-name').textContent = 'دردشة خاصة مع: ' + targetUsername;

    const box = document.getElementById('private-msg-box');
    box.innerHTML = '';

    const history = privateChatMessages[targetUsername] || [];
    history.forEach(m => appendPrivateMsgBubble(m, m.from === currentUser.username));

    document.getElementById('private-chat-modal').classList.remove('hidden');
    document.getElementById('private-chats-list').classList.add('hidden');

    // Clear unread indicator if opening this chat
    clearPrivateUnread(targetUsername);
}

function closePrivateChatModal() {
    document.getElementById('private-chat-modal').classList.add('hidden');
    activePrivateChatUser = null;
}

function sendPrivateMsg() {
    if (!activePrivateChatUser || !currentUser) return;
    if (!checkSpamLimit()) return;

    const input = document.getElementById('private-msg-input');
    const rawText = input.value.trim();
    if (!rawText) return;

    const text = filterProfanity(rawText.slice(0, 1000));
    const ts = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    const msgObj = { from: currentUser.username, text, ts };

    if (!privateChatMessages[activePrivateChatUser]) privateChatMessages[activePrivateChatUser] = [];
    privateChatMessages[activePrivateChatUser].push(msgObj);
    appendPrivateMsgBubble(msgObj, true);

    broadcastPacket({
        type: 'private_msg',
        payload: {
            to: activePrivateChatUser,
            from: currentUser.username,
            text,
            timestamp: ts
        }
    });

    input.value = '';
}

function appendPrivateMsgBubble(msgObj, isMe) {
    const box = document.getElementById('private-msg-box');
    if (!box) return;
    const div = document.createElement('div');
    div.className = 'flex flex-col ' + (isMe ? 'items-end' : 'items-start');

    const meta = document.createElement('span');
    meta.className = 'text-[9px] text-stone-600 mb-0.5';
    meta.textContent = escapeHtml(msgObj.from) + ' · ' + (msgObj.ts || '');

    const bubble = document.createElement('div');
    bubble.className = 'px-3 py-1.5 rounded-xl text-xs max-w-xs ' +
        (isMe ? 'bg-stone-800 text-stone-200 rounded-tr-none' : 'bg-stone-950 text-stone-400 rounded-tl-none border border-stone-900');
    bubble.textContent = msgObj.text; // textContent avoids XSS

    div.appendChild(meta);
    div.appendChild(bubble);
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

function togglePrivateList() {
    isPrivateListOpen = !isPrivateListOpen;
    const el = document.getElementById('private-chats-list');
    el.classList.toggle('hidden', !isPrivateListOpen);
    if (isPrivateListOpen) {
        isNotificationPanelOpen = false;
        document.getElementById('notification-panel').classList.add('hidden');
        updatePrivateList();
    }
}

function updatePrivateList() {
    const container = document.getElementById('private-list-container');
    if (!container) return;
    const users = Object.keys(privateChatMessages);
    if (users.length === 0) {
        container.innerHTML = '<p class="text-center text-stone-700 text-[10px]">لا توجد رسائل خاصة</p>';
        return;
    }
    container.innerHTML = '';
    users.forEach(username => {
        const msgs = privateChatMessages[username];
        const last = msgs[msgs.length - 1];
        const btn = document.createElement('button');
        btn.className = 'w-full text-right p-2 bg-stone-900/50 hover:bg-stone-900 rounded text-[10px] text-stone-400 border border-stone-900/50 flex flex-col gap-0.5';
        // Use textContent to prevent XSS from peer-supplied usernames / message text
        const nameSpan = document.createElement('span');
        nameSpan.className = 'font-bold text-stone-300';
        nameSpan.textContent = username;
        const previewSpan = document.createElement('span');
        previewSpan.className = 'text-stone-600 truncate';
        previewSpan.textContent = last ? (last.text || '').substring(0, 30) : '';
        btn.appendChild(nameSpan);
        btn.appendChild(previewSpan);
        btn.onclick = () => openPrivateChatWith(username);
        container.appendChild(btn);
    });
}

function clearPrivateUnread(username) {
    // reset badge when user opens the chat
    unreadPrivateCount = 0;
    updatePrivateNotificationBadge();
    const dot = document.getElementById('private-notification-dot');
    const icon = document.getElementById('private-chat-icon');
    dot.classList.remove('active');
    icon.classList.remove('has-unread');
}

function updatePrivateNotificationBadge() {
    const badge = document.getElementById('private-unread-count');
    if (!badge) return;
    if (unreadPrivateCount > 0) {
        badge.textContent = unreadPrivateCount > 99 ? '99+' : unreadPrivateCount;
        badge.classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}

/* ══════════════════════════════════════════════════════════════
   § LIVE UPDATES / NOTIFICATIONS
══════════════════════════════════════════════════════════════ */
function showLiveUpdate(text) {
    const bar = document.getElementById('live-updates-bar');
    const ticker = document.getElementById('live-updates-ticker');
    if (!bar || !ticker) return;
    bar.classList.remove('hidden');
    ticker.style.opacity = '0';
    setTimeout(() => {
        ticker.textContent = text;
        ticker.style.opacity = '1';
    }, 200);
}

function addNotification(text) {
    notifications.unshift({ text, ts: new Date().toLocaleTimeString() });
    if (notifications.length > 50) notifications.pop();

    const badge = document.getElementById('notification-badge');
    if (badge) {
        const cnt = parseInt(badge.textContent || '0') + 1;
        badge.textContent = cnt;
        badge.classList.remove('hidden');
    }

    if (isNotificationPanelOpen) renderNotificationList();
}

function renderNotificationList() {
    const list = document.getElementById('notification-list');
    if (!list) return;
    list.innerHTML = '';
    notifications.slice(0, 20).forEach(n => {
        const el = document.createElement('div');
        el.className = 'text-[10px] text-stone-500 border-b border-stone-900/40 py-1 flex justify-between gap-2';
        // textContent prevents XSS from sender names embedded in notification text
        const textSpan = document.createElement('span');
        textSpan.className = 'flex-1';
        textSpan.textContent = n.text || '';
        const tsSpan = document.createElement('span');
        tsSpan.className = 'text-stone-700 flex-shrink-0';
        tsSpan.textContent = n.ts || '';
        el.appendChild(textSpan);
        el.appendChild(tsSpan);
        list.appendChild(el);
    });
}

function toggleNotificationPanel() {
    isNotificationPanelOpen = !isNotificationPanelOpen;
    const panel = document.getElementById('notification-panel');
    panel.classList.toggle('hidden', !isNotificationPanelOpen);
    if (isNotificationPanelOpen) {
        isPrivateListOpen = false;
        document.getElementById('private-chats-list').classList.add('hidden');
        renderNotificationList();
        const badge = document.getElementById('notification-badge');
        if (badge) { badge.textContent = '0'; badge.classList.add('hidden'); }
    }
}

/* ══════════════════════════════════════════════════════════════
   § GHOST BOT
══════════════════════════════════════════════════════════════ */
const GHOST_MESSAGES = [
    '... لا تخف ... أنا لست هنا',
    'هَلْ سَمِعْتَ ذلك؟',
    '...وجودُك يُقلقني...',
    'الباب خلفك ... أغلِق أعينك',
    'لستَ وحدك في هذا الظلام.',
    '..خُذْ نَفَساً عميقاً قبل أن يُسرق منك..',
    'أنا أراك. أنت لا تراني.',
    '...رُوحُ مَيِّت تجلس بجانبك الآن...',
    'هَمَسَ لي جدارُ الغرفة باسمك.',
    '☠ أنتَ التالي ☠',
];

function startGhostBotIfAlone() {
    const peerCount = Object.keys(activeConnections).length;
    if (peerCount === 0 && !ghostBotActive) {
        ghostBotActive = true;
        ghostBotTimer = setTimeout(() => {
            scheduleNextGhostMsg();
        }, 8000);
    }
}

function stopGhostBotIfNeeded() {
    const peerCount = Object.keys(activeConnections).length;
    if (peerCount > 0) stopGhostBot();
}

function stopGhostBot() {
    ghostBotActive = false;
    if (ghostBotTimer) { clearTimeout(ghostBotTimer); ghostBotTimer = null; }
}

function scheduleNextGhostMsg() {
    if (!ghostBotActive) return;
    const delay = 8000 + Math.random() * 12000;
    ghostBotTimer = setTimeout(() => {
        if (!ghostBotActive) return;
        const text = GHOST_MESSAGES[Math.floor(Math.random() * GHOST_MESSAGES.length)];
        const ghostNames = ['☠ شبح_مجهول', '☠ الأرواح_التائهة', '☠ صوت_الظلام'];
        const ghostName = ghostNames[Math.floor(Math.random() * ghostNames.length)];
        renderGhostBotMessage(ghostName, text);
        scheduleNextGhostMsg();
    }, delay);
}

function renderGhostBotMessage(name, text) {
    const box = document.getElementById('chat-box');
    if (!box) return;
    const card = document.createElement('div');
    card.className = 'p-3 rounded-xl max-w-xs space-y-1 border text-right self-start ghost-bot-message msg-card';

    const headerDiv = document.createElement('div');
    headerDiv.className = 'flex justify-between items-center border-b border-red-900/20 pb-1 mb-1';

    const nameSpan = document.createElement('span');
    nameSpan.className = 'text-[10px] font-bold text-red-800 flex items-center gap-1';
    const ghostI = document.createElement('i');
    ghostI.className = 'fa-solid fa-ghost text-[9px] animate-pulse';
    nameSpan.appendChild(ghostI);
    nameSpan.appendChild(document.createTextNode(' ' + (name || '')));

    const tsSpan = document.createElement('span');
    tsSpan.className = 'text-[8px] text-stone-700 font-mono';
    tsSpan.textContent = new Date().toLocaleTimeString('ar-EG', {hour:'2-digit', minute:'2-digit'});

    headerDiv.appendChild(nameSpan);
    headerDiv.appendChild(tsSpan);

    const textP = document.createElement('p');
    textP.className = 'text-xs text-red-900 italic leading-relaxed';
    textP.textContent = text || '';

    card.appendChild(headerDiv);
    card.appendChild(textP);
    box.appendChild(card);
    scrollChatToBottom();
    playHorrorMsgSound();
}

/* ══════════════════════════════════════════════════════════════
   § MESSAGE RENDERING
══════════════════════════════════════════════════════════════ */
function renderSingleMessage(m) {
    const box = document.getElementById('chat-box');
    if (!box) return;

    const isMe = currentUser && m.sender === currentUser.username;
    const isOwnerMsg = isOwner(m.sender) && (isMe || m.verifiedOwner === true);
    const avatarUrl = 'https://api.dicebear.com/7.x/bottts/svg?seed=' + encodeURIComponent(m.sender || 'ghost');

    const card = document.createElement('div');
    card.id = 'msg-' + m.id;
    card.className = 'msg-card p-3 rounded-xl max-w-sm space-y-1 transition border text-right relative ' +
        (isOwnerMsg
            ? 'bg-gradient-to-br from-red-950/50 via-purple-950/40 to-stone-950 self-center w-full owner-glow-bubble'
            : isMe
                ? 'bg-stone-900/40 border-stone-800 self-end'
                : 'bg-stone-950/60 border-stone-900/60 self-start');

    /* ── Sender span (DOM-built to prevent XSS) ── */
    const senderSpan = document.createElement('span');
    senderSpan.className = isOwnerMsg
        ? 'text-[10px] font-black text-red-500 tracking-widest flex items-center gap-1 cursor-pointer'
        : 'text-[10px] font-bold text-stone-500 flex items-center gap-1 cursor-pointer';
    // Store data in dataset instead of inline handlers
    senderSpan.dataset.sender = m.sender || '';
    senderSpan.dataset.role   = m.role || '';
    senderSpan.dataset.avatar = avatarUrl;
    senderSpan.addEventListener('click', (e) => {
        e.stopPropagation();
        openUserPopupMenu(e, senderSpan.dataset.sender, senderSpan.dataset.role, senderSpan.dataset.avatar);
    });

    const avi = document.createElement('img');
    avi.src = avatarUrl;
    avi.className = isOwnerMsg
        ? 'w-4 h-4 rounded-full border border-red-900 animate-spin'
        : 'w-4 h-4 rounded-full border border-stone-800';
    senderSpan.appendChild(avi);

    if (isOwnerMsg) {
        senderSpan.appendChild(document.createTextNode(' ☆ ' + (m.sender || '') + ' 👑'));
    } else {
        senderSpan.appendChild(document.createTextNode(' ' + (m.sender || '')));
        const roleTag = document.createElement('span');
        roleTag.className = 'text-[8px] text-stone-600';
        roleTag.textContent = '[' + (m.level || 0) + '] ' + (m.role || '');
        senderSpan.appendChild(roleTag);
        const dots = document.createElement('i');
        dots.className = 'fa-solid fa-ellipsis-vertical text-[9px] text-stone-700';
        senderSpan.appendChild(dots);
    }

    /* ── Timestamp ── */
    const tsSpan = document.createElement('span');
    tsSpan.className = 'text-[8px] text-stone-700 font-mono';
    tsSpan.textContent = m.timestamp || '';

    /* ── Header row ── */
    const header = document.createElement('div');
    header.className = 'flex justify-between items-center gap-4 border-b border-stone-900 pb-1 mb-1';
    const tsWrap = document.createElement('div');
    tsWrap.className = 'flex items-center gap-1 flex-shrink-0';
    tsWrap.appendChild(tsSpan);
    header.appendChild(senderSpan);
    header.appendChild(tsWrap);

    /* ── Body ── */
    let bodyEl;
    if (m.viewOnce && m.burned) {
        bodyEl = document.createElement('p');
        bodyEl.className = 'text-xs text-red-800/80 italic';
        bodyEl.textContent = '🔥 احترق هذا الأثر.';
    } else if (m.viewOnce) {
        bodyEl = document.createElement('div');
        bodyEl.id = 'burn-area-' + m.id;
        const burnInfo = document.createElement('p');
        burnInfo.className = 'text-xs text-red-400/80 italic flex items-center gap-1.5';
        const skullI = document.createElement('i');
        skullI.className = 'fa-solid fa-skull animate-pulse';
        burnInfo.appendChild(skullI);
        burnInfo.appendChild(document.createTextNode(' أثر محمي (رؤية لمرة واحدة)'));
        const burnBtn = document.createElement('button');
        burnBtn.className = 'bg-red-950/40 border border-red-900/50 hover:bg-red-900 text-red-200 text-[10px] px-2.5 py-1 rounded mt-1';
        burnBtn.textContent = 'اضغط لقراءة الأثر وفنائه';
        burnBtn.dataset.msgid = m.id;
        burnBtn.addEventListener('click', (e) => { e.stopPropagation(); revealAndBurn(burnBtn.dataset.msgid); });
        bodyEl.appendChild(burnInfo);
        bodyEl.appendChild(burnBtn);
    } else {
        bodyEl = document.createElement('p');
        bodyEl.className = 'msg-body text-xs leading-relaxed ' + (isOwnerMsg ? 'text-stone-300' : 'text-stone-400');
        bodyEl.textContent = m.text || ''; // textContent — zero XSS risk
        if (m.attachmentPending) {
            const pg = document.createElement('span');
            pg.id = 'att-prog-' + m.id; pg.className = 'block text-[10px] text-amber-700 mt-1';
            pg.textContent = '⏳ جاري استقبال المرفق 0%';
            bodyEl.appendChild(pg);
        } else if (m.attachmentType && m.attachmentData) {
            // buildAttachmentElement builds DOM node directly — no innerHTML with attachment data
            const attEl = buildAttachmentElement(m.attachmentType, m.attachmentData, m.attachmentName);
            bodyEl.appendChild(attEl);
        }
    }

    /* ── Reactions ── */
    const reactionsDiv = document.createElement('div');
    reactionsDiv.id = 'reactions-' + m.id;
    reactionsDiv.className = 'flex flex-wrap gap-1 mt-1 min-h-[1px]';

    card.appendChild(header);
    card.appendChild(bodyEl);
    card.appendChild(reactionsDiv);

    card.addEventListener('click', (e) => {
        e.stopPropagation();
        openMsgOptions(m.id, m.viewOnce ? '' : m.text, m.sender);
    });

    box.appendChild(card);
}

function renderAllMessages(msgs) {
    const box = document.getElementById('chat-box');
    if (!box) return;
    box.innerHTML = '';
    msgs.forEach(m => renderSingleMessage(m));
}



// Legacy helper kept for any remaining call sites (no longer used in main render path)
function buildAttachmentHtml(type, data) {
    const el = buildAttachmentElement(type, data);
    const wrapper = document.createElement('div');
    wrapper.appendChild(el);
    return wrapper.innerHTML; // el was built from validated data — safe
}

function scrollChatToBottom() {
    const outer = document.getElementById('chat-box-outer');
    if (outer) requestAnimationFrame(() => { outer.scrollTop = outer.scrollHeight; });
}

function appendSystemMessage(txt) {
    const box = document.getElementById('chat-box');
    if (!box) return;
    const item = document.createElement('div');
    item.className = 'text-[10px] text-stone-600 bg-stone-900/10 border border-stone-900/40 p-1.5 rounded-lg text-center self-center w-4/5 my-1 italic';
    item.innerText = txt;
    box.appendChild(item);
    scrollChatToBottom();
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}


/* ══════════════════════════════════════════════════════════════
   § MESSAGE OPTIONS
══════════════════════════════════════════════════════════════ */
function openMsgOptions(msgId, text, sender) {
    selectedMsgId = msgId;
    window._selectedMsgText = text;
    window._selectedMsgSender = sender;

    const adminBtn = document.getElementById('admin-delete-msg-btn');
    if (adminBtn) adminBtn.classList.toggle('hidden', !isAdmin());

    document.getElementById('msg-options-modal').classList.remove('hidden');
}

function closeOptions() {
    document.getElementById('msg-options-modal').classList.add('hidden');
}

function copyMessageText() {
    if (window._selectedMsgText) {
        navigator.clipboard.writeText(window._selectedMsgText).catch(() => {});
    }
    closeOptions();
}

function reactToMessage(emoji) {
    if (!selectedMsgId) return;
    handleReactionPacket({ msgId: selectedMsgId, emoji });
    broadcastPacket({ type: 'reaction', payload: { msgId: selectedMsgId, emoji } });
    closeOptions();
}

function reportToAdmins() {
    const txt = window._selectedMsgText || '';
    appendSystemMessage('📋 تم إرسال البلاغ بشأن الرسالة: "' + txt.substring(0, 30) + '"...');
    closeOptions();
}

function adminDeleteSelectedMsg() {
    if (!isAdmin() || !selectedMsgId) return;
    handleDeleteMsgPacket({ msgId: selectedMsgId });
    broadcastPacket({ type: 'delete_msg', payload: { msgId: selectedMsgId } });
    closeOptions();
}

/* ══════════════════════════════════════════════════════════════
   § USER POPUP MENU
══════════════════════════════════════════════════════════════ */
function openUserPopupMenu(event, username, role, avatarUrl) {
    event.stopPropagation();
    if (!currentUser || username === currentUser.username) return;

    selectedPopupUser = { username, role, avatarUrl };
    document.getElementById('popup-user-name').textContent = username;
    document.getElementById('popup-user-role').textContent = role;
    document.getElementById('popup-user-avatar').src = avatarUrl;
    const ownerBtn = document.getElementById('popup-owner-mod-btn');
    if (ownerBtn) ownerBtn.classList.toggle('hidden', !isAdmin());

    const menu = document.getElementById('user-popup-menu');
    menu.style.top = (event.clientY + 5) + 'px';
    menu.style.left = (event.clientX - 200) + 'px';
    menu.classList.remove('hidden');
}

function actionFromPopup(action) {
    const menu = document.getElementById('user-popup-menu');
    menu.classList.add('hidden');
    if (!selectedPopupUser) return;
    const { username, role, avatarUrl } = selectedPopupUser;

    if (action === 'pm') {
        openPrivateChatWith(username);
    } else if (action === 'profile') {
        alert(`ملف ${username}\nالرتبة: ${role}\n(الملف الشخصي مخصص)`);
    } else if (action === 'owner_mod') {
        openOwnerModeration(username);
    }
}

function openOwnerModeration(targetUsername) {
    modTargetUsername = targetUsername;
    document.getElementById('mod-target-username').textContent = targetUsername;
    document.getElementById('owner-moderation-modal').classList.remove('hidden');
}

function closeOwnerModeration() {
    document.getElementById('owner-moderation-modal').classList.add('hidden');
    modTargetUsername = null;
}

function executeOwnerWarning() {
    if (!modTargetUsername) return;
    const message = prompt('أدخل نص الإنذار المرعب:');
    if (!message) return;
    broadcastPacket({ type: 'owner_warning', payload: { target: modTargetUsername, message } });
    appendSystemMessage('⚠️ أرسلت إنذاراً رسمياً لـ ' + modTargetUsername);
    closeOwnerModeration();
}

function executeOwnerBan() {
    if (!modTargetUsername) return;
    const duration = document.getElementById('ban-duration-select').value;
    broadcastPacket({ type: 'force_ban_signal', payload: { target: modTargetUsername, expiry: duration } });
    appendSystemMessage('🚫 تم تطبيق الحظر على ' + modTargetUsername);
    showLiveUpdate('🚫 تم حظر ' + modTargetUsername);
    closeOwnerModeration();
}

/* ══════════════════════════════════════════════════════════════
   § HIGH-LEVEL FEATURES
══════════════════════════════════════════════════════════════ */

// — Curse System —
function triggerCurseSystem() {
    if (!currentUser) return;
    if (!isOwner() && currentUser.level < 50) {
        triggerFirewallModal('قفل الميزة: تحتاج مستوى 50 أو أعلى لاستخدام نظام اللعنات.'); return;
    }
    const cost = isOwner() ? 0 : 5000;
    if (!isOwner() && getCoins() < cost) {
        triggerFirewallModal('رصيد غير كافٍ. تحتاج 5000 ذهبة لتفعيل اللعنة.'); return;
    }
    const target = prompt('أدخل اسم المستخدم الذي تريد لعنه (تعطيل شاته):');
    if (!target) return;
    const duration = parseInt(prompt('مدة اللعنة بالثواني (10-120):') || '30');
    if (!isOwner()) deductCoins(cost);
    broadcastPacket({ type: 'curse', payload: { target, duration: Math.min(120, Math.max(10, duration)) } });
    appendSystemMessage('💀 أرسلت لعنة إلى ' + target + ' لمدة ' + duration + ' ثانية!');
    showLiveUpdate('💀 لعنة أُطلقت على ' + target + '!');
}

// — Séance Global Event —
function triggerSeanceEvent() {
    if (!currentUser) return;
    if (!isOwner() && currentUser.level < 70) {
        triggerFirewallModal('قفل الميزة: تحتاج مستوى 70 أو أعلى لاستحضار الأرواح.'); return;
    }
    const cost = isOwner() ? 0 : 10000;
    if (!isOwner() && getCoins() < cost) {
        triggerFirewallModal('رصيد غير كافٍ. تحتاج 10000 ذهبة.'); return;
    }
    if (!isOwner()) deductCoins(cost);
    const duration = 30;
    broadcastPacket({ type: 'seance', payload: { duration } });
    activateSeanceEffect(duration);
    showLiveUpdate('👻 ' + currentUser.username + ' بدأ استحضاراً جماعياً للأرواح!');
    setTimeout(() => {
        broadcastPacket({ type: 'seance_end', payload: {} });
    }, (duration + 1) * 1000);
}

// — Distorted Voice Chat —
function triggerDistortedVoice() {
    if (!currentUser) return;
    if (!isOwner() && currentUser.level < 60) {
        triggerFirewallModal('قفل الميزة: تحتاج مستوى 60 أو أعلى للمحادثة الصوتية المشوهة.'); return;
    }
    const cost = 3000;
    if (!isOwner() && getCoins() < cost) {
        triggerFirewallModal('رصيد غير كافٍ. تحتاج 3000 ذهبة للمحادثة الصوتية المشوهة.'); return;
    }
    const remoteId = prompt('أدخل معرف المستخدم الذي تريد الاتصال به صوتياً:');
    if (!remoteId) return;
    if (!isOwner()) deductCoins(cost);
    startDistortedVoiceCall(remoteId);
}

function startDistortedVoiceCall(remoteId) {
    navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const source = ctx.createMediaStreamSource(stream);

        // Distortion + echo
        const distortion = ctx.createWaveShaper();
        distortion.curve = makeDistortionCurve(300);
        distortion.oversample = '4x';

        const delay = ctx.createDelay(0.5);
        delay.delayTime.setValueAtTime(0.35, ctx.currentTime);

        const feedback = ctx.createGain();
        feedback.gain.setValueAtTime(0.5, ctx.currentTime);

        const pitchShift = ctx.createBiquadFilter();
        pitchShift.type = 'peaking';
        pitchShift.frequency.setValueAtTime(200, ctx.currentTime);
        pitchShift.gain.setValueAtTime(-12, ctx.currentTime);

        source.connect(distortion);
        distortion.connect(pitchShift);
        pitchShift.connect(delay);
        delay.connect(feedback);
        feedback.connect(delay);

        const dest = ctx.createMediaStreamDestination();
        pitchShift.connect(dest);
        delay.connect(dest);

        const call = peer.call(remoteId, dest.stream);
        call.on('stream', (remoteStream) => {
            const audio = new Audio();
            audio.srcObject = remoteStream;
            audio.play();
        });
        call.on('close', () => { stream.getTracks().forEach(t => t.stop()); ctx.close(); });
        activeVoiceCall = call;
        voiceAudioContext = ctx;
        appendSystemMessage('📞 اتصال صوتي مشوه نشط مع ' + remoteId);
    }).catch(err => {
        alert('فشل الوصول للميكروفون: ' + err.message);
    });
}

function handleIncomingVoiceCall(call) {
    if (!confirm('📞 اتصال صوتي مشوه وارد. قبول؟')) { call.close(); return; }
    navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
        call.answer(stream);
        call.on('stream', (remoteStream) => {
            const audio = new Audio();
            audio.srcObject = remoteStream;
            audio.play();
        });
        appendSystemMessage('📞 قبلت اتصالاً صوتياً مشوهاً.');
    });
}

function makeDistortionCurve(amount) {
    const k = typeof amount === 'number' ? amount : 50;
    const n_samples = 256;
    const curve = new Float32Array(n_samples);
    const deg = Math.PI / 180;
    for (let i = 0; i < n_samples; ++i) {
        const x = (i * 2) / n_samples - 1;
        curve[i] = (3 + k) * x * 20 * deg / (Math.PI + k * Math.abs(x));
    }
    return curve;
}

// — Ouija Board —
function triggerOuijaBoard() {
    if (!currentUser) return;
    if (!isOwner() && currentUser.level < 55) {
        triggerFirewallModal('قفل الميزة: تحتاج مستوى 55 لتفعيل لوحة الـ Ouija.'); return;
    }
    const cost = isOwner() ? 0 : 4000;
    if (!isOwner() && getCoins() < cost) {
        triggerFirewallModal('رصيد غير كافٍ. تحتاج 4000 ذهبة.'); return;
    }
    if (!isOwner()) deductCoins(cost);
    ouijaActive = true;
    ouijaLetterBuffer = '';
    document.getElementById('ouija-modal').classList.remove('hidden');
    showLiveUpdate('🔮 ' + currentUser.username + ' فتح لوحة الـ Ouija!');
}

function closeOuijaBoard() {
    ouijaActive = false;
    document.getElementById('ouija-modal').classList.add('hidden');
}

function broadcastOuijaMove(event) {
    if (!ouijaActive) return;
    const board = document.getElementById('ouija-board');
    if (!board) return;
    const rect = board.getBoundingClientRect();
    const xRatio = (event.clientX - rect.left) / rect.width;
    const yRatio = (event.clientY - rect.top) / rect.height;

    // Move local planchette
    const planchette = document.getElementById('ouija-planchette');
    if (planchette) {
        planchette.style.left = (xRatio * rect.width) + 'px';
        planchette.style.top = (yRatio * rect.height) + 'px';
    }
    detectOuijaLetter(xRatio, yRatio);

    broadcastPacket({ type: 'ouija_move', payload: { xRatio, yRatio } });
}

// — Killer Game —
function triggerKillerGame() {
    if (!currentUser) return;
    if (!isOwner() && currentUser.level < 80) {
        triggerFirewallModal('قفل الميزة: تحتاج مستوى 80 لتفعيل لعبة القاتل الخفي.'); return;
    }
    const cost = isOwner() ? 0 : 8000;
    if (!isOwner() && getCoins() < cost) {
        triggerFirewallModal('رصيد غير كافٍ. تحتاج 8000 ذهبة.'); return;
    }
    document.getElementById('killer-game-modal').classList.remove('hidden');
    document.getElementById('killer-game-content').innerHTML = '<p class="text-stone-500">اضغط "بدء اللعبة" لتوزيع الأدوار على جميع المتصلين.</p>';
}

function startKillerGame() {
    if (!isOwner() && getCoins() < 8000) { closeKillerGame(); return; }
    if (!isOwner()) deductCoins(8000);

    const players = [currentUser.username, ...Object.values(activeConnections).map(c => c.peer.substring(0, 8))];
    if (players.length < 2) {
        alert('تحتاج لاعبَين على الأقل!'); return;
    }
    const killerIndex = Math.floor(Math.random() * players.length);
    const roles = {};
    players.forEach((p, i) => { roles[p] = i === killerIndex ? 'قاتل' : 'ضحية'; });

    broadcastPacket({ type: 'killer_game_start', payload: { roles } });
    handleKillerGameStart({ roles });
    closeKillerGame();
}

function closeKillerGame() {
    document.getElementById('killer-game-modal').classList.add('hidden');
}

/* ══════════════════════════════════════════════════════════════
   § COINS HELPERS
══════════════════════════════════════════════════════════════ */
function getCoins() {
    return parseInt(localStorage.getItem('horror_user_coins') || '0');
}

function deductCoins(amount) {
    const cur = getCoins();
    const newAmt = Math.max(0, cur - amount);
    localStorage.setItem('horror_user_coins', newAmt);
    document.getElementById('user-coins').innerText = newAmt;
    if (currentUser) currentUser.coins = newAmt;
}

function addCoins(amount) {
    const cur = getCoins();
    const newAmt = cur + amount;
    localStorage.setItem('horror_user_coins', newAmt);
    document.getElementById('user-coins').innerText = newAmt;
    if (currentUser) currentUser.coins = newAmt;
}

/* ══════════════════════════════════════════════════════════════
   § AUTH & LOGIN
══════════════════════════════════════════════════════════════ */
function switchTab(mode) {
    authMode = mode;
    const vBtn = document.getElementById('tab-visitor');
    const rBtn = document.getElementById('tab-register');
    const extended = document.getElementById('extended-fields');
    if (mode === 'visitor') {
        vBtn.className = 'w-1/2 py-1.5 text-xs font-bold rounded bg-stone-900 text-stone-300 transition-all';
        rBtn.className = 'w-1/2 py-1.5 text-xs font-bold rounded text-stone-600 transition-all';
        extended.classList.add('hidden');
    } else {
        rBtn.className = 'w-1/2 py-1.5 text-xs font-bold rounded bg-stone-900 text-stone-300 transition-all';
        vBtn.className = 'w-1/2 py-1.5 text-xs font-bold rounded text-stone-600 transition-all';
        extended.classList.remove('hidden');
    }
}

async function handleAuth(event) {
    event.preventDefault();
    const username = sanitizeName(document.getElementById('login-username').value);
    const errorDiv = document.getElementById('login-error');

    if (!username) return;

    if (OWNER_NAMES.includes(username)) {
        let k = await importOwnerKey(localStorage.getItem('hdc_owner_key') || '');
        if (!k) {
            const pasted = prompt('هذا الاسم محجوز للمالك. الصق مفتاح المالك الخاص:');
            if (pasted) { k = await importOwnerKey(pasted); if (k) localStorage.setItem('hdc_owner_key', pasted.trim()); }
        }
        if (!k) { errorDiv.textContent = 'هذا الاسم محجوز للمالك ولا يمكن استخدامه.'; errorDiv.classList.remove('hidden'); return; }
        ownerPrivateKey = k;
    }

    // Check ban
    const banExpiry = localStorage.getItem('banned_' + username);
    if (banExpiry && banExpiry !== 'permanent' && Date.now() < parseInt(banExpiry)) {
        const remaining = Math.ceil((parseInt(banExpiry) - Date.now()) / 60000);
        errorDiv.textContent = `أنت محظور! ينتهي حظرك بعد ${remaining} دقيقة.`;
        errorDiv.classList.remove('hidden');
        return;
    }
    if (banExpiry === 'permanent') {
        errorDiv.textContent = 'أنت محظور نهائياً من هذه الغرفة.';
        errorDiv.classList.remove('hidden');
        return;
    }

    const savedData = localStorage.getItem('horror_user_' + username);
    let coins = parseInt(localStorage.getItem('horror_user_coins') || '0');
    let level = 1;
    let role = '👁️ زائر';
    let exp = 0;

    if (savedData) {
        try {
            const d = JSON.parse(savedData);
            coins = d.coins || coins;
            level = d.level || level;
            role = d.role || role;
            exp = d.exp || 0;
        } catch(e) {}
    }

    if (authMode === 'register') {
        role = '⛓️ عضو حزين';
        level = Math.max(level, 1);
    }

    if (isOwner(username)) {
        role = '👑 المالك';
        level = 100;
        coins = coins < 9999999 ? 9999999 : coins;
        localStorage.setItem('horror_user_coins', coins);
    }

    currentUser = { username, role, level, coins, exp };
    localStorage.setItem('horror_user_' + username, JSON.stringify({ coins, level, role, exp }));
    localStorage.setItem('horror_user_coins', coins);

    document.getElementById('profile-display-name').textContent = username;
    document.getElementById('profile-display-role').textContent = role;
    document.getElementById('user-level').textContent = level;
    document.getElementById('user-coins').textContent = coins;
    document.getElementById('edit-username-btn').classList.remove('hidden');

    if (isAdmin()) {
        document.getElementById('admin-panel').classList.remove('hidden');
        document.getElementById('owner-cms-section').classList.remove('hidden');
        document.getElementById('owner-send-coins-btn').classList.remove('hidden');
        document.getElementById('owner-marquee-edit').classList.remove('hidden');
    }

    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('live-updates-bar').classList.remove('hidden');

    initPeer();
    setupViewportFix();
    renderPremiumFeatures();
    checkDailyRewardStatus();
    renderMarqueeContent();

    dbLoadMessages(currentRoom ? currentRoom.name : 'public').then(msgs => {
        renderAllMessages(msgs);
        scrollChatToBottom();
    });

    // Become host if alone initially
    isHost = true;
    hostPeerId = null; // will be set once peer opens
    peer.on('open', (id) => {
        hostPeerId = id;
        document.getElementById('host-badge').classList.remove('hidden');
        showLiveUpdate('👑 أنت مضيف الغرفة.');
    });

    appendSystemMessage('☣ دخلت غرفة الموت. مرحباً، ' + username + ' ☠');
    showLiveUpdate('☣ ' + username + ' دخل الظلام...');

    // Start ghost bot after a delay if alone
    setTimeout(startGhostBotIfAlone, 12000);
}

/* ══════════════════════════════════════════════════════════════
   § VIEW-ONCE
══════════════════════════════════════════════════════════════ */
function toggleViewOnce() {
    if (!isOwner() && currentUser && currentUser.level < 1) {
        triggerFirewallModal('جدار الحماية: المستوى 0 لا يمكنه استخدام الرؤية لمرة واحدة.'); return;
    }
    viewOnceActive = !viewOnceActive;
    const btn = document.getElementById('view-once-btn');
    btn.className = viewOnceActive
        ? 'p-2 bg-red-950 text-red-500 rounded border border-red-900 transition shadow-[0_0_10px_rgba(220,38,38,0.4)] flex-shrink-0'
        : 'p-2 bg-stone-900 text-stone-600 hover:text-stone-400 rounded border border-stone-800 transition flex-shrink-0';
}

/* ══════════════════════════════════════════════════════════════
   § ATTACHMENTS
══════════════════════════════════════════════════════════════ */
function triggerAttachment(type) {
    if (!currentUser || (currentUser.level < 1 && !isOwner())) {
        triggerFirewallModal('جدار الحماية: لا تملك صلاحية إرسال المرفقات بمستواك الحالي.'); return;
    }
    const inputs = { image: 'attach-image-input', audio: 'attach-audio-input', video: 'attach-video-input' };
    const el = document.getElementById(inputs[type]);
    if (el) el.click();
}


/* ══════════════════════════════════════════════════════════════
   § AVATAR
══════════════════════════════════════════════════════════════ */
function triggerAvatarChange() {
    if (!currentUser) return;
    if (currentUser.level < 10 && !isOwner()) {
        triggerFirewallModal('جدار الحماية: تحتاج لمستوى 10 لتغيير الصورة الشخصية.'); return;
    }
    document.getElementById('avatar-file-input').click();
}

function uploadAvatar(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        document.getElementById('profile-avatar').src = e.target.result;
        localStorage.setItem('horror_avatar_' + currentUser.username, e.target.result);
    };
    reader.readAsDataURL(file);
    input.value = '';
}

function loadSavedAvatar() {
    if (!currentUser) return;
    const saved = localStorage.getItem('horror_avatar_' + currentUser.username);
    if (saved) document.getElementById('profile-avatar').src = saved;
}

/* ══════════════════════════════════════════════════════════════
   § ROOMS
══════════════════════════════════════════════════════════════ */
function createNewRoom() {
    if (!currentUser) return;
    if (!isOwner() && currentUser.level < 75) {
        triggerFirewallModal('قفل الميزة: تحتاج مستوى 75 لإنشاء الغرف السرية.'); return;
    }
    const cost = 6000;
    if (!isOwner() && getCoins() < cost) {
        alert('لا تملك ذهباً كافياً! تكلفة إنشاء الغرفة 6000 ذهبة.'); return;
    }
    const name = document.getElementById('new-room-name').value.trim();
    const pass = document.getElementById('new-room-pass').value.trim();
    if (!name) return;

    if (!isOwner()) deductCoins(cost);
    currentRoom = { name, pass };
    isHost = true;
    if (peer) hostPeerId = peer.id;
    document.getElementById('host-badge').classList.remove('hidden');
    appendSystemMessage('🔒 تم إنشاء الغرفة السرية: ' + name);

    const list = document.getElementById('local-rooms-list');
    const btn = document.createElement('button');
    btn.className = 'w-full text-right p-1 bg-stone-900 hover:bg-stone-800 rounded text-[10px] text-stone-400 block truncate';
    btn.textContent = '🔒 ' + name;
    btn.onclick = () => joinEncryptedRoom(name, pass);
    list.appendChild(btn);
}

function joinEncryptedRoom(name, pass) {
    if (pass) {
        const check = prompt('أدخل الرقم السري لدخول الغرفة:');
        if (check !== pass) { alert('الرمز السري خاطئ!'); return; }
    }
    currentRoom = { name, pass };
    appendSystemMessage('✅ دخلت الغرفة المشفرة: ' + name);
}

/* ══════════════════════════════════════════════════════════════
   § CONNECTION STATUS
══════════════════════════════════════════════════════════════ */
function updateConnectionStatus() {
    const count = Object.keys(activeConnections).length;
    const el = document.getElementById('connection-status');
    if (!el) return;
    if (count === 0) {
        el.textContent = 'وحيد الآن في الظلام...';
        el.className = 'text-[10px] text-stone-600 font-medium';
    } else {
        el.textContent = count + ' روح متصلة الآن';
        el.className = 'text-[10px] text-emerald-800 font-medium';
    }
}

/* ══════════════════════════════════════════════════════════════
   § PREMIUM FEATURES
══════════════════════════════════════════════════════════════ */
const featureNamesByLevel = {
    10: 'ميزة تغيير الصورة الشخصية',
    20: 'ميزة التمرير اللامتناهي الفائق',
    30: 'ميزة إرسال الروابط داخل غرف البث',
    40: 'ميزة تخصيص ألوان النيون للفقاعات',
    50: 'ميزة إرسال ورفع الملفات المضغوطة',
    60: 'ميزة تسجيل المقاطع الصوتية اللحظية',
    70: 'ميزة الردود والاقتباسات الذكية',
    75: 'صلاحية إنشاء الغرف السرية المشفرة',
    85: 'ميزة إخفاء حالة التواجد',
    100: 'التمكين الكامل وكسر كافة حدود الخصوصية'
};

const premiumFeaturesList = [];
for (let i = 1; i <= 100; i++) {
    const targetLevel = Math.min(100, Math.ceil(i * 1.2));
    premiumFeaturesList.push({
        id: i,
        name: featureNamesByLevel[targetLevel] || `حزمة الترقية رقم ${i}`,
        level: targetLevel,
        cost: i * 1500
    });
}

function renderPremiumFeatures() {
    const container = document.getElementById('level-features-buttons-container');
    if (!container) return;
    container.innerHTML = '';
    premiumFeaturesList.slice(0, 20).forEach(f => {
        const btn = document.createElement('button');
        btn.className = 'bg-stone-950 border border-stone-900 rounded p-1 text-[9px] text-right text-stone-400 hover:border-stone-700 transition flex flex-col justify-between';
        btn.onclick = (e) => { e.stopPropagation(); triggerPremiumFeaturePurchase(f); };
        btn.innerHTML = `<span class="truncate text-stone-300 font-bold">${f.name}</span><span class="text-[8px] text-indigo-500">Lv.${f.level} | ${f.cost}⚙</span>`;
        container.appendChild(btn);
    });
}

function triggerPremiumFeaturePurchase(feature) {
    if (isOwner()) { alert(`المالك: ميزة [${feature.name}] مفتوحة لك بالكامل مجاناً.`); return; }
    if (currentUser && currentUser.role.includes('زائر')) {
        triggerFirewallModal('جدار الحماية: الزائر لا يمكنه شراء الميزات.'); return;
    }
    if (currentUser.level < feature.level) {
        triggerFirewallModal(`قفل المستوى: تحتاج مستوى ${feature.level}. مستواك الحالي: ${currentUser.level}.`); return;
    }
    if (getCoins() < feature.cost) {
        triggerFirewallModal(`رصيد غير كافٍ: تحتاج ${feature.cost} ذهبة.`); return;
    }
    deductCoins(feature.cost);
    alert(`تم تفعيل [${feature.name}] بنجاح!`);
}

/* ══════════════════════════════════════════════════════════════
   § THEMES & WALLPAPER
══════════════════════════════════════════════════════════════ */
function changeTheme(theme) {
    document.body.className = `${theme} text-slate-400 h-screen flex flex-col font-sans antialiased select-none`;
}

function changeChatWallpaper() {
    const url = document.getElementById('chat-bg-url').value.trim();
    if (url) {
        document.getElementById('chat-main-area').style.backgroundImage = `url('${url}')`;
        alert('تم تطبيق خلفية الشات.');
    }
}

/* ══════════════════════════════════════════════════════════════
   § SETTINGS STORAGE (per-user, localStorage)
══════════════════════════════════════════════════════════════ */
function getAppSettings() {
    try { return JSON.parse(localStorage.getItem('horror_app_settings') || '{}'); }
    catch(e) { return {}; }
}
function saveAppSetting(key, val) {
    const s = getAppSettings();
    s[key] = val;
    localStorage.setItem('horror_app_settings', JSON.stringify(s));
}

/* ══════════════════════════════════════════════════════════════
   § APP LOCK (optional — only for users who enabled it)
══════════════════════════════════════════════════════════════ */
function checkAppLockOnLoad() {
    const s = getAppSettings();
    if (s.lockEnabled && (s.lockHash || s.lockPassword)) {
        document.getElementById('lock-screen').classList.remove('hidden');
    }
}


/* ══════════════════════════════════════════════════════════════
   § FORGOT APP LOCK
══════════════════════════════════════════════════════════════ */
function triggerForgotLock() {
    const m = document.getElementById('forgot-lock-modal');
    if (m) m.classList.remove('hidden');
}
function closeForgotLockModal() {
    const m = document.getElementById('forgot-lock-modal');
    if (m) m.classList.add('hidden');
}
function confirmForgotLock() {
    // Disable lock settings first
    saveAppSetting('lockEnabled', false);
    saveAppSetting('lockPassword', '');
    saveAppSetting('lockHash', '');
    closeForgotLockModal();
    document.getElementById('lock-screen').classList.add('hidden');

    // Wipe IndexedDB unconditionally — works even if db handle isn't open yet
    if (db) {
        try { db.close(); } catch(e) {}
        db = null;
    }
    const delReq = indexedDB.deleteDatabase(DB_NAME);
    delReq.onsuccess = () => setTimeout(() => window.location.reload(), 200);
    delReq.onerror   = () => setTimeout(() => window.location.reload(), 200);
    delReq.onblocked = () => setTimeout(() => window.location.reload(), 500);
}

/* ══════════════════════════════════════════════════════════════
   § SETTINGS PANEL
══════════════════════════════════════════════════════════════ */
function openSettingsPanel() {
    renderSettingsUI();
    document.getElementById('settings-modal').classList.remove('hidden');
}
function closeSettingsPanel() {
    document.getElementById('settings-modal').classList.add('hidden');
}

function renderSettingsUI() {
    const s = getAppSettings();

    // Lock status
    const lockStatus = document.getElementById('settings-lock-status');
    if (lockStatus) {
        lockStatus.textContent = (s.lockEnabled && (s.lockHash || s.lockPassword))
            ? '🔒 القفل مفعّل — انقر لتعطيله'
            : '🔓 القفل غير مفعّل — انقر لتفعيله';
        lockStatus.className = (s.lockEnabled && (s.lockHash || s.lockPassword))
            ? 'settings-lock-badge active'
            : 'settings-lock-badge';
    }

    // Hide password form by default
    const pwWrap = document.getElementById('settings-lock-pw-wrap');
    if (pwWrap) pwWrap.classList.add('hidden');

    // Sound toggle
    const soundChk = document.getElementById('settings-sound-chk');
    if (soundChk) soundChk.checked = soundEffectsEnabled;

    // Notification status
    const permEl = document.getElementById('settings-notif-perm');
    if (permEl) {
        if (!('Notification' in window)) {
            permEl.textContent = '⚠️ المتصفح لا يدعم الإشعارات';
            permEl.className = 'text-[10px] text-stone-600 mt-1';
        } else if (Notification.permission === 'granted' && s.notificationsEnabled) {
            permEl.textContent = '✅ الإشعارات مفعّلة';
            permEl.className = 'text-[10px] text-emerald-700 mt-1';
        } else if (Notification.permission === 'denied') {
            permEl.textContent = '❌ محظورة من المتصفح — فعّلها يدوياً من إعدادات المتصفح';
            permEl.className = 'text-[10px] text-red-700 mt-1';
        } else {
            permEl.textContent = '🔔 اضغط "تفعيل" للسماح بالإشعارات';
            permEl.className = 'text-[10px] text-yellow-700 mt-1';
        }
    }

    // Notification toggle
    const notifChk = document.getElementById('settings-notif-chk');
    if (notifChk) {
        notifChk.checked = !!(s.notificationsEnabled && Notification.permission === 'granted');
    }
}



function settingToggleSound() {
    soundEffectsEnabled = !soundEffectsEnabled;
    saveAppSetting('soundEffects', soundEffectsEnabled);
    const btn = document.getElementById('sound-effect-btn');
    if (btn) btn.textContent = soundEffectsEnabled ? 'صوت: مفعل' : 'صوت: معطل';
    renderSettingsUI();
}

function settingToggleNotifications() {
    const chk = document.getElementById('settings-notif-chk');
    if (chk && !chk.checked) {
        saveAppSetting('notificationsEnabled', false);
        renderSettingsUI();
    } else {
        requestNotificationPermission();
    }
}

function settingClearChatHistory() {
    if (!confirm('⚠️ سيتم حذف كل سجل الشات نهائياً. هل أنت متأكد؟')) return;
    dbClearAll();
    renderAllMessages([]);
    addNotification('🗑️ تم مسح سجل الشات.');
}

function saveAppLock() {
    // Legacy: called from old sidebar UI — redirect to settings
    openSettingsPanel();
}

function loadSettingsOnStartup() {
    const s = getAppSettings();
    if (s.soundEffects === false) {
        soundEffectsEnabled = false;
        const btn = document.getElementById('sound-effect-btn');
        if (btn) btn.textContent = 'صوت: معطل';
    }
}

/* ══════════════════════════════════════════════════════════════
   § BROWSER NOTIFICATIONS
══════════════════════════════════════════════════════════════ */
function requestNotificationPermission() {
    if (!('Notification' in window)) { alert('متصفحك لا يدعم الإشعارات.'); return; }
    if (Notification.permission === 'denied') {
        alert('الإشعارات محظورة. فعّلها من إعدادات المتصفح ثم أعد المحاولة.');
        const c = document.getElementById('settings-notif-chk');
        if (c) c.checked = false;
        renderSettingsUI();
        return;
    }
    if (Notification.permission === 'granted') {
        saveAppSetting('notificationsEnabled', true);
        pingServiceWorker();
        renderSettingsUI();
        return;
    }
    Notification.requestPermission().then(perm => {
        if (perm === 'granted') {
            saveAppSetting('notificationsEnabled', true);
            showBrowserNotification('☣ Horror Death Chat ☠', '✅ الإشعارات مفعّلة! ستصلك تحديثات الغرفة.', { tag: 'hdc-welcome' });
            pingServiceWorker();
        } else {
            saveAppSetting('notificationsEnabled', false);
            const c = document.getElementById('settings-notif-chk');
            if (c) c.checked = false;
        }
        renderSettingsUI();
    });
}

function showBrowserNotification(title, body, opts = {}) {
    const s = getAppSettings();
    if (!s.notificationsEnabled) return;
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    try {
        const n = new Notification(title, {
            body,
            icon: opts.icon || 'assets/icons/icon-192.png',
            badge: opts.badge || 'assets/icons/icon-192.png',
            tag: opts.tag || ('hdc-' + Date.now()),
            silent: false
        });
        n.onclick = () => { window.focus(); n.close(); };
        setTimeout(() => n.close(), opts.ttl || 6000);
    } catch(e) {}
}

function pingServiceWorker() {
    if (!('serviceWorker' in navigator) || !navigator.serviceWorker.controller) return;
    const s = getAppSettings();
    navigator.serviceWorker.controller.postMessage({
        type: 'settings_update',
        notificationsEnabled: !!(s.notificationsEnabled && Notification.permission === 'granted')
    });
}

function registerServiceWorker() {
    if (!('serviceWorker' in navigator)) return;
    navigator.serviceWorker.register('sw.js?v=14', { scope: './' }).then(reg => {
        reg.addEventListener('updatefound', () => {
            const sw = reg.installing;
            if (sw) sw.addEventListener('statechange', () => {
                if (sw.state === 'activated') pingServiceWorker();
            });
        });
        // Ping once SW is ready
        navigator.serviceWorker.ready.then(() => pingServiceWorker());
    }).catch(e => console.warn('SW register error:', e));

    // Listen for visibility pings from SW
    navigator.serviceWorker.addEventListener('message', (e) => {
        if (e.data && e.data.type === 'visibility_check') {
            pingServiceWorker();
        }
    });
}

/* ══════════════════════════════════════════════════════════════
   § ACCOUNT SLAUGHTER
══════════════════════════════════════════════════════════════ */
function triggerAccountSlaughter() {
    document.getElementById('slaughter-modal').classList.remove('hidden');
}

function closeSlaughter() {
    document.getElementById('slaughter-modal').classList.add('hidden');
}

function executeAccountSlaughter() {
    dbClearAll();
    localStorage.clear();
    alert('تم تدمير هويتك وسجلاتك بالكامل... فناء الوجود البرمجي.');
    window.location.reload();
}

/* ══════════════════════════════════════════════════════════════
   § OWNER CONTROLS
══════════════════════════════════════════════════════════════ */
function ownerBroadcastNotice() {
    if (!isAdmin()) return;
    const notice = prompt('أدخل الإخطار للبث لجميع المتصلين:');
    if (notice) {
        broadcastPacket({ type: 'system_broadcast', payload: { text: notice } });
        appendSystemMessage('📢 بثثت إخطاراً: ' + notice);
    }
}

function ownerUpdateMarquee() {
    if (!isAdmin()) return;
    const customText = prompt('أدخل نص الإعلان الجديد:');
    if (customText) {
        const mc = document.getElementById('marquee-container'); mc.textContent = ''; const sp = document.createElement('span'); sp.textContent = '☣ ' + String(customText).slice(0, 200) + ' ☠'; mc.appendChild(sp);
    }
}

function ownerSendCoins() {
    if (!isAdmin()) return;
    const name = prompt('اسم الحساب المراد إرسال الذهب له:');
    const amount = parseInt(prompt('كمية الذهب:') || '0');
    if (name && amount > 0) {
        broadcastPacket({ type: 'coins_gift', payload: { to: name, from: currentUser.username, amount } });
        appendSystemMessage(`🪙 أرسلت ${amount} ذهبة لـ ${name}.`);
    }
}

function adminBlockUser() {
    if (!isAdmin()) return;
    const target = prompt('اسم المستخدم المراد حظره:');
    if (target) {
        broadcastPacket({ type: 'force_ban_signal', payload: { target, expiry: 'permanent' } });
        appendSystemMessage(`🚫 تم حظر ${target}.`);
    }
}

function adminSendPasscodeMsg() {
    if (!isAdmin()) return;
    const text = prompt('محتوى الرسالة الإدارية:');
    const code = prompt('الرقم السري لفتحها:');
    if (text && code) {
        appendSystemMessage(`📩 رسالة إدارية مشفرة. الرمز: ${code}`);
    }
}

/* ══════════════════════════════════════════════════════════════
   § PROFILE / EDIT
══════════════════════════════════════════════════════════════ */
function editProfileDialog() {
    if (!currentUser) return;
    if (!isOwner() && currentUser.level < 5) {
        triggerFirewallModal('جدار الحماية: تحتاج مستوى 5 لتعديل الملف الشخصي.'); return;
    }
    const newName = sanitizeName(prompt('أدخل الاسم الجديد:', currentUser.username));
    if (newName && OWNER_NAMES.includes(newName) && !ownerPrivateKey) { alert('هذا الاسم محجوز.'); return; }
    if (newName) {
        currentUser.username = newName;
        broadcastPacket({ type: 'hello', payload: { username: newName, role: currentUser.role, level: currentUser.level, peers: [] } });
        document.getElementById('profile-display-name').textContent = currentUser.username;
    }
}

function purchaseNameDecoration() {
    if (!currentUser) return;
    const cost = 100000;
    if (!isOwner() && getCoins() < cost) {
        triggerFirewallModal(`رصيد غير كافٍ. تحتاج ${cost} ذهبة للزخرفة الفاخرة.`); return;
    }
    if (!isOwner()) deductCoins(cost);
    alert('تم شراء زخرفة فاخرة للحساب بنجاح!');
}

/* ══════════════════════════════════════════════════════════════
   § LOGOUT
══════════════════════════════════════════════════════════════ */
function logout() {
    if (confirm('هل أنت متأكد من رغبتك في الخروج؟')) {
        if (peer) peer.destroy();
        window.location.reload();
    }
}

/* ══════════════════════════════════════════════════════════════
   § FIREWALL MODAL
══════════════════════════════════════════════════════════════ */
function triggerFirewallModal(descText) {
    playErrorSound();
    document.getElementById('firewall-modal-desc').innerText = descText;
    document.getElementById('firewall-warning-modal').classList.remove('hidden');
}

function closeFirewallModal() {
    document.getElementById('firewall-warning-modal').classList.add('hidden');
}

/* ══════════════════════════════════════════════════════════════
   § MARQUEE
══════════════════════════════════════════════════════════════ */
function renderMarqueeContent() {
    const container = document.getElementById('marquee-container');
    if (!container) return;
    container.innerHTML = `
        <span>☣ مرحباً بكم في Horror Death Chat ☠</span>
        <a href="https://mohamedhamdyr.github.io/2048/" target="_blank" class="text-red-800 hover:underline font-bold">جرب لعبة 2048</a>
        <a href="https://hasalit-elhassanat.horror2024death.workers.dev/" target="_blank" rel="noopener noreferrer" class="text-emerald-500 hover:text-emerald-300 hover:underline font-bold">🕌 حصالة الحسنات: تطبيق إسلامي للأطفال والعائلات، اضغط للفتح</a>
        <span>☠ الغرف مشفرة محلياً ☣</span>
        <a href="https://mohamedhamdyr.github.io/mo-ai/" target="_blank" class="text-indigo-800 hover:underline font-bold">جرب MO AI</a>
        <span>☣ تطوير: محمد حمدي ☠</span>
    `;
}

/* ══════════════════════════════════════════════════════════════
   § GLOBAL CLICK / UTILITY
══════════════════════════════════════════════════════════════ */
function handleGlobalClick() {
    playClickSound();
    initMelancholyAudio();

    // Close panels when clicking outside
    const panels = ['user-popup-menu'];
    panels.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.add('hidden');
    });
}

/* ══════════════════════════════════════════════════════════════
   § MULTILINGUAL DICTIONARY
══════════════════════════════════════════════════════════════ */
const dictionary = {
    ar: {
        chatTitle: '☣Chat Horror Death☠', send: 'بث', exit: 'تلاشي (خروج)',
        ops: 'تفاصيل الأثر', copy: 'نسخ الكلمات',
        wait: 'وحيد الآن في الظلام...', connOK: 'روح أخرى وجدت... لست وحدك',
        placeholder: 'امسح وحشتك بروح هنا...',
        visitor: 'دخول كزائر حزين', register: 'تسجيل هويتك',
        loginBtn: 'دخول الغرفة القديمة', userPlace: 'الاسم المستعار...',
        themeLbl: 'تغيير المظهر الكئيب:', lockLbl: 'قفل الشات بكلمة سر:',
        roomTitle: 'إنشاء غرفة سرية:', roomBtn: 'تأسيس الغرفة',
        roomPlace: 'اسم الغرفة الموحشة...', roomPass: 'كلمة مرور الغرفة...',
        localRooms: 'الغرف النشطة:', lockTitle: 'الدردشة مغلقة بكلمة سر',
        lockBtn: 'فتح الدردشة', killBtn: 'قتل الحساب وفقدان البيانات للأبد',
        slaughterTitle: 'قتل الحساب وفقدان البيانات للأبد',
        slaughterDesc: 'أنت على وشك تدمير وجودك. سيتم مسح حسابك وسجل دردشاتك للأبد.',
        slaughterConfirm: 'موافق', slaughterCancel: 'تراجع',
        soundOn: 'صوت: مفعل', soundOff: 'صوت: معطل',
        yourId: 'معرفك الفريد:', connect: 'استدعاء صديق عن بعد:',
        m1: '☣ مرحباً بكم في Horror Death Chat ☠',
        m2: 'جرب لعبة 2048', m3: '☠ الغرف مشفرة محلياً ☣',
        m4: 'جرب MO AI', m5: '☣ تطوير: محمد حمدي ☠'
    },
    en: {
        chatTitle: '☣Chat Horror Death☠', send: 'Broadcast', exit: 'Vanish (Exit)',
        ops: 'Message Details', copy: 'Copy Text',
        wait: 'Alone in the darkness...', connOK: 'Another soul found... you are not alone',
        placeholder: 'Pour your soul here...',
        visitor: 'Enter as Sad Visitor', register: 'Register Identity',
        loginBtn: 'Enter the Old Room', userPlace: 'Alias...',
        themeLbl: 'Change Dark Theme:', lockLbl: 'Lock chat with password:',
        roomTitle: 'Create Secret Room:', roomBtn: 'Create Room',
        roomPlace: 'Room name...', roomPass: 'Room password...',
        localRooms: 'Active Rooms:', lockTitle: 'Chat locked with password',
        lockBtn: 'Unlock Chat', killBtn: 'Kill Account & Lose Data Forever',
        slaughterTitle: 'Kill Account & Lose Data Forever',
        slaughterDesc: 'You are about to erase your existence. Your account and chat history will be destroyed forever.',
        slaughterConfirm: 'Confirm', slaughterCancel: 'Cancel',
        soundOn: 'Sound: On', soundOff: 'Sound: Off',
        yourId: 'Your Unique ID:', connect: 'Summon a Friend Remotely:',
        m1: '☣ Welcome to Horror Death Chat ☠',
        m2: 'Try 2048 Game', m3: '☠ Rooms are locally encrypted ☣',
        m4: 'Try MO AI', m5: '☣ Developed by Mohamed Hamdy ☠'
    },
    fr: {
        chatTitle: '☣Chat Horror Death☠', send: 'Diffuser', exit: 'Disparaître',
        ops: 'Détails', copy: 'Copier',
        wait: 'Seul dans les ténèbres...', connOK: 'Une autre âme trouvée...',
        placeholder: 'Exprimez votre âme ici...',
        visitor: 'Entrer comme Visiteur Triste', register: 'Enregistrer Identité',
        loginBtn: 'Entrer dans l\'Ancienne Chambre', userPlace: 'Alias...',
        themeLbl: 'Changer Thème Sombre:', lockLbl: 'Verrouiller avec mot de passe:',
        roomTitle: 'Créer Salle Secrète:', roomBtn: 'Créer Salle',
        roomPlace: 'Nom de la salle...', roomPass: 'Mot de passe...',
        localRooms: 'Salles actives:', lockTitle: 'Chat verrouillé',
        lockBtn: 'Déverrouiller', killBtn: 'Tuer le compte pour toujours',
        slaughterTitle: 'Tuer le compte pour toujours',
        slaughterDesc: 'Vous êtes sur le point d\'effacer votre existence.',
        slaughterConfirm: 'Confirmer', slaughterCancel: 'Annuler',
        soundOn: 'Son: Activé', soundOff: 'Son: Désactivé',
        yourId: 'Votre ID unique:', connect: 'Appeler un ami:',
        m1: '☣ Bienvenue dans Horror Death Chat ☠',
        m2: 'Essayez le jeu 2048', m3: '☠ Salles cryptées localement ☣',
        m4: 'Essayez MO AI', m5: '☣ Développé par Mohamed Hamdy ☠'
    },
    de: {
        chatTitle: '☣Chat Horror Death☠', send: 'Senden', exit: 'Verschwinden',
        ops: 'Details', copy: 'Kopieren',
        wait: 'Allein in der Dunkelheit...', connOK: 'Eine andere Seele gefunden...',
        placeholder: 'Schreib deine Seele hier...',
        visitor: 'Als trauriger Besucher eintreten', register: 'Identität registrieren',
        loginBtn: 'Alten Raum betreten', userPlace: 'Alias...',
        themeLbl: 'Dunkles Thema ändern:', lockLbl: 'Chat mit Passwort sperren:',
        roomTitle: 'Geheimen Raum erstellen:', roomBtn: 'Raum erstellen',
        roomPlace: 'Raumname...', roomPass: 'Raumpasswort...',
        localRooms: 'Aktive Räume:', lockTitle: 'Chat gesperrt',
        lockBtn: 'Entsperren', killBtn: 'Konto für immer löschen',
        slaughterTitle: 'Konto für immer löschen',
        slaughterDesc: 'Sie sind dabei, Ihre Existenz zu löschen.',
        slaughterConfirm: 'Bestätigen', slaughterCancel: 'Abbrechen',
        soundOn: 'Ton: An', soundOff: 'Ton: Aus',
        yourId: 'Deine eindeutige ID:', connect: 'Freund rufen:',
        m1: '☣ Willkommen bei Horror Death Chat ☠',
        m2: 'Spiele 2048', m3: '☠ Räume lokal verschlüsselt ☣',
        m4: 'Probiere MO AI', m5: '☣ Entwickelt von Mohamed Hamdy ☠'
    },
    es: {
        chatTitle: '☣Chat Horror Death☠', send: 'Transmitir', exit: 'Desvanecerse',
        ops: 'Detalles', copy: 'Copiar',
        wait: 'Solo en la oscuridad...', connOK: 'Otra alma encontrada...',
        placeholder: 'Derrama tu alma aquí...',
        visitor: 'Entrar como Visitante Triste', register: 'Registrar Identidad',
        loginBtn: 'Entrar a la Habitación Vieja', userPlace: 'Alias...',
        themeLbl: 'Cambiar Tema Oscuro:', lockLbl: 'Bloquear chat con contraseña:',
        roomTitle: 'Crear Sala Secreta:', roomBtn: 'Crear Sala',
        roomPlace: 'Nombre de la sala...', roomPass: 'Contraseña...',
        localRooms: 'Salas activas:', lockTitle: 'Chat bloqueado',
        lockBtn: 'Desbloquear', killBtn: 'Matar cuenta para siempre',
        slaughterTitle: 'Matar cuenta para siempre',
        slaughterDesc: 'Estás a punto de borrar tu existencia.',
        slaughterConfirm: 'Confirmar', slaughterCancel: 'Cancelar',
        soundOn: 'Sonido: Activado', soundOff: 'Sonido: Desactivado',
        yourId: 'Tu ID único:', connect: 'Llamar a un amigo:',
        m1: '☣ Bienvenido a Horror Death Chat ☠',
        m2: 'Juega 2048', m3: '☠ Salas cifradas localmente ☣',
        m4: 'Prueba MO AI', m5: '☣ Desarrollado por Mohamed Hamdy ☠'
    },
    ja: {
        chatTitle: '☣ホラーデスチャット☠', send: '送信', exit: '消える',
        ops: 'メッセージ詳細', copy: 'コピー',
        wait: '暗闇の中で一人...', connOK: '別の魂が見つかりました...',
        placeholder: 'ここに心を打ち明けて...',
        visitor: '悲しい訪問者として入る', register: 'アイデンティティを登録',
        loginBtn: '古い部屋に入る', userPlace: '別名...',
        themeLbl: 'ダークテーマを変更:', lockLbl: 'パスワードでロック:',
        roomTitle: '秘密の部屋を作る:', roomBtn: '部屋を作る',
        roomPlace: '部屋名...', roomPass: 'パスワード...',
        localRooms: 'アクティブな部屋:', lockTitle: 'チャットはロックされています',
        lockBtn: 'アンロック', killBtn: 'アカウントを永久削除',
        slaughterTitle: 'アカウントを永久削除',
        slaughterDesc: 'あなたの存在を消去しようとしています。',
        slaughterConfirm: '確認', slaughterCancel: 'キャンセル',
        soundOn: '音: オン', soundOff: '音: オフ',
        yourId: 'あなたのユニークID:', connect: '友達を呼ぶ:',
        m1: '☣ ホラーデスチャットへようこそ ☠',
        m2: '2048ゲームを試す', m3: '☠ 部屋はローカルで暗号化 ☣',
        m4: 'MO AIを試す', m5: '☣ 開発: Mohamed Hamdy ☠'
    },
    ru: {
        chatTitle: '☣Чат Ужас Смерти☠', send: 'Отправить', exit: 'Исчезнуть',
        ops: 'Детали', copy: 'Копировать',
        wait: 'Один в темноте...', connOK: 'Найдена ещё одна душа...',
        placeholder: 'Вылей свою душу здесь...',
        visitor: 'Войти как грустный гость', register: 'Зарегистрировать личность',
        loginBtn: 'Войти в старую комнату', userPlace: 'Псевдоним...',
        themeLbl: 'Изменить тёмную тему:', lockLbl: 'Заблокировать паролем:',
        roomTitle: 'Создать секретную комнату:', roomBtn: 'Создать',
        roomPlace: 'Название комнаты...', roomPass: 'Пароль...',
        localRooms: 'Активные комнаты:', lockTitle: 'Чат заблокирован',
        lockBtn: 'Разблокировать', killBtn: 'Удалить аккаунт навсегда',
        slaughterTitle: 'Удалить аккаунт навсегда',
        slaughterDesc: 'Вы собираетесь стереть своё существование.',
        slaughterConfirm: 'Подтвердить', slaughterCancel: 'Отмена',
        soundOn: 'Звук: Вкл', soundOff: 'Звук: Выкл',
        yourId: 'Ваш уникальный ID:', connect: 'Вызвать друга:',
        m1: '☣ Добро пожаловать в Horror Death Chat ☠',
        m2: 'Игра 2048', m3: '☠ Комнаты зашифрованы локально ☣',
        m4: 'Попробуй MO AI', m5: '☣ Разработчик: Mohamed Hamdy ☠'
    },
    ko: {
        chatTitle: '☣공포 죽음 채팅☠', send: '전송', exit: '사라지기',
        ops: '세부 정보', copy: '복사',
        wait: '어둠 속에 혼자...', connOK: '다른 영혼 발견...',
        placeholder: '여기에 마음을 털어놓으세요...',
        visitor: '슬픈 방문자로 입장', register: '신원 등록',
        loginBtn: '오래된 방 입장', userPlace: '별명...',
        themeLbl: '어두운 테마 변경:', lockLbl: '비밀번호로 잠금:',
        roomTitle: '비밀 방 만들기:', roomBtn: '방 만들기',
        roomPlace: '방 이름...', roomPass: '비밀번호...',
        localRooms: '활성 방:', lockTitle: '채팅 잠김',
        lockBtn: '잠금 해제', killBtn: '계정 영구 삭제',
        slaughterTitle: '계정 영구 삭제',
        slaughterDesc: '당신의 존재를 지우려 합니다.',
        slaughterConfirm: '확인', slaughterCancel: '취소',
        soundOn: '소리: 켬', soundOff: '소리: 끔',
        yourId: '고유 ID:', connect: '친구 호출:',
        m1: '☣ Horror Death Chat에 오신 것을 환영합니다 ☠',
        m2: '2048 게임 해보기', m3: '☠ 방은 로컬에서 암호화됨 ☣',
        m4: 'MO AI 시도', m5: '☣ 개발: Mohamed Hamdy ☠'
    },
    zh: {
        chatTitle: '☣恐怖死亡聊天☠', send: '广播', exit: '消失',
        ops: '详细信息', copy: '复制',
        wait: '黑暗中独自...', connOK: '发现另一个灵魂...',
        placeholder: '在这里倾诉你的灵魂...',
        visitor: '以悲伤访客身份进入', register: '注册身份',
        loginBtn: '进入旧房间', userPlace: '别名...',
        themeLbl: '更改黑暗主题:', lockLbl: '用密码锁定:',
        roomTitle: '创建秘密房间:', roomBtn: '创建房间',
        roomPlace: '房间名称...', roomPass: '密码...',
        localRooms: '活跃房间:', lockTitle: '聊天已锁定',
        lockBtn: '解锁', killBtn: '永久删除账户',
        slaughterTitle: '永久删除账户',
        slaughterDesc: '您即将抹去您的存在。',
        slaughterConfirm: '确认', slaughterCancel: '取消',
        soundOn: '声音: 开', soundOff: '声音: 关',
        yourId: '您的唯一ID:', connect: '召唤朋友:',
        m1: '☣ 欢迎来到恐怖死亡聊天 ☠',
        m2: '试试2048游戏', m3: '☠ 房间在本地加密 ☣',
        m4: '试试MO AI', m5: '☣ 开发者: Mohamed Hamdy ☠'
    },
    it: { chatTitle:'☣Horror Death Chat☠', send:'Trasmetti', exit:'Svanire', ops:'Dettagli', copy:'Copia', wait:'Solo nell\'oscurità...', connOK:'Un\'altra anima trovata...', placeholder:'Scrivi la tua anima qui...', visitor:'Entra come Visitatore Triste', register:'Registra Identità', loginBtn:'Entra nella Vecchia Stanza', userPlace:'Alias...', themeLbl:'Cambia Tema Scuro:', lockLbl:'Blocca chat con password:', roomTitle:'Crea Stanza Segreta:', roomBtn:'Crea Stanza', roomPlace:'Nome stanza...', roomPass:'Password...', localRooms:'Stanze attive:', lockTitle:'Chat bloccata', lockBtn:'Sblocca', killBtn:'Elimina account per sempre', slaughterTitle:'Elimina account per sempre', slaughterDesc:'Stai per cancellare la tua esistenza.', slaughterConfirm:'Conferma', slaughterCancel:'Annulla', soundOn:'Suono: On', soundOff:'Suono: Off', yourId:'Il tuo ID univoco:', connect:'Chiama un amico:', m1:'☣ Benvenuto in Horror Death Chat ☠', m2:'Gioca a 2048', m3:'☠ Stanze cifrate localmente ☣', m4:'Prova MO AI', m5:'☣ Sviluppato da Mohamed Hamdy ☠' },
    pt: { chatTitle:'☣Horror Death Chat☠', send:'Transmitir', exit:'Desaparecer', ops:'Detalhes', copy:'Copiar', wait:'Sozinho na escuridão...', connOK:'Outra alma encontrada...', placeholder:'Despeje sua alma aqui...', visitor:'Entrar como Visitante Triste', register:'Registrar Identidade', loginBtn:'Entrar na Sala Antiga', userPlace:'Apelido...', themeLbl:'Mudar Tema Sombrio:', lockLbl:'Bloquear chat com senha:', roomTitle:'Criar Sala Secreta:', roomBtn:'Criar Sala', roomPlace:'Nome da sala...', roomPass:'Senha...', localRooms:'Salas ativas:', lockTitle:'Chat bloqueado', lockBtn:'Desbloquear', killBtn:'Matar conta para sempre', slaughterTitle:'Matar conta para sempre', slaughterDesc:'Você está prestes a apagar sua existência.', slaughterConfirm:'Confirmar', slaughterCancel:'Cancelar', soundOn:'Som: Ativado', soundOff:'Som: Desativado', yourId:'Seu ID único:', connect:'Chamar um amigo:', m1:'☣ Bem-vindo ao Horror Death Chat ☠', m2:'Jogue 2048', m3:'☠ Salas criptografadas localmente ☣', m4:'Experimente MO AI', m5:'☣ Desenvolvido por Mohamed Hamdy ☠' },
    tr: { chatTitle:'☣Korku Ölüm Sohbeti☠', send:'Yayınla', exit:'Yok Ol', ops:'Ayrıntılar', copy:'Kopyala', wait:'Karanlıkta yalnız...', connOK:'Başka bir ruh bulundu...', placeholder:'Ruhunu buraya dök...', visitor:'Üzgün Ziyaretçi Olarak Gir', register:'Kimliği Kaydet', loginBtn:'Eski Odaya Gir', userPlace:'Takma ad...', themeLbl:'Karanlık Temayı Değiştir:', lockLbl:'Sohbeti şifreyle kilitle:', roomTitle:'Gizli Oda Oluştur:', roomBtn:'Oda Oluştur', roomPlace:'Oda adı...', roomPass:'Şifre...', localRooms:'Aktif odalar:', lockTitle:'Sohbet kilitli', lockBtn:'Kilidi Aç', killBtn:'Hesabı sonsuza dek sil', slaughterTitle:'Hesabı sonsuza dek sil', slaughterDesc:'Varlığını silmek üzeresiniz.', slaughterConfirm:'Onayla', slaughterCancel:'İptal', soundOn:'Ses: Açık', soundOff:'Ses: Kapalı', yourId:'Benzersiz ID\'niz:', connect:'Arkadaş Çağır:', m1:'☣ Horror Death Chat\'e Hoş Geldiniz ☠', m2:'2048 Oynayın', m3:'☠ Odalar yerel olarak şifrelendi ☣', m4:'MO AI\'yi deneyin', m5:'☣ Geliştiren: Mohamed Hamdy ☠' },
    nl: { chatTitle:'☣Horror Death Chat☠', send:'Uitzenden', exit:'Verdwijnen', ops:'Details', copy:'Kopiëren', wait:'Alleen in het donker...', connOK:'Een andere ziel gevonden...', placeholder:'Stort je ziel hier uit...', visitor:'Binnenkomen als Droevig Bezoeker', register:'Identiteit Registreren', loginBtn:'De Oude Kamer Betreden', userPlace:'Alias...', themeLbl:'Donker Thema Wijzigen:', lockLbl:'Chat vergrendelen met wachtwoord:', roomTitle:'Geheime Kamer Maken:', roomBtn:'Kamer Maken', roomPlace:'Kamernaam...', roomPass:'Wachtwoord...', localRooms:'Actieve kamers:', lockTitle:'Chat vergrendeld', lockBtn:'Ontgrendelen', killBtn:'Account voor altijd verwijderen', slaughterTitle:'Account voor altijd verwijderen', slaughterDesc:'Je staat op het punt je bestaan te wissen.', slaughterConfirm:'Bevestigen', slaughterCancel:'Annuleren', soundOn:'Geluid: Aan', soundOff:'Geluid: Uit', yourId:'Jouw unieke ID:', connect:'Vriend oproepen:', m1:'☣ Welkom bij Horror Death Chat ☠', m2:'Speel 2048', m3:'☠ Kamers lokaal versleuteld ☣', m4:'Probeer MO AI', m5:'☣ Ontwikkeld door Mohamed Hamdy ☠' },
    pl: { chatTitle:'☣Horror Death Chat☠', send:'Nadaj', exit:'Zniknąć', ops:'Szczegóły', copy:'Kopiuj', wait:'Sam w ciemności...', connOK:'Znaleziono inną duszę...', placeholder:'Wylej tutaj swoją duszę...', visitor:'Wejdź jako Smutny Gość', register:'Zarejestruj Tożsamość', loginBtn:'Wejdź do Starego Pokoju', userPlace:'Alias...', themeLbl:'Zmień Ciemny Motyw:', lockLbl:'Zablokuj czat hasłem:', roomTitle:'Utwórz Tajny Pokój:', roomBtn:'Utwórz Pokój', roomPlace:'Nazwa pokoju...', roomPass:'Hasło...', localRooms:'Aktywne pokoje:', lockTitle:'Czat zablokowany', lockBtn:'Odblokuj', killBtn:'Usuń konto na zawsze', slaughterTitle:'Usuń konto na zawsze', slaughterDesc:'Zamierzasz wymazać swoje istnienie.', slaughterConfirm:'Potwierdź', slaughterCancel:'Anuluj', soundOn:'Dźwięk: Wł', soundOff:'Dźwięk: Wył', yourId:'Twój unikalny ID:', connect:'Wywołaj znajomego:', m1:'☣ Witaj w Horror Death Chat ☠', m2:'Zagraj w 2048', m3:'☠ Pokoje lokalnie szyfrowane ☣', m4:'Wypróbuj MO AI', m5:'☣ Stworzony przez Mohamed Hamdy ☠' },
    hi: { chatTitle:'☣हॉरर डेथ चैट☠', send:'प्रसारण', exit:'गायब हो', ops:'विवरण', copy:'कॉपी', wait:'अंधेरे में अकेला...', connOK:'एक और आत्मा मिली...', placeholder:'यहाँ अपनी आत्मा उँडेलें...', visitor:'उदास आगंतुक के रूप में प्रवेश', register:'पहचान दर्ज करें', loginBtn:'पुराने कमरे में प्रवेश', userPlace:'उपनाम...', themeLbl:'डार्क थीम बदलें:', lockLbl:'पासवर्ड से लॉक करें:', roomTitle:'गुप्त कमरा बनाएं:', roomBtn:'कमरा बनाएं', roomPlace:'कमरे का नाम...', roomPass:'पासवर्ड...', localRooms:'सक्रिय कमरे:', lockTitle:'चैट लॉक है', lockBtn:'अनलॉक करें', killBtn:'खाता हमेशा के लिए हटाएं', slaughterTitle:'खाता हमेशा के लिए हटाएं', slaughterDesc:'आप अपना अस्तित्व मिटाने वाले हैं।', slaughterConfirm:'पुष्टि करें', slaughterCancel:'रद्द', soundOn:'ध्वनि: चालू', soundOff:'ध्वनि: बंद', yourId:'आपकी अनूठी ID:', connect:'मित्र को बुलाएं:', m1:'☣ Horror Death Chat में आपका स्वागत है ☠', m2:'2048 खेलें', m3:'☠ कमरे स्थानीय रूप से एन्क्रिप्टेड ☣', m4:'MO AI आज़माएं', m5:'☣ विकसित: Mohamed Hamdy ☠' }
};

function changeLang(lang) {
    if (!dictionary[lang]) return;
    currentLang = lang;
    const d = dictionary[lang];
    const rtlLangs = ['ar', 'fa', 'ur', 'he'];
    document.documentElement.setAttribute('dir', rtlLangs.includes(lang) ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', lang);

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };
    const setPlaceholder = (id, val) => { const el = document.getElementById(id); if (el) el.placeholder = val; };
    const setHTML = (id, val) => { const el = document.getElementById(id); if (el) el.innerHTML = val; };

    set('t-chat-title', d.chatTitle);
    set('t-send-text', d.send);
    set('t-exit-btn', d.exit);
    set('t-msg-ops', d.ops);
    set('t-copy-msg', d.copy);
    set('t-lock-title', d.lockTitle);
    set('t-lock-btn', d.lockBtn);
    set('t-your-id', d.yourId);
    set('t-connect-peer', d.connect);
    set('t-slaughter-title', d.slaughterTitle);
    set('t-slaughter-desc', d.slaughterDesc);
    set('t-slaughter-confirm', d.slaughterConfirm);
    set('t-slaughter-cancel', d.slaughterCancel);
    set('t-room-btn', d.roomBtn);
    set('t-local-rooms', d.localRooms);
    set('tab-visitor', d.visitor);
    set('tab-register', d.register);
    set('t-login-btn', d.loginBtn);
    setHTML('t-kill-btn', `<i class="fa-solid fa-skull"></i> ${d.killBtn}`);
    setHTML('t-room-title', `<i class="fa-solid fa-door-closed"></i> ${d.roomTitle}`);
    setPlaceholder('msg-input', d.placeholder);
    setPlaceholder('login-username', d.userPlace);
    setPlaceholder('new-room-name', d.roomPlace);
    setPlaceholder('new-room-pass', d.roomPass);

    const connEl = document.getElementById('connection-status');
    if (connEl && !currentUser) connEl.innerText = d.wait;
    const sBtn = document.getElementById('sound-effect-btn');
    if (sBtn) sBtn.innerText = soundEffectsEnabled ? d.soundOn : d.soundOff;

    renderMarqueeContent();
}

/* ══════════════════════════════════════════════════════════════
   § القائمة الجانبية على الموبايل (Drawer)
══════════════════════════════════════════════════════════════ */
function toggleMobileSidebar() {
    const aside = document.getElementById('app-sidebar');
    const backdrop = document.getElementById('mobile-sidebar-backdrop');
    if (!aside) return;
    const opening = !aside.classList.contains('mobile-sidebar-open');
    aside.classList.toggle('mobile-sidebar-open', opening);
    if (backdrop) backdrop.classList.toggle('active', opening);
}

function closeMobileSidebar() {
    const aside = document.getElementById('app-sidebar');
    const backdrop = document.getElementById('mobile-sidebar-backdrop');
    if (aside) aside.classList.remove('mobile-sidebar-open');
    if (backdrop) backdrop.classList.remove('active');
}

/* ══════════════════════════════════════════════════════════════
   § شاشة البداية (Splash Screen)
══════════════════════════════════════════════════════════════ */
function dismissSplash(e) {
    if (e) e.stopPropagation();
    const el = document.getElementById('splash-screen');
    if (!el || el.classList.contains('splash-hide')) return;
    el.classList.add('splash-hide');
    setTimeout(() => { if (el && el.parentNode) el.remove(); }, 700);
}

/* ══════════════════════════════════════════════════════════════
   § INIT (window.onload)
══════════════════════════════════════════════════════════════ */
window.onload = async () => {
    // إخفاء شاشة البداية تلقائياً بعد لحظات (أو عند اللمس)
    setTimeout(dismissSplash, 2600);

    checkAppLockOnLoad();
    loadSettingsOnStartup();
    changeLang('ar');
    setupViewportFix();
    registerServiceWorker();

    try {
        await openDB();
    } catch(e) {
        console.warn('IndexedDB not available, falling back.');
    }

    // Copy button
    const copyBtn = document.getElementById('copy-btn');
    if (copyBtn) {
        copyBtn.onclick = () => {
            const id = document.getElementById('my-peer-id').innerText;
            navigator.clipboard.writeText(id).then(() => alert('تم نسخ معرفك.')).catch(() => {});
        };
    }

    // Enter key for main input
    const msgInput = document.getElementById('msg-input');
    if (msgInput) {
        msgInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendBroadcastMessage();
            }
        });
    }

    // Enter key for unlock input
    const unlockInput = document.getElementById('unlock-pass-input');
    if (unlockInput) {
        unlockInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); unlockApp(); }
        });
    }

    // Click outside to close panels
    document.addEventListener('click', (e) => {
        const popup = document.getElementById('user-popup-menu');
        if (popup && !popup.contains(e.target)) popup.classList.add('hidden');
        const privList = document.getElementById('private-chats-list');
        const privIcon = document.getElementById('private-chat-icon-wrapper');
        if (privList && privIcon && !privList.contains(e.target) && !privIcon.contains(e.target)) {
            privList.classList.add('hidden');
            isPrivateListOpen = false;
        }
        const notifPanel = document.getElementById('notification-panel');
        if (notifPanel && !notifPanel.contains(e.target)) {
            notifPanel.classList.add('hidden');
            isNotificationPanelOpen = false;
        }
        // Close settings if clicking outside
        const settingsModal = document.getElementById('settings-modal');
        const settingsBtn = document.getElementById('settings-gear-btn');
        if (settingsModal && settingsBtn &&
            !settingsModal.contains(e.target) && !settingsBtn.contains(e.target)) {
            if (!settingsModal.classList.contains('hidden')) {
                closeSettingsPanel();
            }
        }
    });
};

/* ══════════════════════════════════════════════════════════════
   § v6 — HARDENING + MEDIA + MESH  (صيانة شاملة)
══════════════════════════════════════════════════════════════ */
const OWNER_PUBLIC_JWK = {"kty":"EC","crv":"P-256","x":"p3Pr27t-z0SMME_n4lvaRB2BFRUqpBwQTlVu-y2q9aE","y":"OlHVtIKlQD5CkrXmDhoGjlJETFnDyMqxMQLOpzmEhJU"};
const MAX_ATT_BYTES = 10 * 1024 * 1024;
const ATT_CHUNK = 14000;
let ownerPrivateKey = null;
const verifiedOwnerPeers = new Set();
const pendingChallenges = {};
const peerNames = {};
const pendingConns = new Set();
const seenMsgIds = new Set();
const incomingAtt = {};
const viewOnceStore = new Map();
const ECDSA = { name: 'ECDSA', namedCurve: 'P-256' };
const ECDSA_SIGN = { name: 'ECDSA', hash: 'SHA-256' };
const enc = (s) => new TextEncoder().encode(s);
const b64 = (buf) => { let s = ''; new Uint8Array(buf).forEach(c => s += String.fromCharCode(c)); return btoa(s); };
const unb64 = (s) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function sanitizeName(s) {
    return String(s || '').replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, 24);
}

/* ── فلتر الشتائم (بحدود الكلمة، لا يكسر كلمات مثل password/class) ── */
function filterProfanity(text) {
    if (!text) return text;
    let out = String(text);
    badWordsFilter.forEach(word => {
        const w = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const re = new RegExp('(^|[^\\p{L}\\p{N}])(' + w + ')(?=[^\\p{L}\\p{N}]|$)', 'giu');
        out = out.replace(re, (m, pre, hit) => pre + '*'.repeat(hit.length));
    });
    return out;
}

/* ── هوية المالك (توقيع ECDSA — لا يمكن انتحالها بمجرد كتابة الاسم) ── */
async function importOwnerKey(jwkStr) {
    try {
        const k = await crypto.subtle.importKey('jwk', JSON.parse(jwkStr), ECDSA, false, ['sign']);
        const nonce = crypto.getRandomValues(new Uint8Array(16));
        const sig = await crypto.subtle.sign(ECDSA_SIGN, k, nonce);
        const pub = await crypto.subtle.importKey('jwk', OWNER_PUBLIC_JWK, ECDSA, false, ['verify']);
        return (await crypto.subtle.verify(ECDSA_SIGN, pub, sig, nonce)) ? k : null;
    } catch (e) { return null; }
}
async function answerOwnerChallenge(p, conn) {
    if (!ownerPrivateKey || !p || typeof p.nonce !== 'string' || p.nonce.length > 40) return;
    try {
        const sig = await crypto.subtle.sign(ECDSA_SIGN, ownerPrivateKey, enc(p.nonce + '|' + conn.peer + '|' + peer.id));
        sendPacket(conn, { type: 'owner_proof', payload: { sig: b64(sig) } });
    } catch (e) {}
}
async function verifyOwnerProof(p, conn) {
    const nonce = pendingChallenges[conn.peer];
    if (!nonce || !p || typeof p.sig !== 'string') return;
    delete pendingChallenges[conn.peer];
    try {
        const pub = await crypto.subtle.importKey('jwk', OWNER_PUBLIC_JWK, ECDSA, false, ['verify']);
        const ok = await crypto.subtle.verify(ECDSA_SIGN, pub, unb64(p.sig), enc(nonce + '|' + peer.id + '|' + conn.peer));
        if (ok) { verifiedOwnerPeers.add(conn.peer); appendSystemMessage('👑 تم التحقق من هوية المالك.'); }
    } catch (e) {}
}

/* ── الشبكة: اتصال شبكي كامل (Mesh) + Hello ── */
function connectToPeer(remoteId) {
    if (!peer || activeConnections[remoteId] || pendingConns.has(remoteId) || remoteId === peer.id) return;
    pendingConns.add(remoteId);
    setTimeout(() => pendingConns.delete(remoteId), 15000);
    setupDataConnection(peer.connect(remoteId, { reliable: true, serialization: 'json' }));
}

function setupDataConnection(conn) {
    conn.on('open', () => {
        pendingConns.delete(conn.peer);
        activeConnections[conn.peer] = conn;
        updateConnectionStatus();
        sendPacket(conn, { type: 'hello', payload: {
            username: currentUser.username, role: currentUser.role, level: currentUser.level,
            peers: Object.keys(activeConnections).filter(p => p !== conn.peer)
        } });
        if (isHost) sendPacket(conn, { type: 'room_state', payload: buildRoomState() });
        showLiveUpdate('👻 روح جديدة دخلت الظلام...');
        showBrowserNotification('☣ Horror Death Chat', 'روح أخرى وجدت... لست وحدك في الظلام', { tag: 'hdc-connect', ttl: 5000 });
    });
    conn.on('data', (data) => { try { handleIncomingPacket(data, conn); } catch (e) { console.warn('packet error', e); } });
    const gone = () => {
        if (activeConnections[conn.peer] === conn) delete activeConnections[conn.peer];
        pendingConns.delete(conn.peer);
        verifiedOwnerPeers.delete(conn.peer);
        delete incomingAtt[conn.peer];
        Object.keys(incomingAtt).forEach(id => { if (incomingAtt[id].peer === conn.peer) delete incomingAtt[id]; });
        updateConnectionStatus();
    };
    conn.on('close', () => { const had = !!peerNames[conn.peer]; gone(); if (had) appendSystemMessage('💨 ' + peerNames[conn.peer] + ' غادر الظلام.'); delete peerNames[conn.peer]; handlePeerDisconnect(conn.peer); });
    conn.on('error', (err) => { console.warn('Connection error:', err); gone(); });
}

function handleHello(p, conn) {
    if (!p) return;
    const name = sanitizeName(p.username);
    if (!name) return;
    const first = !peerNames[conn.peer];
    peerNames[conn.peer] = name;
    if (OWNER_NAMES.includes(name) && !verifiedOwnerPeers.has(conn.peer)) {
        const nonce = b64(crypto.getRandomValues(new Uint8Array(16)));
        pendingChallenges[conn.peer] = nonce;
        sendPacket(conn, { type: 'owner_challenge', payload: { nonce } });
    }
    if (Array.isArray(p.peers)) p.peers.slice(0, 30).forEach(pid => { if (typeof pid === 'string' && pid.length < 64) connectToPeer(pid); });
    if (first) { appendSystemMessage('👻 ' + name + ' انضم إلى الظلام.'); showLiveUpdate('👻 ' + name + ' دخل الغرفة.'); stopGhostBot(); }
}

const OWNER_ONLY_PACKETS = new Set(['system_broadcast', 'force_ban_signal', 'owner_warning', 'coins_gift', 'delete_msg']);

function handleIncomingPacket(packet, conn) {
    if (!packet || typeof packet !== 'object' || typeof packet.type !== 'string' || !conn) return;
    const p = packet.payload;
    if (OWNER_ONLY_PACKETS.has(packet.type) && !verifiedOwnerPeers.has(conn.peer)) return;
    switch (packet.type) {
        case 'hello': return handleHello(p, conn);
        case 'typing': return window.handleTyping(p, conn);
        case 'edit_msg': return window.handleEditMsg(p, conn);
        case 'del_own': return window.handleDelOwn(p, conn);
        case 'poll': return window.handlePoll(p, conn);
        case 'vote': return window.handleVote(p, conn);
        case 'pin': return window.handlePin(p, conn);
        case 'scare': return window.handleScare(p, conn);
        case 'owner_challenge': return answerOwnerChallenge(p, conn);
        case 'owner_proof': return verifyOwnerProof(p, conn);
        case 'att_chunk': return handleAttChunk(p, conn);
        case 'chat': return handleChatPacket(p, conn);
        case 'private_msg': return handlePrivateMsgPacket(p);
        case 'room_state': return handleRoomState(p);
        case 'user_joined': return;
        case 'user_left': return;
        case 'host_migration': return handleHostMigration(p);
        case 'system_broadcast': {
            const t = String((p && p.text) || '').slice(0, 300);
            appendSystemMessage('📢 ' + t); showLiveUpdate('📢 ' + t); return;
        }
        case 'force_ban_signal': return handleForceBanSignal(p);
        case 'owner_warning': return handleOwnerWarning(p);
        case 'curse': return handleCursePacket(p);
        case 'seance': return handleSeancePacket(p);
        case 'seance_end': return endSeanceEffect();
        case 'ouija_move': return handleOuijaMovePacket(p);
        case 'killer_game_start': return handleKillerGameStart(p);
        case 'reaction': return handleReactionPacket(p);
        case 'delete_msg': return handleDeleteMsgPacket(p);
        case 'coins_gift': return handleCoinsGiftPacket(p);
        default: return;
    }
}

function persistMessage(msg) {
    if (msg.viewOnce) {
        viewOnceStore.set(msg.id, Object.assign({}, msg));
        dbSaveMessage(Object.assign({}, msg, { text: '', attachmentData: null }));
    } else dbSaveMessage(msg);
}

function handleChatPacket(payload, conn) {
    if (!payload || typeof payload !== 'object') return;
    const id = String(payload.id || '');
    if (!/^[\w-]{1,64}$/.test(id) || seenMsgIds.has(id)) return;
    seenMsgIds.add(id);
    if (seenMsgIds.size > 3000) seenMsgIds.delete(seenMsgIds.values().next().value);

    let sender = peerNames[conn.peer] || sanitizeName(payload.sender) || 'مجهول';
    const verified = verifiedOwnerPeers.has(conn.peer);
    if (OWNER_NAMES.includes(sender) && !verified) sender = '⚠️ منتحل (' + sender + ')';
    const total = parseInt(payload.attachmentTotal) || 0;
    if (total < 0 || total * ATT_CHUNK > MAX_ATT_BYTES * 1.4 + ATT_CHUNK) return;

    const msg = {
        id, sender,
        role: String(payload.role || '').slice(0, 30),
        text: filterProfanity(String(payload.text || '').slice(0, 2000)),
        viewOnce: !!payload.viewOnce,
        timestamp: String(payload.timestamp || '').slice(0, 20),
        level: Math.max(0, Math.min(verified ? 100 : 99, parseInt(payload.level) || 0)),
        room: currentRoom ? currentRoom.name : 'public',
        verifiedOwner: verified,
        attachmentType: payload.attachmentType ? String(payload.attachmentType).slice(0, 10) : null,
        attachmentName: payload.attachmentName ? String(payload.attachmentName).slice(0, 80) : null,
        attachmentData: null,
        attachmentPending: total > 0
    };
    if (total > 0) incomingAtt[id] = { peer: conn.peer, parts: new Array(total), got: 0, total, msg };
    else if (payload.attachmentData && isSafeAttachmentData(payload.attachmentData)) msg.attachmentData = payload.attachmentData;

    if (!msg.attachmentPending) persistMessage(msg);
    else if (msg.viewOnce) viewOnceStore.set(id, Object.assign({}, msg));
    renderSingleMessage(msg);
    scrollChatToBottom();
    playHorrorMsgSound();
    addNotification('💬 رسالة جديدة من ' + msg.sender);
    showLiveUpdate('💬 ' + msg.sender + ': ' + (msg.viewOnce ? '[أثر محمي]' : (msg.text || '[مرفق]')).substring(0, 40));
    showBrowserNotification('☣ رسالة جديدة في Horror Death Chat', msg.sender + (msg.viewOnce ? ': [أثر محمي]' : ': ' + (msg.text || '[مرفق]').substring(0, 60)), { tag: 'hdc-chat', ttl: 5000 });
}

function handleAttChunk(p, conn) {
    if (!p || typeof p.d !== 'string' || p.d.length > ATT_CHUNK + 500) return;
    const a = incomingAtt[p.id];
    if (!a || a.peer !== conn.peer || !Number.isInteger(p.i) || p.i < 0 || p.i >= a.total || a.parts[p.i] !== undefined) return;
    a.parts[p.i] = p.d; a.got++;
    const prog = document.getElementById('att-prog-' + p.id);
    if (prog) prog.textContent = '⏳ جاري استقبال المرفق ' + Math.round(a.got / a.total * 100) + '%';
    if (a.got < a.total) return;
    delete incomingAtt[p.id];
    const data = a.parts.join('');
    const msg = a.msg;
    msg.attachmentPending = false;
    if (!isSafeAttachmentData(data)) { if (prog) prog.textContent = '⚠️ مرفق غير مدعوم أو غير آمن'; return; }
    msg.attachmentData = data;
    persistMessage(msg);
    if (msg.viewOnce) { if (prog) prog.remove(); return; }
    if (prog) prog.replaceWith(buildAttachmentElement(msg.attachmentType, data, msg.attachmentName));
    scrollChatToBottom();
}

/* ── إرسال المرفقات على دفعات (حل عدم وصول الصورة/الصوت/الفيديو) ── */
async function sendAttachmentPackets(msg) {
    const data = msg.attachmentData, total = Math.ceil(data.length / ATT_CHUNK);
    const head = Object.assign({}, msg, { attachmentData: null, attachmentTotal: total });
    broadcastPacket({ type: 'chat', payload: head });
    Object.keys(activeConnections).forEach(pid => {
        const c = activeConnections[pid];
        (async () => {
            for (let i = 0; i < total; i++) {
                if (!c.open) return;
                while (c.dataChannel && c.dataChannel.bufferedAmount > 512 * 1024) await sleep(40);
                sendPacket(c, { type: 'att_chunk', payload: { id: msg.id, i, total, d: data.slice(i * ATT_CHUNK, (i + 1) * ATT_CHUNK) } });
                if (i % 16 === 15) await sleep(0);
            }
        })();
    });
}

const MIME_BY_EXT = { mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', weba: 'audio/webm', opus: 'audio/ogg',
    mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', m4v: 'video/mp4', '3gp': 'video/3gpp',
    jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', pdf: 'application/pdf', zip: 'application/zip' };

function readAsDataURL(blob) {
    return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
}
function compressImage(file) {
    return new Promise((res) => {
        const url = URL.createObjectURL(file), img = new Image();
        img.onload = () => {
            const s = Math.min(1, 1280 / Math.max(img.width, img.height));
            const c = document.createElement('canvas'); c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
            c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
            URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.82));
        };
        img.onerror = () => { URL.revokeObjectURL(url); readAsDataURL(file).then(res, () => res(null)); };
        img.src = url;
    });
}
function isSafeAttachmentData(data) {
    return typeof data === 'string' && /^data:(image\/(png|jpe?g|gif|webp|bmp|avif|heic|heif)|audio\/[\w.+-]+|video\/[\w.+-]+|application\/(pdf|zip|x-zip-compressed|octet-stream|msword|x-rar-compressed|vnd\.[\w.+-]+)|text\/plain)(;[\w=.-]+)*;base64,/i.test(data.slice(0, 120));
}
function dataUrlToBlob(d) {
    const i = d.indexOf(',');
    const bin = atob(d.slice(i + 1)), u = new Uint8Array(bin.length);
    for (let k = 0; k < bin.length; k++) u[k] = bin.charCodeAt(k);
    return new Blob([u], { type: d.slice(5, i).split(';')[0] });
}
function openLightbox(url) {
    const o = document.createElement('div');
    o.style.cssText = 'position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.96);display:flex;align-items:center;justify-content:center;padding:8px';
    const i = document.createElement('img'); i.src = url; i.style.cssText = 'max-width:100%;max-height:100%;object-fit:contain';
    o.appendChild(i); o.onclick = () => o.remove(); document.body.appendChild(o);
}
function buildAttachmentElement(type, data, name) {
    if (!isSafeAttachmentData(data)) {
        const err = document.createElement('span');
        err.className = 'text-[10px] text-red-800 italic'; err.textContent = '⚠️ مرفق غير مدعوم أو غير آمن';
        return err;
    }
    let url; try { url = URL.createObjectURL(dataUrlToBlob(data)); } catch (e) { url = data; }
    const kind = data.slice(5, data.indexOf('/'));
    const fallback = (el) => { el.addEventListener('error', () => { const a = document.createElement('a'); a.href = url; a.download = name || 'attachment'; a.className = 'text-indigo-400 underline text-[11px] mt-1 block'; a.textContent = '⬇️ تعذر التشغيل — تحميل الملف'; el.replaceWith(a); }); return el; };
    if (kind === 'image') {
        const img = document.createElement('img'); img.src = url; img.alt = 'صورة'; img.className = 'attachment-image mt-1';
        img.addEventListener('click', (e) => { e.stopPropagation(); openLightbox(url); });
        return img;
    }
    if (kind === 'audio') {
        const a = document.createElement('audio'); a.controls = true; a.preload = 'metadata'; a.className = 'attachment-audio mt-1'; a.src = url;
        a.addEventListener('click', e => e.stopPropagation());
        return fallback(a);
    }
    if (kind === 'video') {
        const v = document.createElement('video'); v.controls = true; v.preload = 'metadata'; v.playsInline = true; v.setAttribute('playsinline', ''); v.className = 'attachment-video mt-1'; v.src = url;
        v.addEventListener('click', e => e.stopPropagation());
        return fallback(v);
    }
    const a = document.createElement('a'); a.href = url; a.download = name || 'attachment';
    a.className = 'text-indigo-400 underline text-[11px] mt-1 block'; a.textContent = '⬇️ تحميل الملف';
    a.addEventListener('click', e => e.stopPropagation());
    return a;
}

async function dispatchAttachment(type, dataUrl, name) {
    if (!currentUser || !dataUrl) return;
    const msg = {
        id: 'att_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        sender: currentUser.username, role: currentUser.role,
        text: '📎 ' + (name || ''), attachmentType: type, attachmentName: name || null, attachmentData: dataUrl,
        viewOnce: viewOnceActive,
        timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
        level: currentUser.level, room: currentRoom ? currentRoom.name : 'public'
    };
    seenMsgIds.add(msg.id);
    persistMessage(msg);
    renderSingleMessage(msg);
    scrollChatToBottom();
    sendAttachmentPackets(msg);
    if (viewOnceActive) toggleViewOnce();
}

async function processAttachment(input) {
    const file = input.files && input.files[0];
    input.value = '';
    if (!file || !currentUser) return;
    if (isCursed) { appendSystemMessage('⛓️ لا يمكنك الإرسال. أنت ملعون حالياً.'); return; }
    if (file.size > MAX_ATT_BYTES) { alert('الملف كبير جداً! الحد الأقصى 10 ميغابايت.'); return; }
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    let mime = file.type || MIME_BY_EXT[ext] || 'application/octet-stream';
    const kind = mime.split('/')[0];
    const type = ['image', 'audio', 'video'].includes(kind) ? kind : 'file';
    showLiveUpdate('⏳ جاري تجهيز المرفق...');
    try {
        const data = (type === 'image' && mime !== 'image/gif') ? await compressImage(file) : await readAsDataURL(file.type ? file : new Blob([file], { type: mime }));
        if (data) dispatchAttachment(type, data, file.name);
    } catch (e) { alert('فشل قراءة الملف. حاول مجدداً.'); }
}

/* ── تسجيل رسالة صوتية ── */
let recorder = null, recChunks = [], recStream = null;
async function toggleVoiceRecord() {
    const btn = document.getElementById('voice-rec-btn');
    if (recorder && recorder.state === 'recording') { recorder.stop(); return; }
    if (!currentUser || (currentUser.level < 1 && !isOwner())) { triggerFirewallModal('جدار الحماية: لا تملك صلاحية إرسال المرفقات بمستواك الحالي.'); return; }
    if (!navigator.mediaDevices || !window.MediaRecorder) { alert('متصفحك لا يدعم التسجيل الصوتي.'); return; }
    try { recStream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { alert('لم يتم السماح باستخدام الميكروفون.'); return; }
    const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'].find(t => MediaRecorder.isTypeSupported(t)) || '';
    recChunks = [];
    recorder = new MediaRecorder(recStream, mime ? { mimeType: mime } : undefined);
    recorder.ondataavailable = (e) => { if (e.data && e.data.size) recChunks.push(e.data); };
    recorder.onstop = async () => {
        recStream.getTracks().forEach(t => t.stop());
        if (btn) btn.classList.remove('rec-active');
        const type = (recorder.mimeType || mime || 'audio/webm').split(';')[0];
        const blob = new Blob(recChunks, { type });
        if (!blob.size) return;
        if (blob.size > MAX_ATT_BYTES) { alert('التسجيل كبير جداً.'); return; }
        dispatchAttachment('audio', await readAsDataURL(blob), 'رسالة صوتية');
    };
    recorder.start();
    if (btn) btn.classList.add('rec-active');
    setTimeout(() => { if (recorder && recorder.state === 'recording') recorder.stop(); }, 120000);
}

/* ── الرسائل المخفية (رؤية لمرة واحدة) ── */
function revealAndBurn(msgId) {
    const area = document.getElementById('burn-area-' + msgId);
    if (!area) return;
    const s = viewOnceStore.get(msgId);
    const note = (t) => { const p = document.createElement('p'); p.className = 'text-xs text-red-800/80 italic'; p.textContent = t; return p; };
    if (s && s.attachmentPending) { showLiveUpdate('⏳ المرفق لم يصل بعد، انتظر لحظات.'); return; }
    area.textContent = '';
    if (!s) { area.appendChild(note('🔥 هذا الأثر احترق ولا يمكن قراءته مرة أخرى.')); return; }
    viewOnceStore.delete(msgId);
    const p = document.createElement('p'); p.className = 'text-xs text-stone-300 leading-relaxed'; p.textContent = s.text || ''; area.appendChild(p);
    if (s.attachmentData) area.appendChild(buildAttachmentElement(s.attachmentType, s.attachmentData, s.attachmentName));
    const t = document.createElement('p'); t.className = 'text-[9px] text-red-700 mt-1 italic'; area.appendChild(t);
    let left = 10;
    const iv = setInterval(() => {
        t.textContent = '🔥 يتلاشى خلال ' + left + ' ثانية...';
        if (left-- <= 0) {
            clearInterval(iv);
            area.textContent = ''; area.appendChild(note('🔥 احترق هذا الأثر.'));
            const card = document.getElementById('msg-' + msgId); if (card) card.style.opacity = '0.4';
            dbSaveMessage(Object.assign({}, s, { text: '', attachmentData: null, attachmentType: null, burned: true }));
        }
    }, 1000);
}

/* ── قفل التطبيق (تجزئة PBKDF2 بدل النص الصريح) ── */
async function hashLock(pass, salt) {
    const k = await crypto.subtle.importKey('raw', enc(pass), 'PBKDF2', false, ['deriveBits']);
    return b64(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: unb64(salt), iterations: 150000, hash: 'SHA-256' }, k, 256));
}
async function verifyLock(input) {
    const s = getAppSettings();
    if (s.lockHash && s.lockSalt) return (await hashLock(input, s.lockSalt)) === s.lockHash;
    return !!s.lockPassword && input === s.lockPassword;
}
let lockFails = 0, lockBlockedUntil = 0;
async function unlockApp() {
    const inp = document.getElementById('unlock-pass-input'), errEl = document.getElementById('unlock-error');
    const val = inp.value; inp.value = '';
    if (Date.now() < lockBlockedUntil) { errEl.textContent = '⏳ محاولات كثيرة، انتظر قليلاً.'; errEl.classList.remove('hidden'); return; }
    if (await verifyLock(val)) {
        lockFails = 0;
        const s = getAppSettings();
        if (s.lockPassword && !s.lockHash) { const salt = b64(crypto.getRandomValues(new Uint8Array(16))); saveAppSetting('lockSalt', salt); saveAppSetting('lockHash', await hashLock(val, salt)); saveAppSetting('lockPassword', ''); }
        document.getElementById('lock-screen').classList.add('hidden'); errEl.classList.add('hidden');
    } else {
        playErrorSound();
        if (++lockFails >= 5) { lockBlockedUntil = Date.now() + 30000; lockFails = 0; }
        errEl.textContent = '❌ الرمز غير صحيح، حاول مرة أخرى.'; errEl.classList.remove('hidden');
    }
}
async function settingSaveLockPassword() {
    const pass = ((document.getElementById('settings-lock-password') || {}).value || '').trim();
    if (pass.length < 4) { alert('كلمة المرور يجب أن تكون 4 أحرف على الأقل.'); return; }
    const salt = b64(crypto.getRandomValues(new Uint8Array(16)));
    saveAppSetting('lockSalt', salt); saveAppSetting('lockHash', await hashLock(pass, salt));
    saveAppSetting('lockPassword', ''); saveAppSetting('lockEnabled', true);
    document.getElementById('settings-lock-password').value = '';
    document.getElementById('settings-lock-pw-wrap').classList.add('hidden');
    renderSettingsUI(); addNotification('🔒 تم تفعيل قفل التطبيق.');
}
async function settingToggleLockPanel() {
    const s = getAppSettings();
    if (s.lockEnabled && (s.lockHash || s.lockPassword)) {
        const pw = prompt('أدخل كلمة السر الحالية لإلغاء القفل:');
        if (pw === null) return;
        if (!(await verifyLock(pw))) { alert('❌ كلمة السر غير صحيحة.'); return; }
        saveAppSetting('lockEnabled', false); saveAppSetting('lockPassword', ''); saveAppSetting('lockHash', ''); saveAppSetting('lockSalt', '');
        renderSettingsUI(); addNotification('🔓 تم إلغاء القفل.');
    } else {
        const pw = document.getElementById('settings-lock-pw-wrap'); if (pw) pw.classList.toggle('hidden');
    }
}

/* ── الجوال: ارتفاع الشاشة + لوحة المفاتيح ── */
function setupViewportFix() {
    if (_viewportFixRegistered) return;
    _viewportFixRegistered = true;
    const vv = window.visualViewport;
    const update = () => {
        const h = vv ? vv.height : window.innerHeight;
        document.documentElement.style.setProperty('--app-height', Math.round(h) + 'px');
        const kb = vv ? (window.innerHeight - vv.height > 120) : false;
        document.body.classList.toggle('kb-open', kb);
        if (kb) { window.scrollTo(0, 0); scrollChatToBottom(); }
    };
    update();
    ['resize', 'orientationchange'].forEach(ev => window.addEventListener(ev, () => setTimeout(update, 60)));
    if (vv) { vv.addEventListener('resize', update); vv.addEventListener('scroll', update); }
}

/* ── دعوة برابط + أدوات إضافية ── */
function setupInvite(id) {
    const el = document.getElementById('my-peer-id');
    if (el && !document.getElementById('invite-btn')) {
        const b = document.createElement('button');
        b.id = 'invite-btn'; b.type = 'button';
        b.className = 'mt-1 w-full bg-stone-900 border border-stone-800 text-stone-400 text-[10px] rounded py-1.5';
        b.textContent = '🔗 نسخ رابط الدعوة';
        b.onclick = () => {
            const url = location.href.split('#')[0] + '#join=' + encodeURIComponent(id);
            (navigator.clipboard ? navigator.clipboard.writeText(url) : Promise.reject()).then(() => showLiveUpdate('✅ تم نسخ رابط الدعوة'), () => prompt('انسخ الرابط:', url));
        };
        el.insertAdjacentElement('afterend', b);
    }
    const m = location.hash.match(/join=([^&]+)/);
    if (m) { const rid = decodeURIComponent(m[1]); if (rid && rid !== id) connectToPeer(rid); }
}

document.addEventListener('DOMContentLoaded', () => {
    setupViewportFix();
    const grp = document.getElementById('attachments-buttons-group');
    if (grp && !document.getElementById('voice-rec-btn')) {
        const b = document.createElement('button');
        b.id = 'voice-rec-btn'; b.type = 'button'; b.title = 'تسجيل رسالة صوتية';
        b.className = 'p-2 bg-stone-900 text-stone-600 hover:text-stone-400 rounded border border-stone-800 text-xs';
        b.innerHTML = '<i class="fa-solid fa-circle-dot"></i>';
        b.onclick = toggleVoiceRecord; grp.appendChild(b);
    }
    window.addEventListener('beforeunload', () => { try { if (peer) peer.destroy(); } catch (e) {} });
});

/* ══════════════════════════════════════════════════════════════
   § v7 — حزمة الميزات الجديدة
══════════════════════════════════════════════════════════════ */
(function () {
    const g = (id) => document.getElementById(id);
    const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
    const store = { get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} } };
    const typingTimers = {}; let lastTypingSent = 0, lastScareSent = 0, lastScareSeen = 0, missed = 0, unreadTitle = 0;
    const BASE_TITLE = document.title;

    /* ── نافذة سفلية عامة ── */
    function sheet(title, build) {
        const old = g('hx-sheet'); if (old) old.remove();
        const w = el('div', 'hx-sheet'); w.id = 'hx-sheet';
        const box = el('div', 'hx-sheet-box');
        const head = el('div', 'hx-sheet-head'); head.appendChild(el('b', '', title));
        const x = el('button', 'hx-x', '✕'); x.onclick = () => w.remove(); head.appendChild(x);
        box.appendChild(head); build(box); w.appendChild(box);
        w.addEventListener('click', (e) => { if (e.target === w) w.remove(); });
        document.body.appendChild(w); return w;
    }

    /* ── الإيموجي ── */
    const EMOJIS = '💀 ☠️ 👻 🕷️ 🕸️ 🦇 🩸 🔪 ⚰️ 🪦 🎃 🧟 🧛 🧙 👁️ 🔮 🕯️ 🌑 🌫️ 🐈‍⬛ 😱 😨 😰 😈 👹 🤡 🥀 🖤 ❤️ 🔥 ⚡ 😂 😅 😭 😍 😎 🤔 👍 👎 🙏 👏 💪 🎉 ✨ 🌙 ⭐ 💯 😴 🤯'.split(' ');
    function openEmoji() {
        sheet('إيموجي', (b) => { const grid = el('div', 'hx-grid');
            EMOJIS.forEach(e => { const t = el('button', 'hx-emo', e); t.onclick = () => { const i = g('msg-input'); const p = i.selectionStart ?? i.value.length; i.value = i.value.slice(0, p) + e + i.value.slice(p); i.focus(); }; grid.appendChild(t); });
            b.appendChild(grid); });
    }

    /* ── المتصلون ── */
    function openUsers() {
        sheet('المتصلون الآن', (b) => {
            const names = [currentUser.username + ' (أنت)'].concat(Object.keys(peerNames).filter(p => activeConnections[p]).map(p => peerNames[p] + (verifiedOwnerPeers.has(p) ? ' 👑' : '')));
            b.appendChild(el('p', 'hx-muted', 'العدد: ' + names.length));
            names.forEach(n => b.appendChild(el('div', 'hx-row', '👤 ' + n)));
        });
    }

    /* ── البحث ── */
    function openSearch() {
        sheet('بحث في الرسائل', (b) => {
            const i = el('input', 'hx-input'); i.placeholder = 'اكتب كلمة...'; const c = el('p', 'hx-muted', '');
            i.oninput = () => { const q = i.value.trim().toLowerCase(); let n = 0;
                document.querySelectorAll('#chat-box .msg-card').forEach(m => { const hit = !q || m.textContent.toLowerCase().includes(q); m.style.display = hit ? '' : 'none'; if (q && hit) n++; });
                c.textContent = q ? 'النتائج: ' + n : ''; };
            b.appendChild(i); b.appendChild(c); setTimeout(() => i.focus(), 50);
            const done = el('button', 'hx-btn', 'إظهار الكل'); done.onclick = () => { i.value = ''; i.oninput(); }; b.appendChild(done);
        });
    }

    /* ── تصدير المحادثة ── */
    async function exportChat() {
        const msgs = await dbLoadMessages(currentRoom ? currentRoom.name : 'public');
        const lines = msgs.filter(m => !m.viewOnce).map(m => '[' + (m.timestamp || '') + '] ' + (m.sender || '?') + ': ' + (m.text || ''));
        if (!lines.length) { showLiveUpdate('لا توجد رسائل للتصدير.'); return; }
        const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + lines.join('\n')], { type: 'text/plain;charset=utf-8' }));
        a.download = 'HDChat-' + new Date().toISOString().slice(0, 10) + '.txt'; document.body.appendChild(a); a.click(); a.remove();
    }

    /* ── الأدوات والمظهر ── */
    function applyPrefs() {
        document.documentElement.style.setProperty('--msg-fs', store.get('hx_fs', '12') + 'px');
        document.documentElement.style.setProperty('--hx-accent', store.get('hx_accent', '#b91c1c'));
        document.body.classList.toggle('hx-compact', store.get('hx_compact', '0') === '1');
    }
    function openTools() {
        sheet('الأدوات والمظهر', (b) => {
            const row = (label, ctrl) => { const r = el('div', 'hx-row'); r.appendChild(el('span', '', label)); r.appendChild(ctrl); b.appendChild(r); };
            const fs = el('input'); fs.type = 'range'; fs.min = 11; fs.max = 20; fs.value = store.get('hx_fs', '12'); fs.oninput = () => { store.set('hx_fs', fs.value); applyPrefs(); };
            row('حجم الخط', fs);
            const ac = el('input'); ac.type = 'color'; ac.value = store.get('hx_accent', '#b91c1c'); ac.oninput = () => { store.set('hx_accent', ac.value); applyPrefs(); };
            row('لون التمييز', ac);
            const cp = el('input'); cp.type = 'checkbox'; cp.checked = store.get('hx_compact', '0') === '1'; cp.onchange = () => { store.set('hx_compact', cp.checked ? '1' : '0'); applyPrefs(); };
            row('عرض مضغوط', cp);
            const vb = el('input'); vb.type = 'checkbox'; vb.checked = store.get('hx_vibrate', '1') === '1'; vb.onchange = () => store.set('hx_vibrate', vb.checked ? '1' : '0');
            row('اهتزاز عند الرسائل', vb);
            const sc = el('input'); sc.type = 'checkbox'; sc.checked = store.get('hx_scare', '1') === '1'; sc.onchange = () => store.set('hx_scare', sc.checked ? '1' : '0');
            row('استقبال أمر /boo', sc);
            const ex = el('button', 'hx-btn', '📄 تصدير المحادثة كملف نصي'); ex.onclick = exportChat; b.appendChild(ex);
            const help = el('button', 'hx-btn', '❓ الأوامر السريعة'); help.onclick = showHelp; b.appendChild(help);
        });
    }
    function showHelp() {
        sheet('الأوامر السريعة', (b) => [['/roll [رقم]', 'رمي نرد'], ['/flip', 'ملك أو كتابة'], ['/me نص', 'رسالة حدث'], ['/shrug', 'تجاهل ¯\\_(ツ)_/¯'], ['/boo', 'رعشة قصيرة للجميع'], ['/users', 'عرض المتصلين'], ['/clear', 'مسح الشاشة محلياً'], ['/help', 'هذه القائمة']].forEach(([c, d]) => { const r = el('div', 'hx-row'); r.appendChild(el('code', '', c)); r.appendChild(el('span', 'hx-muted', d)); b.appendChild(r); }));
    }

    /* ── الأوامر ── */
    function runCommand(v) {
        const [cmd, ...rest] = v.split(/\s+/), arg = rest.join(' ');
        switch (cmd.toLowerCase()) {
            case '/roll': { const n = Math.min(1000, Math.max(2, parseInt(arg) || 6)); return '🎲 ' + currentUser.username + ' رمى النرد (1-' + n + ') فجاءت: ' + (1 + crypto.getRandomValues(new Uint32Array(1))[0] % n); }
            case '/flip': return '🪙 ' + currentUser.username + ' رمى العملة فجاءت: ' + (crypto.getRandomValues(new Uint8Array(1))[0] & 1 ? 'ملك 👑' : 'كتابة ✍️');
            case '/me': return arg ? '✦ ' + currentUser.username + ' ' + arg : true;
            case '/shrug': return (arg ? arg + ' ' : '') + '¯\\_(ツ)_/¯';
            case '/boo': { if (Date.now() - lastScareSent < 30000) { showLiveUpdate('⏳ انتظر 30 ثانية بين كل /boo'); return true; } lastScareSent = Date.now(); broadcastPacket({ type: 'scare', payload: {} }); scare(); return true; }
            case '/users': openUsers(); return true;
            case '/clear': renderAllMessages([]); return true;
            case '/help': showHelp(); return true;
            default: return null;
        }
    }
    const _send = sendBroadcastMessage;
    sendBroadcastMessage = function () {
        const i = g('msg-input');
        if (i && currentUser && i.value.trim().startsWith('/')) {
            const r = runCommand(i.value.trim());
            if (r === true) { i.value = ''; return; }
            if (typeof r === 'string') i.value = r;
        }
        _send();
    };

    /* ── رعشة /boo ── */
    function scare() {
        const o = el('div', 'hx-scare'); document.body.appendChild(o); try { playHorrorAlertSound(); } catch (e) {}
        if (navigator.vibrate) navigator.vibrate([120, 60, 200]); setTimeout(() => o.remove(), 900);
    }
    window.handleScare = function (p, conn) { if (store.get('hx_scare', '1') !== '1' || Date.now() - lastScareSeen < 20000) return; lastScareSeen = Date.now(); scare(); };

    /* ── مؤشر الكتابة ── */
    window.handleTyping = function (p, conn) {
        const n = peerNames[conn.peer]; if (!n) return;
        clearTimeout(typingTimers[n]); typingTimers[n] = setTimeout(() => { delete typingTimers[n]; renderTyping(); }, 3500); renderTyping();
    };
    function renderTyping() { const t = g('hx-typing'); if (!t) return; const a = Object.keys(typingTimers); t.textContent = a.length ? '✍️ ' + a.slice(0, 3).join('، ') + (a.length > 1 ? ' يكتبون...' : ' يكتب...') : ''; }

    /* ── زر النزول + العداد + عنوان التبويب ── */
    function watchChat() {
        const out = g('chat-box-outer'), box = g('chat-box'); if (!out || !box) return;
        const jump = el('button', 'hx-jump', '⬇'); jump.style.display = 'none'; jump.onclick = () => { out.scrollTop = out.scrollHeight; };
        (g('chat-main-area') || document.body).appendChild(jump);
        const far = () => out.scrollHeight - out.scrollTop - out.clientHeight > 160;
        out.addEventListener('scroll', () => { if (!far()) { missed = 0; jump.style.display = 'none'; jump.textContent = '⬇'; } else jump.style.display = ''; }, { passive: true });
        new MutationObserver((ms) => {
            const added = ms.reduce((a, m) => a + m.addedNodes.length, 0);
            if (far()) { missed += added; jump.style.display = ''; jump.textContent = '⬇ ' + missed; }
            if (document.hidden && added) { unreadTitle += added; document.title = '(' + unreadTitle + ') ' + BASE_TITLE; if (store.get('hx_vibrate', '1') === '1' && navigator.vibrate) navigator.vibrate(80); }
        }).observe(box, { childList: true });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) { unreadTitle = 0; document.title = BASE_TITLE; } });
    }

    /* ── لصق صورة + سحب وإفلات ── */
    function attachInputs() {
        const i = g('msg-input');
        i.addEventListener('paste', (e) => { const f = e.clipboardData && e.clipboardData.files && e.clipboardData.files[0]; if (f) { e.preventDefault(); processAttachment({ files: [f], value: '' }); } });
        i.addEventListener('input', () => { if (Date.now() - lastTypingSent > 2000 && i.value) { lastTypingSent = Date.now(); broadcastPacket({ type: 'typing', payload: {} }); } });
        i.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendBroadcastMessage(); } });
        ['dragover', 'drop'].forEach(ev => document.addEventListener(ev, (e) => { if (!e.dataTransfer || !e.dataTransfer.types.includes('Files')) return; e.preventDefault(); if (ev === 'drop' && e.dataTransfer.files[0]) processAttachment({ files: [e.dataTransfer.files[0]], value: '' }); }));
    }

    function init() {
        applyPrefs();
        const area = g('input-area'); if (!area || g('hx-bar')) return;
        const bar = el('div', 'hx-bar'); bar.id = 'hx-bar';
        [['😀', 'إيموجي', openEmoji], ['🔍', 'بحث', openSearch], ['👥', 'المتصلون', openUsers], ['⚙️', 'الأدوات', openTools]].forEach(([t, ti, fn]) => { const b = el('button', 'hx-tb', t); b.type = 'button'; b.title = ti; b.onclick = (e) => { e.stopPropagation(); if (currentUser) fn(); }; bar.appendChild(b); });
        const ty = el('span', 'hx-typing'); ty.id = 'hx-typing'; bar.appendChild(ty);
        area.insertBefore(bar, area.firstChild);
        attachInputs(); watchChat();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

/* ══════════════════════════════════════════════════════════════
   § v8 — ردود، استطلاعات، تثبيت، إشارات، روابط، والمزيد
══════════════════════════════════════════════════════════════ */
(function () {
    const g = (id) => document.getElementById(id);
    const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
    const ls = { get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} }, del: (k) => { try { localStorage.removeItem(k); } catch (e) {} } };
    const clip = (s, n) => { s = String(s || '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n) + '…' : s; };
    let replyTo = null, pinned = '', deferredInstall = null, wakeLock = null;
    const polls = {}, pinSent = new Set();
    const URL_RE = /(https?:\/\/[^\s<>"']{3,200})/g;
    const BIG_RE = /^(?:\p{Extended_Pictographic}|\uFE0F|\u200D|\s){1,14}$/u;
    OWNER_ONLY_PACKETS.add('pin');

    function sheet(title, build) {
        const old = g('hx-sheet'); if (old) old.remove();
        const w = el('div', 'hx-sheet'); w.id = 'hx-sheet'; const box = el('div', 'hx-sheet-box');
        const head = el('div', 'hx-sheet-head'); head.appendChild(el('b', '', title));
        const x = el('button', 'hx-x', '✕'); x.onclick = () => w.remove(); head.appendChild(x);
        box.appendChild(head); build(box, w); w.appendChild(box);
        w.addEventListener('click', (e) => { if (e.target === w) w.remove(); }); document.body.appendChild(w);
    }

    /* ── معالجة كل رسالة جديدة: رد، رابط، إيموجي كبير، إشارة ── */
    function decorate(card, batch) {
        if (!card.classList || !card.classList.contains('msg-card') || card.dataset.hx) return;
        card.dataset.hx = '1';
        const senderEl = card.querySelector('[data-sender]'), sender = senderEl ? senderEl.dataset.sender : '';
        const body = card.querySelector('.msg-body');
        const isMe = currentUser && sender === currentUser.username;
        if (body) {
            const t = body.firstChild && body.firstChild.nodeType === 3 ? body.firstChild : null;
            if (t) {
                const txt = t.nodeValue;
                if (BIG_RE.test(txt) && txt.trim()) body.classList.add('hx-big');
                if (URL_RE.test(txt)) {
                    URL_RE.lastIndex = 0; const frag = document.createDocumentFragment();
                    txt.split(URL_RE).forEach((part, i) => {
                        if (i % 2) { const a = el('a', 'hx-link', part); a.href = part; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow'; a.addEventListener('click', (e) => e.stopPropagation()); frag.appendChild(a); }
                        else if (part) frag.appendChild(document.createTextNode(part));
                    });
                    body.replaceChild(frag, t);
                }
                URL_RE.lastIndex = 0;
                if (currentUser && !isMe && txt.toLowerCase().includes('@' + currentUser.username.toLowerCase())) {
                    card.classList.add('hx-mention');
                    if (batch === 1) { showLiveUpdate('🔔 ' + sender + ' ذكرك في رسالة'); if (navigator.vibrate) navigator.vibrate([60, 40, 60]); }
                }
            }
            const hdr = card.firstElementChild;
            if (hdr && !card.querySelector('.hx-reply-btn')) {
                const b = el('button', 'hx-reply-btn', '↩'); b.type = 'button'; b.title = 'رد';
                b.onclick = (e) => { e.stopPropagation(); setReply(sender, body.textContent); };
                hdr.appendChild(b);
            }
        }
    }
    function setReply(name, text) {
        replyTo = { name: clip(name, 24), snip: clip(text, 60) };
        let bar = g('hx-reply');
        if (!bar) { bar = el('div', 'hx-replybar'); bar.id = 'hx-reply'; const a = g('hx-bar'); a.insertAdjacentElement('afterend', bar); }
        bar.textContent = ''; bar.appendChild(el('span', '', '↩ رد على ' + replyTo.name + ': ' + replyTo.snip));
        const x = el('button', 'hx-x', '✕'); x.onclick = clearReply; bar.appendChild(x);
        const i = g('msg-input'); if (i) i.focus();
    }
    function clearReply() { replyTo = null; const b = g('hx-reply'); if (b) b.remove(); }
    function mention(name) { const i = g('msg-input'); if (i) { i.value += (i.value && !i.value.endsWith(' ') ? ' ' : '') + '@' + name + ' '; i.focus(); } }

    /* ── الاستطلاعات ── */
    function pollEl(p) {
        if (!p.el) { p.el = el('div', 'hx-poll'); const box = g('chat-box'); if (box) box.appendChild(p.el); }
        const e = p.el; e.textContent = ''; e.appendChild(el('b', '', '📊 ' + p.q + '  —  ' + p.by));
        const total = Object.keys(p.votes).length;
        p.opts.forEach((o, i) => {
            const n = Object.values(p.votes).filter(v => v === i).length, pct = total ? Math.round(n / total * 100) : 0;
            const b = el('button', 'hx-opt' + (p.votes.me === i ? ' mine' : '')); b.type = 'button';
            const fill = el('span', 'hx-fill'); fill.style.width = pct + '%'; b.appendChild(fill);
            b.appendChild(el('span', 'hx-opt-t', o + '  (' + n + ' · ' + pct + '%)'));
            b.onclick = (ev) => { ev.stopPropagation(); p.votes.me = i; broadcastPacket({ type: 'vote', payload: { id: p.id, i } }); pollEl(p); };
            e.appendChild(b);
        });
        e.appendChild(el('small', 'hx-muted', 'الأصوات: ' + total));
        scrollChatToBottom();
    }
    function makePoll(q, opts, by, id) {
        q = clip(q, 120); opts = opts.map(o => clip(o, 60)).filter(Boolean).slice(0, 6);
        if (!q || opts.length < 2) return false;
        id = id || ('poll_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5));
        if (polls[id]) return false;
        polls[id] = { id, q, opts, by: clip(by, 24), votes: {} }; pollEl(polls[id]); return polls[id];
    }
    window.handlePoll = (p, conn) => { if (!p || !/^poll_[\w]{3,24}$/.test(p.id) || !Array.isArray(p.opts) || typeof p.q !== 'string') return; if (makePoll(p.q, p.opts.map(String), peerNames[conn.peer] || '؟', p.id)) { playHorrorMsgSound(); showLiveUpdate('📊 استطلاع جديد من ' + (peerNames[conn.peer] || '؟')); } };
    window.handleVote = (p, conn) => { const pl = p && polls[p.id]; if (!pl || !Number.isInteger(p.i) || p.i < 0 || p.i >= pl.opts.length) return; pl.votes[conn.peer] = p.i; pollEl(pl); };

    /* ── الرسالة المثبتة (للمالك) ── */
    function showPin(t) {
        pinned = clip(t, 300); let b = g('hx-pin');
        if (!pinned) { if (b) b.remove(); return; }
        if (!b) { b = el('div', 'hx-pin'); b.id = 'hx-pin'; const o = g('chat-box-outer'); o.parentNode.insertBefore(b, o); }
        b.textContent = '📌 ' + pinned;
    }
    window.handlePin = (p) => showPin((p && p.text) || '');

    /* ── تغليف الإرسال: رد + مسودة + /poll + /pin ── */
    const _prev = sendBroadcastMessage;
    sendBroadcastMessage = function () {
        const i = g('msg-input'); if (!i || !currentUser) return _prev();
        const raw = i.value.trim();
        if (/^\/poll(\s|$)/i.test(raw)) {
            const [q, ...o] = raw.replace(/^\/poll\s*/i, '').split('|').map(s => s.trim());
            const pl = makePoll(q, o, currentUser.username);
            if (pl) broadcastPacket({ type: 'poll', payload: { id: pl.id, q: pl.q, opts: pl.opts } }); else appendSystemMessage('الصيغة: /poll السؤال | خيار1 | خيار2');
            i.value = ''; return;
        }
        if (/^\/(un)?pin(\s|$)/i.test(raw)) {
            if (!ownerPrivateKey) { appendSystemMessage('⛔ التثبيت للمالك فقط.'); i.value = ''; return; }
            const t = /^\/unpin/i.test(raw) ? '' : raw.replace(/^\/pin\s*/i, ''); showPin(t); pinSent.clear();
            broadcastPacket({ type: 'pin', payload: { text: pinned } }); i.value = ''; return;
        }
        const orig = i.value;
        if (replyTo && raw && !raw.startsWith('/')) i.value = '↪ ' + replyTo.name + ': «' + replyTo.snip + '»\n' + raw;
        _prev();
        if (i.value) i.value = orig; else { clearReply(); ls.del('hx_draft'); }
    };

    /* ── المزيد ── */
    function openMore() {
        sheet('المزيد', (b) => {
            b.appendChild(el('b', '', '📊 إنشاء استطلاع'));
            const q = el('input', 'hx-input'); q.placeholder = 'السؤال'; const o = el('textarea', 'hx-input'); o.rows = 4; o.placeholder = 'الخيارات، كل خيار في سطر (من 2 إلى 6)';
            const go = el('button', 'hx-btn', 'نشر الاستطلاع');
            go.onclick = () => { const pl = makePoll(q.value, o.value.split('\n'), currentUser.username); if (!pl) { alert('اكتب سؤالاً وخيارين على الأقل.'); return; } broadcastPacket({ type: 'poll', payload: { id: pl.id, q: pl.q, opts: pl.opts } }); g('hx-sheet').remove(); };
            [q, o, go].forEach(x => b.appendChild(x));
            const add = (label, fn) => { const x = el('button', 'hx-btn', label); x.onclick = fn; b.appendChild(x); return x; };
            if (deferredInstall) add('📲 تثبيت التطبيق على الهاتف', async () => { deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; g('hx-sheet').remove(); });
            add('🔗 مشاركة رابط الدعوة', () => { if (!peer || !peer.id) return; const url = location.href.split('#')[0] + '#join=' + encodeURIComponent(peer.id); if (navigator.share) navigator.share({ title: 'Horror Death Chat', text: 'تعال ندردش في الظلام ☠', url }).catch(() => {}); else (navigator.clipboard ? navigator.clipboard.writeText(url) : Promise.reject()).then(() => showLiveUpdate('✅ تم نسخ الرابط'), () => prompt('انسخ الرابط:', url)); });
            if ('wakeLock' in navigator) { const w = add(wakeLock ? '💡 إيقاف إبقاء الشاشة مضيئة' : '💡 إبقاء الشاشة مضيئة', async () => { try { if (wakeLock) { await wakeLock.release(); wakeLock = null; } else wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {} g('hx-sheet').remove(); }); }
            add('❓ الأوامر: /poll و /pin و @اسم لإشارة شخص', () => {});
            const users = Object.keys(peerNames).filter(p => activeConnections[p]);
            if (users.length) { b.appendChild(el('p', 'hx-muted', 'اضغط على اسم لإشارته:')); const r = el('div', 'hx-chips'); users.forEach(p => { const c = el('button', 'hx-chip', '@' + peerNames[p]); c.onclick = () => { mention(peerNames[p]); g('hx-sheet').remove(); }; r.appendChild(c); }); b.appendChild(r); }
        });
    }

    function init() {
        const bar = g('hx-bar'), box = g('chat-box'), inp = g('msg-input');
        if (!bar || !box || !inp) return setTimeout(init, 300);
        const more = el('button', 'hx-tb', '➕'); more.type = 'button'; more.title = 'المزيد'; more.onclick = (e) => { e.stopPropagation(); if (currentUser) openMore(); };
        bar.insertBefore(more, g('hx-typing'));
        new MutationObserver((ms) => { const n = ms.reduce((a, m) => a + m.addedNodes.length, 0); ms.forEach(m => m.addedNodes.forEach(x => decorate(x, n))); }).observe(box, { childList: true });
        inp.value = ls.get('hx_draft', ''); inp.addEventListener('input', () => ls.set('hx_draft', inp.value));
        window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredInstall = e; });
        document.addEventListener('visibilitychange', async () => { if (wakeLock && !document.hidden) { try { wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {} } });
        setInterval(() => {
            const users = Object.keys(activeConnections).length; const ub = [...bar.querySelectorAll('.hx-tb')].find(b => b.title === 'المتصلون'); if (ub) ub.textContent = '👥' + (users ? ' ' + (users + 1) : '');
            if (ownerPrivateKey && pinned) Object.keys(activeConnections).forEach(pid => { if (!pinSent.has(pid) && activeConnections[pid].open) { pinSent.add(pid); sendPacket(activeConnections[pid], { type: 'pin', payload: { text: pinned } }); } });
        }, 3000);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

/* ══════════════════════════════════════════════════════════════
   § v9 — تعديل/حذف الرسائل، تنسيق النص، رسائل تحترق، ألعاب، كتم، إحصائيات، ثيمات
══════════════════════════════════════════════════════════════ */
(function () {
    const g = (id) => document.getElementById(id);
    const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
    const ls = { get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} } };
    const pick = (a) => a[crypto.getRandomValues(new Uint32Array(1))[0] % a.length];
    const senderOf = (card) => { const s = card && card.querySelector('[data-sender]'); return s ? s.dataset.sender : ''; };
    const muted = new Set(JSON.parse(ls.get('hx_muted', '[]') || '[]'));
    OWNER_ONLY_PACKETS.delete('del_own');

    const SHORT = { skull: '💀', ghost: '👻', fire: '🔥', heart: '🖤', eye: '👁️', bat: '🦇', spider: '🕷️', coffin: '⚰️', moon: '🌑', knife: '🔪', blood: '🩸', zombie: '🧟', smile: '🙂', cry: '😭', ok: '👍', pray: '🙏', laugh: '😂', scream: '😱', devil: '😈', candle: '🕯️' };
    const BALL = ['نعم، بلا شك 💀', 'الأرواح تقول نعم 👻', 'الظلام يقول لا 🌑', 'اسأل مرة أخرى بعد منتصف الليل 🕯️', 'مستحيل 🪦', 'ربما... إن نجوت 🩸', 'الإشارات غامضة 🔮', 'بالتأكيد ☠️'];
    const TRUTH = ['ما أكثر شيء أخافك في حياتك؟', 'ما أغرب حلم أو كابوس رأيته؟', 'هل رأيت شيئاً لم تستطع تفسيره؟', 'ما السر الذي لم تخبر به أحداً هنا؟', 'أي فيلم رعب لم تستطع إكماله؟'];
    const DARE = ['اكتب رسالة كاملة بدون حرف الألف!', 'ابعث أسوأ نكتة تعرفها الآن.', 'غيّر اسمك لاسم شبح لمدة خمس دقائق.', 'صِف أقرب شخص لك بثلاث كلمات مرعبة.', 'اروِ قصة رعب في جملة واحدة.'];
    const SCARY = ['سمعتَ خطواتٍ خلفك... لكنك تعيش وحدك. 🕯️', 'المرآة ابتسمت... قبل أن تفعل أنت. 🪞', 'وصلتك رسالة من رقمك أنت: «لا تلتفت». 📱', 'الباب الذي أغلقتَه بالمفتاح... فُتح من الداخل. 🚪', 'كل الصور في هاتفك تحدّق بك الآن. 👁️'];

    /* ── قاعدة البيانات: تعديل / حذف ── */
    function dbUpdateText(id, text) { if (!db) return; try { const st = db.transaction('messages', 'readwrite').objectStore('messages'); st.get(id).onsuccess = (e) => { const r = e.target.result; if (r) { r.text = text; r.edited = true; st.put(r); } }; } catch (e) {} }
    function dbDeleteMsg(id) { if (!db) return; try { const tx = db.transaction(['messages', 'attachments'], 'readwrite'); tx.objectStore('messages').delete(id); tx.objectStore('attachments').delete(id); } catch (e) {} }

    /* ── تعديل وحذف رسائلي ── */
    function redecorate(card) { delete card.dataset.hx; delete card.dataset.hxf; const p = card.parentNode; if (p) p.insertBefore(card, card.nextSibling); }
    function applyEdit(card, text) {
        const body = card.querySelector('.msg-body'); if (!body) return;
        body.textContent = text; card.dataset.edited = '1'; redecorate(card);
        setTimeout(() => { const b = card.querySelector('.msg-body'); if (b && !b.querySelector('.hx-edited')) b.appendChild(el('small', 'hx-edited', ' (معدّلة)')); }, 0);
    }
    function editMine(card) {
        const body = card.querySelector('.msg-body'); if (!body || body.querySelector('img,audio,video')) return;
        const clone = body.cloneNode(true); clone.querySelectorAll('.hx-edited').forEach(x => x.remove());
        const t = prompt('عدّل رسالتك:', clone.textContent); if (t === null) return;
        const text = filterProfanity(t.trim().slice(0, 1000)); if (!text) return;
        const id = card.id.slice(4); applyEdit(card, text); dbUpdateText(id, text);
        broadcastPacket({ type: 'edit_msg', payload: { id, text } });
    }
    function deleteMine(card) {
        if (!confirm('حذف هذه الرسالة عند الجميع؟')) return;
        const id = card.id.slice(4); handleDeleteMsgPacket({ msgId: id }); dbDeleteMsg(id);
        broadcastPacket({ type: 'del_own', payload: { id } });
    }
    const ownsRemote = (card, conn) => card && peerNames[conn.peer] && senderOf(card) === peerNames[conn.peer];
    window.handleEditMsg = (p, conn) => { if (!p || typeof p.text !== 'string' || !/^[\w-]{1,64}$/.test(p.id || '')) return; const c = g('msg-' + p.id); if (ownsRemote(c, conn)) applyEdit(c, filterProfanity(p.text.slice(0, 1000))); };
    window.handleDelOwn = (p, conn) => { if (!p || !/^[\w-]{1,64}$/.test(p.id || '')) return; if (ownsRemote(g('msg-' + p.id), conn)) handleDeleteMsgPacket({ msgId: p.id }); };

    /* ── تنسيق النص: *غامق* `كود` ~مشطوب~ ||مخفي|| ── */
    const FMT = /(\|\|[^|\n]{1,200}\|\||\*[^*\n]{1,200}\*|`[^`\n]{1,200}`|~[^~\n]{1,200}~)/;
    function format(body) {
        [...body.childNodes].forEach(n => {
            if (n.nodeType !== 3 || !FMT.test(n.nodeValue)) return;
            const frag = document.createDocumentFragment();
            n.nodeValue.split(FMT).forEach((part, i) => {
                if (!(i % 2)) { if (part) frag.appendChild(document.createTextNode(part)); return; }
                if (part.startsWith('||')) { const s = el('span', 'hx-spoiler', part.slice(2, -2)); s.onclick = (e) => { e.stopPropagation(); s.classList.toggle('open'); }; frag.appendChild(s); }
                else frag.appendChild(el(part[0] === '*' ? 'b' : part[0] === '`' ? 'code' : 's', part[0] === '`' ? 'hx-code' : '', part.slice(1, -1)));
            });
            body.replaceChild(frag, n);
        });
    }
    function decorate(card) {
        if (!card.classList || !card.classList.contains('msg-card') || card.dataset.hxf) return;
        card.dataset.hxf = '1';
        const sender = senderOf(card); if (muted.has(sender)) { card.style.display = 'none'; return; }
        const body = card.querySelector('.msg-body'); if (!body) return;
        format(body);
        if (currentUser && sender === currentUser.username && !card.querySelector('.hx-own-btn') && card.id && !card.id.startsWith('msg-r_')) {
            const hdr = card.firstElementChild; if (!hdr) return;
            if (!body.querySelector('img,audio,video')) { const e = el('button', 'hx-own-btn', '✎'); e.type = 'button'; e.title = 'تعديل'; e.onclick = (ev) => { ev.stopPropagation(); editMine(card); }; hdr.appendChild(e); }
            const d = el('button', 'hx-own-btn', '🗑'); d.type = 'button'; d.title = 'حذف'; d.onclick = (ev) => { ev.stopPropagation(); deleteMine(card); }; hdr.appendChild(d);
        }
    }

    /* ── تغليف الإرسال: اختصارات + أوامر ترفيه + /burn ── */
    const _prev = sendBroadcastMessage;
    sendBroadcastMessage = function () {
        const i = g('msg-input'); if (!i || !currentUser) return _prev();
        i.value = i.value.replace(/:([a-z]{2,10}):/g, (m, k) => SHORT[k] || m);
        const raw = i.value.trim(), cmd = raw.split(/\s+/)[0].toLowerCase(), arg = raw.slice(cmd.length).trim();
        let burn = 0;
        if (cmd === '/8ball') i.value = '🎱 «' + (arg || '؟') + '» ← ' + pick(BALL);
        else if (cmd === '/truth') i.value = '🕯️ سؤال صراحة: ' + pick(TRUTH);
        else if (cmd === '/dare') i.value = '😈 تحدّي: ' + pick(DARE);
        else if (cmd === '/scary') i.value = '🩸 ' + pick(SCARY);
        else if (cmd === '/burn') {
            const m = arg.match(/^(\d{1,3})\s+([\s\S]+)/); if (!m) { appendSystemMessage('الصيغة: /burn 30 نص الرسالة (بالثواني)'); i.value = ''; return; }
            burn = Math.min(300, Math.max(5, +m[1])); i.value = '🔥⏳ ' + m[2];
        }
        const before = g('chat-box') && g('chat-box').lastElementChild;
        _prev();
        if (burn) setTimeout(() => {
            const c = g('chat-box').lastElementChild; if (!c || c === before || senderOf(c) !== currentUser.username) return;
            const id = c.id.slice(4); setTimeout(() => { handleDeleteMsgPacket({ msgId: id }); dbDeleteMsg(id); broadcastPacket({ type: 'del_own', payload: { id } }); }, burn * 1000);
        }, 60);
    };

    /* ── القوائم ── */
    function sheet(title, build) {
        const old = g('hx-sheet'); if (old) old.remove();
        const w = el('div', 'hx-sheet'); w.id = 'hx-sheet'; const box = el('div', 'hx-sheet-box'); const head = el('div', 'hx-sheet-head'); head.appendChild(el('b', '', title));
        const x = el('button', 'hx-x', '✕'); x.onclick = () => w.remove(); head.appendChild(x); box.appendChild(head); build(box); w.appendChild(box);
        w.addEventListener('click', (e) => { if (e.target === w) w.remove(); }); document.body.appendChild(w);
    }
    const btn = (b, label, fn) => { const x = el('button', 'hx-btn', label); x.onclick = fn; b.appendChild(x); };
    function menuThemes() {
        sheet('🎨 المظهر', (b) => { const r = el('div', 'hx-chips');
            [['دم', '#b91c1c'], ['سمّ', '#16a34a'], ['جليد', '#0ea5e9'], ['بنفسجي', '#9333ea'], ['ذهبي', '#ca8a04'], ['وردي', '#db2777']].forEach(([n, c]) => { const x = el('button', 'hx-chip', n); x.style.borderColor = c; x.onclick = () => { ls.set('hx_accent', c); document.documentElement.style.setProperty('--hx-accent', c); }; r.appendChild(x); });
            b.appendChild(r); });
    }
    function menuMute() {
        sheet('🔇 كتم المتصلين', (b) => {
            const names = [...new Set(Object.keys(peerNames).filter(p => activeConnections[p]).map(p => peerNames[p]).concat([...muted]))];
            if (!names.length) b.appendChild(el('p', 'hx-muted', 'لا يوجد متصلون حالياً.'));
            names.forEach(n => { const r = el('div', 'hx-row'); r.appendChild(el('span', '', '👤 ' + n)); const t = el('button', 'hx-chip', muted.has(n) ? 'إلغاء الكتم' : 'كتم');
                t.onclick = () => { if (muted.has(n)) muted.delete(n); else muted.add(n); ls.set('hx_muted', JSON.stringify([...muted])); document.querySelectorAll('#chat-box .msg-card').forEach(c => { if (senderOf(c) === n) c.style.display = muted.has(n) ? 'none' : ''; }); menuMute(); };
                r.appendChild(t); b.appendChild(r); });
            b.appendChild(el('p', 'hx-muted', 'الكتم عندك فقط ولا يعلم به أحد.'));
        });
    }
    function menuStats() {
        sheet('📈 إحصائيات المحادثة', (b) => {
            const cards = [...document.querySelectorAll('#chat-box .msg-card')], per = {}; let words = 0, media = 0;
            cards.forEach(c => { const s = senderOf(c) || '؟'; per[s] = (per[s] || 0) + 1; const t = c.querySelector('.msg-body'); if (t) words += t.textContent.trim().split(/\s+/).filter(Boolean).length; if (c.querySelector('img.attachment-image,audio,video')) media++; });
            const row = (a, v) => { const r = el('div', 'hx-row'); r.appendChild(el('span', '', a)); r.appendChild(el('b', '', String(v))); b.appendChild(r); };
            row('عدد الرسائل', cards.length); row('عدد الكلمات', words); row('المرفقات', media);
            Object.entries(per).sort((x, y) => y[1] - x[1]).slice(0, 5).forEach(([n, v], i) => row((['🥇', '🥈', '🥉', '4️⃣', '5️⃣'][i]) + ' ' + n, v));
        });
    }
    function menuHelp() {
        sheet('❓ التنسيق والأوامر', (b) => ['*نص* ← غامق', '`نص` ← كود', '~نص~ ← مشطوب', '||نص|| ← مخفي (اضغط لإظهاره)', ':skull: :ghost: :fire: ← إيموجي سريع', '/burn 30 نص ← رسالة تختفي بعد 30 ثانية', '/8ball سؤال ← كرة الأرواح', '/truth و /dare ← صراحة وتحدّي', '/scary ← جملة رعب عشوائية', '/poll سؤال | أ | ب ← استطلاع', 'السهم ↑ في الخانة الفارغة ← تعديل آخر رسالة لك', 'Esc ← إغلاق القوائم'].forEach(t => b.appendChild(el('div', 'hx-row', t))));
    }
    function openMenu() { sheet('🧰 أدوات إضافية', (b) => { btn(b, '🎨 المظهر', menuThemes); btn(b, '🔇 كتم المتصلين', menuMute); btn(b, '📈 إحصائيات المحادثة', menuStats); btn(b, '❓ التنسيق والأوامر', menuHelp); }); }

    function init() {
        const bar = g('hx-bar'), box = g('chat-box'), inp = g('msg-input');
        if (!bar || !box || !inp) return setTimeout(init, 300);
        const m = el('button', 'hx-tb', '🧰'); m.type = 'button'; m.title = 'أدوات إضافية'; m.onclick = (e) => { e.stopPropagation(); if (currentUser) openMenu(); };
        bar.insertBefore(m, g('hx-typing'));
        new MutationObserver((ms) => ms.forEach(r => r.addedNodes.forEach(decorate))).observe(box, { childList: true });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') { const s = g('hx-sheet'); if (s) s.remove(); }
            if (e.key === 'ArrowUp' && document.activeElement === inp && !inp.value) { const mine = [...box.querySelectorAll('.msg-card')].reverse().find(c => senderOf(c) === currentUser.username && c.querySelector('.hx-own-btn[title="تعديل"]')); if (mine) { e.preventDefault(); editMine(mine); } }
        });
        window.addEventListener('offline', () => showLiveUpdate('📴 انقطع الإنترنت — سنعيد الاتصال تلقائياً'));
        window.addEventListener('online', () => { showLiveUpdate('📶 عاد الإنترنت'); try { if (peer && peer.disconnected && !peer.destroyed) peer.reconnect(); } catch (e) {} });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();


/* ══════════════════════════════════════════════════════════════
   § v10 — صيانة: الأزرار، الهنج، الشريط الجانبي، خانة المعرّف
══════════════════════════════════════════════════════════════ */
(function () {
    const g = (id) => document.getElementById(id);
    const note = (t) => { try { showLiveUpdate(t); } catch (e) { console.log(t); } };

    /* شاشة البداية لا تنتظر تحميل كل الموارد الخارجية أبداً */
    const killSplash = () => { try { dismissSplash(); } catch (e) {} const s = g('splash-screen'); if (s) s.remove(); };
    setTimeout(killSplash, 4500);
    document.addEventListener('DOMContentLoaded', () => setTimeout(() => { try { dismissSplash(); } catch (e) {} }, 2600));

    /* أخطاء غير متوقعة لا تُجمّد الواجهة بصمت */
    let errShown = 0;
    window.addEventListener('error', (e) => { console.warn('runtime error:', e.message); if (errShown++ < 3) note('⚠️ حدث خطأ بسيط، حاول مرة أخرى.'); });
    window.addEventListener('unhandledrejection', (e) => { console.warn('promise error:', e.reason); });

    /* منع الضغط المزدوج السريع على الأزرار (يسبب تكرار الإرسال والتعليق) */
    const last = new WeakMap();
    document.addEventListener('click', (e) => {
        const b = e.target.closest && e.target.closest('button[onclick], button[id]');
        if (!b || b.id === 'mobile-sidebar-btn') return;
        const now = Date.now(); if (now - (last.get(b) || 0) < 280) { e.stopImmediatePropagation(); e.preventDefault(); return; }
        last.set(b, now);
    }, true);

    /* زر «نسخ» و«ربط الاتصال» مستقلان عن جاهزية PeerJS */
    function parseId(v) { v = String(v || '').trim(); const m = v.match(/join=([^&\s]+)/); if (m) v = decodeURIComponent(m[1]); return v.replace(/[^\w-]/g, '').slice(0, 64); }
    function doConnect() {
        const inp = g('remote-peer-id'), id = parseId(inp && inp.value);
        if (!id) { note('⚠️ اكتب معرّف صديقك أولاً'); if (inp) inp.focus(); return; }
        if (!peer || !peer.open) { note('⏳ جاري تجهيز اتصالك... انتظر ثوانٍ ثم أعد المحاولة'); return; }
        if (id === peer.id) { note('⚠️ هذا معرّفك أنت'); return; }
        connectToPeer(id); note('🔌 جاري الاتصال...'); if (typeof closeMobileSidebar === 'function') closeMobileSidebar();
    }
    async function doCopy() {
        const id = (g('my-peer-id') || {}).textContent || '';
        if (!peer || !peer.id) { note('⏳ المعرّف لم يجهز بعد'); return; }
        try { await navigator.clipboard.writeText(peer.id); note('✅ تم نسخ المعرّف'); }
        catch (e) { const r = document.createRange(); r.selectNodeContents(g('my-peer-id')); const s = getSelection(); s.removeAllRanges(); s.addRange(r); try { document.execCommand('copy'); note('✅ تم نسخ المعرّف'); } catch (x) { prompt('انسخ معرّفك:', peer.id); } }
    }

    /* إعادة محاولة الاتصال إن تأخر المعرّف */
    let retries = 0;
    function watchdog() {
        const el = g('my-peer-id'); if (!el) return;
        if (peer && peer.id) return;
        if (retries++ < 3 && currentUser) { note('🔄 إعادة محاولة تجهيز الاتصال...'); try { if (peer) peer.destroy(); } catch (e) {} try { initPeer(); } catch (e) {} }
        else if (retries > 3) el.textContent = 'تعذر الاتصال بالخادم — تحقق من الإنترنت ثم حدّث الصفحة';
        setTimeout(watchdog, 12000);
    }

    function openDrawerToId() {
        const a = g('app-sidebar'); if (!a) return;
        if (!a.classList.contains('mobile-sidebar-open')) toggleMobileSidebar();
        setTimeout(() => { const t = g('remote-peer-id') || g('my-peer-id'); if (t) t.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 320);
    }

    function init() {
        const cb = g('connect-btn'), cp = g('copy-btn'), inp = g('remote-peer-id');
        if (cb) cb.addEventListener('click', doConnect);
        if (cp) cp.addEventListener('click', doCopy);
        if (inp) inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doConnect(); } });
        const me = g('my-peer-id'); if (me) me.addEventListener('click', doCopy);

        /* زر عائم للوصول السريع لخانة المعرّف على الهاتف */
        if (!g('hx-id-fab')) { const f = document.createElement('button'); f.id = 'hx-id-fab'; f.type = 'button'; f.textContent = '🆔 معرّفي / اتصال'; f.onclick = openDrawerToId; document.body.appendChild(f); }
        setInterval(() => { const f = g('hx-id-fab'), main = g('chat-main-area') || g('app-sidebar'); const inApp = currentUser && !document.querySelector('#login-screen:not(.hidden)'); if (f) f.classList.toggle('show', !!inApp); }, 1500);

        /* السحب من حافة الشاشة لفتح/إغلاق القائمة */
        let sx = 0, sy = 0, tracking = false;
        document.addEventListener('touchstart', (e) => { const t = e.touches[0]; sx = t.clientX; sy = t.clientY; tracking = true; }, { passive: true });
        document.addEventListener('touchend', (e) => {
            if (!tracking) return; tracking = false; const t = e.changedTouches[0], dx = t.clientX - sx, dy = Math.abs(t.clientY - sy);
            const a = g('app-sidebar'); if (!a || innerWidth > 768 || dy > 60) return;
            const open = a.classList.contains('mobile-sidebar-open');
            if (!open && dx < -60 && sx > innerWidth - 28) toggleMobileSidebar();
            else if (open && dx > 60) closeMobileSidebar();
        }, { passive: true });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && typeof closeMobileSidebar === 'function') closeMobileSidebar(); });
        window.addEventListener('resize', () => { if (innerWidth > 768) closeMobileSidebar(); });
        setTimeout(watchdog, 15000);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
