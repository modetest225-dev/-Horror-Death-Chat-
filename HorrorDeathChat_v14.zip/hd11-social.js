/* ============================================================
   HD Chat v11 — البروفايل والستوري (يظهران للمتصلين فقط، عبر القناة المشفّرة)
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, iconBtn, sheet, section, row, toggle, select, button } = HD;

    const STATUS = { online: ['متصل', '#22c55e'], busy: ['مشغول', '#ef4444'], away: ['غائب', '#eab308'], ghost: ['شبح (غير متاح)', '#78716c'] };
    const BGS = ['linear-gradient(135deg,#450a0a,#7f1d1d)', 'linear-gradient(135deg,#0c0a09,#44403c)', 'linear-gradient(135deg,#1e1b4b,#4c1d95)', 'linear-gradient(135deg,#022c22,#14532d)', 'linear-gradient(135deg,#0c4a6e,#082f49)', 'linear-gradient(135deg,#431407,#9a3412)', 'linear-gradient(135deg,#500724,#9d174d)', 'linear-gradient(135deg,#000,#1c1917)'];
    const DAY = 24 * 3600 * 1000, MAX_STORIES = 10;
    const IMG_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
    const HEX_RE = /^#[0-9a-fA-F]{6}$/;
    const clip = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f<>]/g, ' ').trim().slice(0, n);
    const jget = (k, d) => { try { const v = JSON.parse(ls.get(k, '')); return v == null ? d : v; } catch (e) { return d; } };
    const rid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
    const nameOf = (pid) => (typeof peerNames !== 'undefined' && peerNames[pid]) || 'مجهول';

    /* ── الحالة ── */
    const me = { prof: Object.assign({ bio: '', mood: '', status: 'online', color: '#b91c1c', av: '' }, jget('hx11_prof', {})), stories: [], viewers: {} };
    const peersData = {}; /* pid → { prof, stories, name } */
    const seen = new Set(jget('hx11_seen', []));
    function loadMine() { me.stories = jget('hx11_stories', []).filter((s) => s && s.ts && Date.now() - s.ts < DAY).slice(-MAX_STORIES); ls.set('hx11_stories', JSON.stringify(me.stories)); }
    function saveProf() { ls.set('hx11_prof', JSON.stringify(me.prof)); }
    function saveStories() { ls.set('hx11_stories', JSON.stringify(me.stories)); }
    function saveSeen() { ls.set('hx11_seen', JSON.stringify([...seen].slice(-300))); }
    function seedAvatar() { if (me.prof.av || typeof currentUser === 'undefined' || !currentUser) return; try { const a = localStorage.getItem('horror_avatar_' + currentUser.username); if (a && IMG_RE.test(a) && a.length < 30000) { me.prof.av = a; saveProf(); } } catch (e) {} }

    /* ── الإرسال المجزّأ (للصور والبروفايل) ── */
    const CH = 8000, KINDS = new Set(['prof', 'story']), pend = {};
    function sendBig(conn, kind, obj) {
        const str = JSON.stringify(obj), id = rid(), n = Math.max(1, Math.ceil(str.length / CH));
        for (let i = 0; i < n; i++) sendPacket(conn, { type: 'big', payload: { k: kind, id, i, n, d: str.slice(i * CH, (i + 1) * CH) } });
    }
    function sendAll(kind, obj) { Object.keys(activeConnections).forEach((pid) => { const c = activeConnections[pid]; if (c && c.open && c.__hd && c.__hd.mode !== 'pending') sendBig(c, kind, obj); }); }
    HD.on('big', (p, conn) => {
        if (!p || !KINDS.has(p.k) || typeof p.id !== 'string' || !/^[a-z0-9]{6,20}$/.test(p.id) || typeof p.d !== 'string' || p.d.length > CH + 100) return;
        if (!Number.isInteger(p.n) || !Number.isInteger(p.i) || p.n < 1 || p.n > 24 || p.i < 0 || p.i >= p.n) return;
        const key = conn.peer + ':' + p.id; let e = pend[key];
        if (!e) { if (Object.keys(pend).filter((k) => k.startsWith(conn.peer + ':')).length >= 6) return; e = pend[key] = { k: p.k, n: p.n, parts: {}, size: 0, t: Date.now() }; }
        if (e.n !== p.n || e.parts[p.i] != null) return; e.parts[p.i] = p.d; e.size += p.d.length; if (e.size > 200000) { delete pend[key]; return; }
        if (Object.keys(e.parts).length < e.n) return; delete pend[key];
        let o; try { o = JSON.parse(Array.from({ length: e.n }, (_, i) => e.parts[i]).join('')); } catch (x) { return; }
        if (e.k === 'prof') onProf(o, conn); else if (e.k === 'story') onStory(o, conn);
    });
    setInterval(() => { const now = Date.now(); Object.keys(pend).forEach((k) => { if (now - pend[k].t > 60000) delete pend[k]; }); }, 15000);

    /* ── استقبال ── */
    function pdata(pid) { return peersData[pid] || (peersData[pid] = { prof: {}, stories: [], name: nameOf(pid) }); }
    function onProf(o, conn) {
        if (!o || typeof o !== 'object') return;
        const p = (HD.prof && HD.prof.clean) ? HD.prof.clean(o) : {
            bio: clip(o.bio, 100), mood: clip(o.mood, 30), status: STATUS[o.status] ? o.status : 'online',
            color: HEX_RE.test(o.color) ? o.color : '#b91c1c', av: (typeof o.av === 'string' && o.av.length < 40000 && IMG_RE.test(o.av)) ? o.av : ''
        };
        const d = pdata(conn.peer); d.prof = p; d.name = nameOf(conn.peer); refreshAvatars();
    }
    function cleanStory(s) {
        if (!s || typeof s !== 'object' || !/^[a-z0-9]{6,20}$/.test(String(s.id))) return null;
        const kind = s.kind === 'img' ? 'img' : 'text', ts = Number.isFinite(s.ts) ? Math.min(s.ts, Date.now()) : Date.now();
        if (Date.now() - ts > DAY) return null;
        const out = { id: String(s.id), kind, text: clip(s.text, 220), bg: Number.isInteger(s.bg) && s.bg >= 0 && s.bg < BGS.length ? s.bg : 0, ts, img: '' };
        if (kind === 'img') { if (typeof s.img === 'string' && s.img.length < 110000 && IMG_RE.test(s.img)) out.img = s.img; else return null; }
        return out;
    }
    function onStory(o, conn) {
        if (!o || typeof o !== 'object') return; const d = pdata(conn.peer);
        if (o.op === 'sync' && Array.isArray(o.list)) { d.stories = o.list.slice(0, MAX_STORIES).map(cleanStory).filter(Boolean); }
        else if (o.op === 'add') { const s = cleanStory(o.s); if (s && !d.stories.some((x) => x.id === s.id)) { d.stories.push(s); d.stories = d.stories.slice(-MAX_STORIES); note(nameOf(conn.peer) + ' أضاف ستوري جديداً'); } }
        else if (o.op === 'del' && typeof o.id === 'string') { d.stories = d.stories.filter((x) => x.id !== o.id); }
        updateBadge(); if (g('hx11-people')) renderPeople(g('hx11-people'));
    }
    HD.on('story_view', (p, conn) => {
        if (!p || typeof p.id !== 'string' || !me.stories.some((s) => s.id === p.id)) return;
        (me.viewers[p.id] = me.viewers[p.id] || new Set()).add(nameOf(conn.peer));
    });

    /* ── مزامنة عند اتصال جديد + تنظيف المنقطعين ── */
    function mineStoriesPayload() { return me.stories.map((s) => ({ id: s.id, kind: s.kind, text: s.text, bg: s.bg, ts: s.ts, img: s.img })); }
    function tick() {
        loadMineFilter();
        Object.keys(activeConnections).forEach((pid) => {
            const c = activeConnections[pid]; if (!c || !c.open || !c.__hd || c.__hd.mode === 'pending' || c.__hd.socialSent) return;
            c.__hd.socialSent = true; seedAvatar(); sendBig(c, 'prof', me.prof); if (me.stories.length) sendBig(c, 'story', { op: 'sync', list: mineStoriesPayload() });
        });
        Object.keys(peersData).forEach((pid) => { if (!activeConnections[pid]) delete peersData[pid]; });
        Object.keys(peersData).forEach((pid) => { peersData[pid].name = nameOf(pid); });
        updateBadge();
    }
    function loadMineFilter() { const n = me.stories.length; me.stories = me.stories.filter((s) => Date.now() - s.ts < DAY); if (me.stories.length !== n) saveStories(); }

    /* ── عناصر الواجهة ── */
    function unseenCount(pid) { const d = peersData[pid]; return d ? d.stories.filter((s) => !seen.has(s.id)).length : 0; }
    function totalUnseen() { return Object.keys(peersData).reduce((a, p) => a + unseenCount(p), 0); }
    function avatar(prof, name, size, opts) {
        opts = opts || {}; const w = el('div', 'hx11-avw' + (opts.ring ? ' ring' + (opts.ring === 'seen' ? ' seen' : '') : '')); w.style.setProperty('--sz', (size || 44) + 'px'); if (prof && prof.color) w.style.setProperty('--rc', prof.color);
        if (prof && prof.frame) { w.classList.add('fr' + (prof.frame | 0)); if (prof.color2) w.style.setProperty('--rc2', prof.color2); }
        const a = el('div', 'hx11-avc'); if (prof && prof.av) { const im = el('img'); im.src = prof.av; im.alt = ''; a.appendChild(im); } else { a.textContent = (name || '؟').trim().slice(0, 1); if (prof && prof.color) a.style.background = prof.color; }
        w.appendChild(a); if (opts.status && prof && STATUS[prof.status]) { const d = el('i', 'hx11-sd'); d.style.background = STATUS[prof.status][1]; w.appendChild(d); } return w;
    }
    function refreshAvatars() {
        const box = g('chat-box'); if (!box) return;
        box.querySelectorAll('.msg-card [data-sender]').forEach((s) => {
            const n = s.dataset.sender, img = s.querySelector('img'); if (!img) return;
            let prof = null; if (currentUser && n === currentUser.username) prof = me.prof; else { const pid = Object.keys(peersData).find((p) => peersData[p].name === n); if (pid) prof = peersData[pid].prof; }
            if (prof && prof.av && img.dataset.hxav !== prof.av.slice(-24)) { img.src = prof.av; img.dataset.hxav = prof.av.slice(-24); img.style.objectFit = 'cover'; }
        });
    }
    function updateBadge() { const b = g('hx11-story-badge'); if (!b) return; const n = totalUnseen(); b.textContent = n ? String(n) : ''; }

    /* ── بروفايلي ── */
    function compress(file, max, limit, cb, rounds) {
        const rd = new FileReader(); rd.onerror = () => cb(null); rd.onload = () => {
            const im = new Image(); im.onerror = () => cb(null); im.onload = () => {
                const sc = Math.min(1, max / Math.max(im.width, im.height)), w = Math.max(1, Math.round(im.width * sc)), h = Math.max(1, Math.round(im.height * sc));
                const cv = document.createElement('canvas'); cv.width = w; cv.height = h; cv.getContext('2d').drawImage(im, 0, 0, w, h);
                let q = 0.82, out = cv.toDataURL('image/jpeg', q); while (out.length > limit && q > 0.3) { q -= 0.1; out = cv.toDataURL('image/jpeg', q); }
                cb(out.length <= limit ? out : null);
            }; im.src = rd.result;
        }; rd.readAsDataURL(file);
    }
    function squareAvatar(file, cb) {
        const rd = new FileReader(); rd.onerror = () => cb(null); rd.onload = () => {
            const im = new Image(); im.onerror = () => cb(null); im.onload = () => {
                const S = 128, cv = document.createElement('canvas'), m = Math.min(im.width, im.height); cv.width = cv.height = S; cv.getContext('2d').drawImage(im, (im.width - m) / 2, (im.height - m) / 2, m, m, 0, 0, S, S);
                let q = 0.8, out = cv.toDataURL('image/jpeg', q); while (out.length > 14000 && q > 0.3) { q -= 0.1; out = cv.toDataURL('image/jpeg', q); } cb(out.length <= 30000 ? out : null);
            }; im.src = rd.result;
        }; rd.readAsDataURL(file);
    }
    function openMyProfile() {
        if (!currentUser) return; seedAvatar();
        sheet('بروفايلي', (b) => {
            const head = el('div', 'hx11-prof-head'); const avBox = el('div'); const draw = () => { avBox.textContent = ''; avBox.appendChild(avatar(me.prof, currentUser.username, 84, { status: true })); }; draw();
            const side = el('div', 'hx11-prof-side'); side.appendChild(el('b', '', currentUser.username)); side.appendChild(el('small', 'hx-muted', 'يراه المتصلون معك فقط'));
            const file = el('input'); file.type = 'file'; file.accept = 'image/*'; file.style.display = 'none';
            file.onchange = () => { const f = file.files[0]; file.value = ''; if (!f) return; squareAvatar(f, (d) => { if (!d) { note('تعذّر تجهيز الصورة'); return; } me.prof.av = d; try { localStorage.setItem('horror_avatar_' + currentUser.username, d); } catch (e) {} draw(); }); };
            const pick = el('button', 'hx11-chipbtn', 'تغيير الصورة'); pick.type = 'button'; pick.onclick = () => file.click();
            const rm = el('button', 'hx11-chipbtn', 'إزالة'); rm.type = 'button'; rm.onclick = () => { me.prof.av = ''; draw(); };
            const act = el('div', 'hx11-inline'); act.appendChild(pick); act.appendChild(rm); side.appendChild(act); head.appendChild(avBox); head.appendChild(side); b.appendChild(head); b.appendChild(file);
            section(b, 'الحالة'); row(b, 'حالتي', select(Object.entries(STATUS).map(([k, v]) => [k, v[0]]), me.prof.status, (v) => { me.prof.status = v; draw(); }));
            const mood = el('input', 'hx-input'); mood.maxLength = 30; mood.placeholder = 'مزاجي الآن (مثال: أحدّق في الظلام)'; mood.value = me.prof.mood; mood.oninput = () => { me.prof.mood = clip(mood.value, 30); }; b.appendChild(mood);
            section(b, 'نبذة عني'); const bio = el('textarea', 'hx-input hx11-ta'); bio.rows = 3; bio.maxLength = 100; bio.placeholder = 'اكتب نبذة قصيرة (100 حرف)'; bio.value = me.prof.bio; bio.oninput = () => { me.prof.bio = clip(bio.value, 100); }; b.appendChild(bio);
            const cl = el('input'); cl.type = 'color'; cl.className = 'hx11-colorin'; cl.value = me.prof.color; cl.oninput = () => { me.prof.color = cl.value; draw(); }; row(b, 'لوني المميز', cl, 'يظهر حول صورتك في ستورياتك.');
            button(b, 'حفظ ونشر للمتصلين', () => { saveProf(); sendAll('prof', me.prof); refreshAvatars(); const w = g('hx-sheet'); if (w) w.remove(); note('تم تحديث بروفايلك'); }, 'check');
        });
    }

    /* ── بروفايل شخص آخر ── */
    function openPeerProfile(pid) {
        const d = peersData[pid], name = nameOf(pid); if (!activeConnections[pid]) { note('هذا المستخدم غير متصل الآن'); return; }
        const prof = d ? d.prof : {};
        sheet(name, (b) => {
            const head = el('div', 'hx11-prof-head'); head.appendChild(avatar(prof, name, 84, { status: true, ring: d && d.stories.length ? (unseenCount(pid) ? 'new' : 'seen') : null }));
            const side = el('div', 'hx11-prof-side'); side.appendChild(el('b', '', name));
            side.appendChild(el('small', 'hx-muted', STATUS[prof.status] ? STATUS[prof.status][0] : 'متصل')); if (prof.mood) side.appendChild(el('small', '', prof.mood)); head.appendChild(side); b.appendChild(head);
            if (prof.bio) { section(b, 'نبذة'); b.appendChild(el('p', 'hx11-bio', prof.bio)); } else b.appendChild(el('p', 'hx-muted', 'لم يكتب نبذة بعد.'));
            if (d && d.stories.length) button(b, 'مشاهدة الستوري (' + d.stories.length + ')', () => { const w = g('hx-sheet'); if (w) w.remove(); openStories(pid); }, 'spot');
            button(b, 'رسالة خاصة', () => { const w = g('hx-sheet'); if (w) w.remove(); try { openPrivateChatWith(name); } catch (e) {} }, 'send');
            button(b, 'إشارة @' + name, () => { const w = g('hx-sheet'); if (w) w.remove(); const i = g('msg-input'); i.value += (i.value && !/\s$/.test(i.value) ? ' ' : '') + '@' + name + ' '; i.focus(); }, 'users');
            button(b, 'مكالمة فيديو', () => { const w = g('hx-sheet'); if (w) w.remove(); HD.call.start('video', [pid]); }, 'video');
            button(b, 'مكالمة صوتية', () => { const w = g('hx-sheet'); if (w) w.remove(); HD.call.start('audio', [pid]); }, 'phone');
        });
    }

    /* ── الستوري: إنشاء ── */
    function openStoryCreate() {
        if (!currentUser) return;
        sheet('ستوري جديد', (b) => {
            let kind = 'text', bg = 0, img = '';
            const tabs = el('div', 'hx11-tabs'); const tT = el('button', 'on', 'نص'), tI = el('button', '', 'صورة'); [tT, tI].forEach((x) => { x.type = 'button'; tabs.appendChild(x); }); b.appendChild(tabs);
            const prev = el('div', 'hx11-story-prev'); const txt = el('textarea', 'hx11-story-txt'); txt.maxLength = 220; txt.placeholder = 'اكتب ما يدور في ظلامك...'; prev.appendChild(txt);
            const im = el('img', 'hx11-story-img'); im.alt = ''; im.style.display = 'none'; prev.appendChild(im); b.appendChild(prev);
            const sw = el('div', 'hx11-accs'); BGS.forEach((c, i) => { const x = el('button', 'hx11-acc' + (i === 0 ? ' on' : '')); x.type = 'button'; x.style.background = c; x.setAttribute('aria-label', 'خلفية ' + (i + 1)); x.onclick = () => { bg = i; prev.style.background = c; sw.querySelectorAll('.hx11-acc').forEach((y) => y.classList.remove('on')); x.classList.add('on'); }; sw.appendChild(x); }); b.appendChild(sw); prev.style.background = BGS[0];
            const file = el('input'); file.type = 'file'; file.accept = 'image/*'; file.style.display = 'none';
            const pick = button(b, 'اختيار صورة', () => file.click(), 'plus'); pick.style.display = 'none';
            file.onchange = () => { const f = file.files[0]; file.value = ''; if (!f) return; compress(f, 720, 95000, (d) => { if (!d) { note('الصورة كبيرة جداً أو غير مدعومة'); return; } img = d; im.src = d; im.style.display = ''; txt.placeholder = 'تعليق (اختياري)'; }); }; b.appendChild(file);
            const setKind = (k) => { kind = k; tT.classList.toggle('on', k === 'text'); tI.classList.toggle('on', k === 'img'); pick.style.display = k === 'img' ? '' : 'none'; im.style.display = k === 'img' && img ? '' : 'none'; txt.placeholder = k === 'img' ? 'تعليق (اختياري)' : 'اكتب ما يدور في ظلامك...'; };
            tT.onclick = () => setKind('text'); tI.onclick = () => setKind('img');
            b.appendChild(el('p', 'hx-muted', 'يختفي الستوري بعد 24 ساعة، ويراه من يكون متصلاً معك فقط.'));
            button(b, 'نشر الستوري', () => {
                const t = clip(txt.value, 220); if (kind === 'text' && !t) { note('اكتب نصاً أولاً'); return; } if (kind === 'img' && !img) { note('اختر صورة أولاً'); return; }
                const s = { id: rid(), kind, text: t, bg, ts: Date.now(), img: kind === 'img' ? img : '' };
                me.stories.push(s); me.stories = me.stories.slice(-MAX_STORIES); saveStories(); sendAll('story', { op: 'add', s });
                const w = g('hx-sheet'); if (w) w.remove(); note('تم نشر الستوري'); if (g('hx11-people')) renderPeople(g('hx11-people'));
            }, 'send');
        });
    }

    /* ── الستوري: العارض ── */
    let viewer = null;
    function closeViewer() { if (!viewer) return; clearInterval(viewer.iv); viewer.root.remove(); document.removeEventListener('keydown', viewer.kh); viewer = null; if (g('hx11-people')) renderPeople(g('hx11-people')); updateBadge(); }
    function openStories(who) {
        const mine = who === 'me', d = mine ? { prof: me.prof, stories: me.stories, name: currentUser.username } : peersData[who];
        if (!d || !d.stories.length) { note(mine ? 'لا توجد ستوريات لديك' : 'لا توجد ستوريات'); return; }
        closeViewer(); const list = d.stories.slice(); let idx = Math.max(0, list.findIndex((s) => !seen.has(s.id))); if (mine) idx = 0;
        const root = el('div', 'hx11-sv'); root.setAttribute('role', 'dialog'); root.setAttribute('aria-label', 'ستوري ' + d.name);
        const bars = el('div', 'hx11-sv-bars'); list.forEach(() => { const x = el('i'); x.appendChild(el('u')); bars.appendChild(x); });
        const top = el('div', 'hx11-sv-top'); top.appendChild(avatar(d.prof, d.name, 34)); const info = el('div', 'hx11-sv-info'); info.appendChild(el('b', '', mine ? 'ستوريك' : d.name)); const when = el('small', ''); info.appendChild(when); top.appendChild(info);
        const close = iconBtn('x', 'إغلاق', closeViewer, 'sm'); top.appendChild(close);
        const stage = el('div', 'hx11-sv-stage'); const foot = el('div', 'hx11-sv-foot'); const prevB = el('button', 'hx11-sv-nav prev'), nextB = el('button', 'hx11-sv-nav next'); [prevB, nextB].forEach((x) => { x.type = 'button'; });
        prevB.setAttribute('aria-label', 'السابق'); nextB.setAttribute('aria-label', 'التالي');
        root.appendChild(bars); root.appendChild(top); root.appendChild(stage); root.appendChild(foot); root.appendChild(prevB); root.appendChild(nextB); document.body.appendChild(root);
        let t0 = 0, paused = false; const DUR = 6000;
        const show = (i) => {
            if (i < 0) i = 0; if (i >= list.length) return closeViewer(); idx = i; const s = list[i]; stage.textContent = ''; foot.textContent = '';
            stage.style.background = BGS[s.bg] || BGS[0];
            if (s.kind === 'img' && s.img) { const im = el('img'); im.src = s.img; im.alt = ''; stage.appendChild(im); if (s.text) stage.appendChild(el('div', 'hx11-sv-cap', s.text)); }
            else stage.appendChild(el('div', 'hx11-sv-text', s.text));
            bars.querySelectorAll('i').forEach((x, k) => { x.firstChild.style.width = k < i ? '100%' : '0%'; });
            const mins = Math.max(0, Math.round((Date.now() - s.ts) / 60000)); when.textContent = mins < 1 ? 'الآن' : mins < 60 ? 'منذ ' + mins + ' د' : 'منذ ' + Math.floor(mins / 60) + ' س';
            if (!mine) { if (!seen.has(s.id)) { seen.add(s.id); saveSeen(); const c = activeConnections[who]; if (c) sendPacket(c, { type: 'story_view', payload: { id: s.id } }); } }
            else { const v = me.viewers[s.id] ? [...me.viewers[s.id]] : []; const vb = el('div', 'hx11-sv-views', 'شاهده: ' + (v.length ? v.slice(0, 6).join('، ') + (v.length > 6 ? ' +' + (v.length - 6) : '') : 'لا أحد بعد')); foot.appendChild(vb);
                const del = el('button', 'hx11-chipbtn', 'حذف هذا الستوري'); del.type = 'button'; del.onclick = () => { me.stories = me.stories.filter((x) => x.id !== s.id); saveStories(); sendAll('story', { op: 'del', id: s.id }); closeViewer(); }; foot.appendChild(del); }
            t0 = Date.now();
        };
        prevB.onclick = () => show(idx - 1); nextB.onclick = () => show(idx + 1);
        ['pointerdown'].forEach((e) => stage.addEventListener(e, () => { paused = true; })); ['pointerup', 'pointerleave', 'pointercancel'].forEach((e) => stage.addEventListener(e, () => { paused = false; t0 = Date.now() - (parseFloat(bars.children[idx].firstChild.style.width) || 0) / 100 * DUR; }));
        const iv = setInterval(() => { if (paused) return; const p = Math.min(1, (Date.now() - t0) / DUR); const bar = bars.children[idx]; if (bar) bar.firstChild.style.width = (p * 100) + '%'; if (p >= 1) show(idx + 1); }, 80);
        const kh = (e) => { if (e.key === 'Escape') closeViewer(); else if (e.key === 'ArrowLeft') show(idx + 1); else if (e.key === 'ArrowRight') show(idx - 1); }; document.addEventListener('keydown', kh);
        viewer = { root, iv, kh }; show(idx);
    }

    /* ── قائمة الأشخاص (تُعرض داخل المركز) ── */
    function renderPeople(box) {
        box.textContent = ''; const strip = el('div', 'hx11-strip-st');
        const mk = (label, prof, ring, onclick, plus) => { const it = el('button', 'hx11-st'); it.type = 'button'; const a = avatar(prof, label, 52, { ring }); if (plus) { const p = el('i', 'hx11-plus'); p.appendChild(icon('plus', 12)); a.appendChild(p); } it.appendChild(a); it.appendChild(el('span', '', label)); it.onclick = onclick; return it; };
        strip.appendChild(mk('أنا', me.prof, me.stories.length ? 'seen' : null, () => { if (me.stories.length) openStories('me'); else openStoryCreate(); }, !me.stories.length));
        Object.keys(peersData).filter((p) => activeConnections[p] && peersData[p].stories.length).forEach((pid) => { const d = peersData[pid]; strip.appendChild(mk(d.name, d.prof, unseenCount(pid) ? 'new' : 'seen', () => openStories(pid))); });
        box.appendChild(strip);
        const acts = el('div', 'hx11-inline'); const a1 = el('button', 'hx11-chipbtn', 'ستوري جديد'); a1.type = 'button'; a1.onclick = openStoryCreate; const a2 = el('button', 'hx11-chipbtn', 'بروفايلي'); a2.type = 'button'; a2.onclick = () => HD.social.openMyProfile(); acts.appendChild(a1); acts.appendChild(a2); box.appendChild(acts);
        section(box, 'المتصلون الآن');
        const ids = Object.keys(activeConnections).filter((p) => activeConnections[p] && activeConnections[p].open);
        const meRow = el('button', 'hx11-person'); meRow.type = 'button'; meRow.appendChild(avatar(me.prof, currentUser.username, 40, { status: true })); const mi = el('div', 'hx11-pi'); mi.appendChild(el('b', '', currentUser.username + ' (أنت)')); mi.appendChild(el('small', '', me.prof.mood || (STATUS[me.prof.status] || STATUS.online)[0])); meRow.appendChild(mi); meRow.onclick = () => HD.social.openMyProfile(); box.appendChild(meRow);
        if (!ids.length) box.appendChild(el('p', 'hx-muted', 'لا أحد متصل معك الآن.'));
        ids.forEach((pid) => { const d = peersData[pid] || { prof: {}, stories: [] }, nm = nameOf(pid); const r = el('button', 'hx11-person'); r.type = 'button'; r.appendChild(avatar(d.prof, nm, 40, { status: true, ring: d.stories.length ? (unseenCount(pid) ? 'new' : 'seen') : null })); const inf = el('div', 'hx11-pi'); inf.appendChild(el('b', '', nm + (verifiedOwnerPeers.has(pid) ? ' 👑' : ''))); inf.appendChild(el('small', '', d.prof.mood || d.prof.bio || (STATUS[d.prof.status] ? STATUS[d.prof.status][0] : 'متصل'))); r.appendChild(inf); r.onclick = () => HD.social.openPeerProfile(pid); box.appendChild(r); });
    }

    function installHeader() {
        const hdr = document.querySelector('#chat-main-area > header .flex.items-center.gap-3'); if (!hdr || g('hx11-story-btn')) return;
        const b = iconBtn('users', 'الأشخاص والستوري', () => HD.hub && HD.hub.open('people'), 'hx11-hdr'); b.id = 'hx11-story-btn'; const bd = el('span', 'hx11-badge-n'); bd.id = 'hx11-story-badge'; b.appendChild(bd); hdr.insertBefore(b, hdr.firstChild);
    }
    function init() { loadMine(); installHeader(); setInterval(tick, 1500); setInterval(refreshAvatars, 3000); const box = g('chat-box'); if (box) new MutationObserver(() => refreshAvatars()).observe(box, { childList: true }); }
    HD.social = { clip, saveProf, unseenCount, STATUS, BGS, compress, squareAvatar, sendAll, sendBig, me, peersData, renderPeople, openMyProfile, openPeerProfile, openStoryCreate, openStories, avatar };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
