/* ============================================================
   HD Chat v11 — المكالمات: صوت / فيديو / مشاركة الشاشة وسطح المكتب
   مكالمات جماعية (شبكة Mesh) عبر PeerJS، مشفّرة DTLS-SRTP من المتصفح.
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, iconBtn, sheet, section, row, toggle, select, button } = HD;

    const Q = { '240': { w: 426, h: 240, f: 15, br: 180000 }, '360': { w: 640, h: 360, f: 24, br: 550000 }, '720': { w: 1280, h: 720, f: 30, br: 1600000 }, '1080': { w: 1920, h: 1080, f: 30, br: 3800000 } };
    const REACTS = ['👍', '❤️', '😂', '😮', '👏', '💀', '🔥', '👻'];
    const FX = [['none', 'بدون مؤثر'], ['horror', 'صوت مرعب'], ['robot', 'روبوت'], ['cave', 'كهف (صدى)'], ['radio', 'راديو قديم']];
    const S = {
        active: false, cid: null, kind: 'video', ctx: null, micStream: null, micSrc: null, fxIn: null, fxOut: null, fxNodes: [], micGain: null, mixDest: null, recDest: null,
        camTrack: null, camOn: false, micOn: true, screenStream: null, sysSrc: null, sysGain: null, blackCv: null, blackTrack: null, blackIv: null, out: null,
        peers: new Map(), expected: new Set(), pending: new Map(), mode: 'grid', focus: null, facing: 'user', devs: { mic: ls.get('hx11_dmic', ''), cam: ls.get('hx11_dcam', ''), spk: ls.get('hx11_dspk', '') },
        quality: ls.get('hx11_q', '720'), fx: ls.get('hx11_fx', 'none'), startedAt: 0, timers: [], ui: null, rec: null, recBy: {}, wake: null, ring: null, ringUi: null, meAn: null, handUp: false
    };
    S.locked = false; S.prof = ls.get('hx11_cprof', 'normal'); S.lastSpeaker = null; S.lastSpkT = 0;
    S.vfx = ls.get('hx11_vfx', 'none'); S.vb = +ls.get('hx11_vb', '100') || 100; S.vc = +ls.get('hx11_vc', '100') || 100; S.vz = +ls.get('hx11_vz', '100') || 100; S.fps = +ls.get('hx11_fps', '0') || 0; S.chat = []; S.unreadChat = 0;
    HD.call = { state: S };
    const FXV = [['none', 'بدون مؤثر'], ['gray', 'أبيض وأسود'], ['sepia', 'قديم (سيبيا)'], ['horror', 'رعب'], ['night', 'رؤية ليلية'], ['vhs', 'كاميرا VHS'], ['invert', 'معكوس الألوان'], ['blur', 'تركيز (تمويه الأطراف)'], ['warm', 'دافئ'], ['cool', 'بارد'], ['privacy', 'تمويه كامل (خصوصية)']];
    const FILT = { none: '', gray: 'grayscale(1)', sepia: 'sepia(.9) contrast(1.05)', horror: 'grayscale(.75) contrast(1.35) brightness(.78) sepia(.35) hue-rotate(-25deg)', night: 'grayscale(1) brightness(1.3) contrast(1.2) sepia(1) hue-rotate(50deg) saturate(3)', vhs: 'saturate(1.4) contrast(1.1) hue-rotate(-6deg)', invert: 'invert(1)', blur: '', warm: 'sepia(.35) saturate(1.3) hue-rotate(-10deg)', cool: 'saturate(1.1) hue-rotate(15deg) brightness(1.05)', privacy: '' };
    const needsFx = () => S.vfx !== 'none' || S.vb !== 100 || S.vc !== 100 || S.vz !== 100;
    const errMsg = (e) => (e && e.name === 'NotAllowedError') ? 'لم تمنح الإذن من المتصفح' : (e && e.name === 'NotFoundError') ? 'الجهاز غير موجود' : (e && e.name === 'NotReadableError') ? 'الجهاز مستخدم من تطبيق آخر' : (e && e.message) || 'خطأ غير معروف';
    const fmtDur = (ms) => { const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
    const nameOf = (pid) => (typeof peerNames !== 'undefined' && peerNames[pid]) || 'مشارك';

    /* ── الأجهزة ── */
    async function getMic() {
        const a = { echoCancellation: ls.get('hx11_ec', '1') === '1', noiseSuppression: ls.get('hx11_ns', '1') === '1', autoGainControl: ls.get('hx11_agc', '1') === '1' };
        if (S.devs.mic) a.deviceId = { ideal: S.devs.mic };
        return navigator.mediaDevices.getUserMedia({ audio: a });
    }
    async function getCam() {
        const q = Q[S.quality] || Q['720'], v = { width: { ideal: q.w }, height: { ideal: q.h }, frameRate: { ideal: S.fps || q.f } };
        if (S.devs.cam) v.deviceId = { ideal: S.devs.cam }; else v.facingMode = S.facing;
        const st = await navigator.mediaDevices.getUserMedia({ video: v }); return st.getVideoTracks()[0];
    }
    function blackTrack() {
        if (S.blackTrack && S.blackTrack.readyState === 'live') return S.blackTrack;
        const cv = document.createElement('canvas'); cv.width = 320; cv.height = 180; S.blackCv = cv; const c = cv.getContext('2d'); let t = 0;
        const draw = () => { c.fillStyle = '#000'; c.fillRect(0, 0, 320, 180); c.fillStyle = (t++ & 1) ? '#050505' : '#000'; c.fillRect(0, 0, 4, 4); };
        draw(); S.blackIv = setInterval(draw, 500); S.timers.push(S.blackIv);
        S.blackTrack = cv.captureStream(2).getVideoTracks()[0]; return S.blackTrack;
    }
    function teardownFx() { if (S.vxIv) clearInterval(S.vxIv); S.vxIv = null; if (S.vxOut) try { S.vxOut.stop(); } catch (e) {} if (S.vxVid) { try { S.vxVid.pause(); S.vxVid.srcObject = null; } catch (e) {} } S.vxOut = S.vxVid = S.vxCv = S.vxCtx = S.vxSrc = null; }
    function drawFx() {
        const v = S.vxVid, cv = S.vxCv, c = S.vxCtx; if (!v || !v.videoWidth) return; if (cv.width !== v.videoWidth || cv.height !== v.videoHeight) { cv.width = v.videoWidth; cv.height = v.videoHeight; }
        const W = cv.width, H = cv.height, z = Math.max(1, S.vz / 100), sw = W / z, sh = H / z, sx = (W - sw) / 2, sy = (H - sh) / 2, base = 'brightness(' + S.vb + '%) contrast(' + S.vc + '%) ' + (FILT[S.vfx] || '');
        const put = () => c.drawImage(v, sx, sy, sw, sh, 0, 0, W, H);
        try { c.filter = base + (S.vfx === 'blur' ? ' blur(10px)' : S.vfx === 'privacy' ? ' blur(26px)' : ''); } catch (e) {} put();
        if (S.vfx === 'blur') { c.save(); try { c.filter = base; } catch (e) {} c.beginPath(); c.ellipse(W / 2, H / 2, W * 0.36, H * 0.44, 0, 0, Math.PI * 2); c.clip(); put(); c.restore(); }
        try { c.filter = 'none'; } catch (e) {}
        if (S.vfx === 'horror') { const gr = c.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, H * 0.85); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.78)'); c.fillStyle = gr; c.fillRect(0, 0, W, H); c.fillStyle = 'rgba(120,0,0,.12)'; c.fillRect(0, 0, W, H); if (Math.random() < 0.06) { c.fillStyle = 'rgba(255,255,255,.1)'; c.fillRect(0, 0, W, H); } }
        else if (S.vfx === 'night') { c.fillStyle = 'rgba(0,255,70,.1)'; c.fillRect(0, 0, W, H); c.fillStyle = 'rgba(0,0,0,.18)'; for (let y = 0; y < H; y += 4) c.fillRect(0, y, W, 1); }
        else if (S.vfx === 'vhs') { c.fillStyle = 'rgba(0,0,0,.2)'; for (let y = 0; y < H; y += 4) c.fillRect(0, y, W, 1); if (Math.random() < 0.05) { const y = Math.random() * H, h = 6 + Math.random() * 18; try { c.drawImage(cv, 0, y, W, h, (Math.random() * 24) - 12, y, W, h); } catch (e) {} } }
    }
    function fxTrack() {
        if (S.vxOut && S.vxSrc === S.camTrack && S.vxOut.readyState === 'live') return S.vxOut;
        teardownFx(); const fps = Math.min(30, S.fps || (Q[S.quality] || Q['720']).f), v = document.createElement('video'); v.muted = true; v.playsInline = true; v.autoplay = true; v.srcObject = new MediaStream([S.camTrack]); v.play().catch(() => {});
        const cv = document.createElement('canvas'); cv.width = 640; cv.height = 360; S.vxVid = v; S.vxCv = cv; S.vxCtx = cv.getContext('2d'); S.vxSrc = S.camTrack;
        S.vxIv = setInterval(drawFx, Math.round(1000 / fps)); S.vxOut = cv.captureStream(fps).getVideoTracks()[0]; return S.vxOut;
    }
    const currentVideoTrack = () => S.screenStream ? S.screenStream.getVideoTracks()[0] : (S.camTrack && S.camOn ? (needsFx() ? fxTrack() : camPlain()) : blackTrack());
    function camPlain() { if (S.vxOut) teardownFx(); return S.camTrack; }
    function applyVfx() { const now = needsFx(); if (now !== S.fxWas) { S.fxWas = now; refreshVideo(); } }

    /* ── الصوت: ميكروفون → مؤثر → كتم → (إرسال + تسجيل) ── */
    function setupAudio(micStream) {
        const AC = window.AudioContext || window.webkitAudioContext; S.ctx = new AC(); if (S.ctx.resume) S.ctx.resume();
        S.fxIn = S.ctx.createGain(); S.fxOut = S.ctx.createGain(); S.micGain = S.ctx.createGain();
        S.mixDest = S.ctx.createMediaStreamDestination(); S.recDest = S.ctx.createMediaStreamDestination();
        S.fxOut.connect(S.micGain); S.micGain.connect(S.mixDest); S.micGain.connect(S.recDest);
        if (micStream) { S.micStream = micStream; S.micSrc = S.ctx.createMediaStreamSource(micStream); S.micSrc.connect(S.fxIn); }
        applyFx(S.fx); S.micGain.gain.value = S.micOn ? 1 : 0;
        S.meAn = analyser(S.fxOut);
    }
    function analyser(node) { const an = S.ctx.createAnalyser(); an.fftSize = 512; node.connect(an); an.buf = new Uint8Array(an.fftSize); return an; }
    function level(an) { if (!an) return 0; an.getByteTimeDomainData(an.buf); let m = 0; for (let i = 0; i < an.buf.length; i++) { const v = Math.abs(an.buf[i] - 128); if (v > m) m = v; } return m / 128; }
    function applyFx(name) {
        const c = S.ctx; if (!c) return; try { S.fxIn.disconnect(); } catch (e) {}
        S.fxNodes.forEach((n) => { try { n.disconnect(); } catch (e) {} try { if (n.stop) n.stop(); } catch (e) {} }); S.fxNodes = [];
        const k = (n) => { S.fxNodes.push(n); return n; };
        if (!name || name === 'none') { S.fxIn.connect(S.fxOut); return; }
        if (name === 'horror') {
            const ws = k(c.createWaveShaper()); if (typeof makeDistortionCurve === 'function') ws.curve = makeDistortionCurve(120); ws.oversample = '2x';
            const pk = k(c.createBiquadFilter()); pk.type = 'peaking'; pk.frequency.value = 200; pk.gain.value = -10;
            const lp = k(c.createBiquadFilter()); lp.type = 'lowpass'; lp.frequency.value = 2400;
            const d = k(c.createDelay(0.6)); d.delayTime.value = 0.28; const fb = k(c.createGain()); fb.gain.value = 0.4; const wet = k(c.createGain()); wet.gain.value = 0.6; const dry = k(c.createGain()); dry.gain.value = 0.5;
            S.fxIn.connect(ws); ws.connect(pk); pk.connect(lp); lp.connect(dry); dry.connect(S.fxOut); lp.connect(d); d.connect(fb); fb.connect(d); d.connect(wet); wet.connect(S.fxOut);
        } else if (name === 'robot') {
            const osc = k(c.createOscillator()); osc.type = 'sine'; osc.frequency.value = 55; const rg = k(c.createGain()); rg.gain.value = 0; osc.connect(rg.gain); osc.start();
            S.fxIn.connect(rg); rg.connect(S.fxOut);
        } else if (name === 'cave') {
            const lp = k(c.createBiquadFilter()); lp.type = 'lowpass'; lp.frequency.value = 3500; const dry = k(c.createGain()); dry.gain.value = 0.8;
            S.fxIn.connect(dry); dry.connect(S.fxOut); S.fxIn.connect(lp);
            [0.11, 0.19, 0.31].forEach((t, i) => { const d = k(c.createDelay(0.6)); d.delayTime.value = t; const gg = k(c.createGain()); gg.gain.value = 0.38 - i * 0.08; lp.connect(d); d.connect(gg); gg.connect(S.fxOut); });
        } else if (name === 'radio') {
            const hp = k(c.createBiquadFilter()); hp.type = 'highpass'; hp.frequency.value = 500; const lp = k(c.createBiquadFilter()); lp.type = 'lowpass'; lp.frequency.value = 3200;
            const ws = k(c.createWaveShaper()); if (typeof makeDistortionCurve === 'function') ws.curve = makeDistortionCurve(25);
            S.fxIn.connect(hp); hp.connect(lp); lp.connect(ws); ws.connect(S.fxOut);
        }
    }
    function buildOut() {
        const t = []; const a = S.mixDest && S.mixDest.stream.getAudioTracks()[0]; if (a) t.push(a); t.push(currentVideoTrack()); S.out = new MediaStream(t);
    }

    /* ── إرسال الأحداث لبقية المشاركين ── */
    function evt(k, extra) {
        if (!S.active) return; const pk = { type: 'call_evt', payload: Object.assign({ k, cid: S.cid }, extra || {}) };
        S.peers.forEach((p, pid) => { const c = activeConnections[pid]; if (c) sendPacket(c, pk); });
    }
    function evtTo(pid, k, extra) {
        const c = activeConnections[pid]; if (!c || !S.active) return;
        sendPacket(c, { type: 'call_evt', payload: Object.assign({ k, cid: S.cid }, extra || {}) });
    }
    function syncStateTo(pid) {
        evtTo(pid, 'cam', { on: !!(S.camOn && S.camTrack) }); evtTo(pid, 'mic', { on: S.micOn });
        if (S.screenStream) evtTo(pid, 'screen', { on: true }); if (S.handUp) evtTo(pid, 'hand', { on: true }); if (S.rec) evtTo(pid, 'rec', { on: true });
    }
    function videoSenders() { const r = []; S.peers.forEach((p) => { const pc = p.mc && p.mc.peerConnection; if (!pc) return; const s = pc.getSenders().find((x) => x.track && x.track.kind === 'video'); if (s) r.push([p, s]); }); return r; }
    function setBitrate(sender, bps) { try { const pr = sender.getParameters(); if (!pr.encodings || !pr.encodings.length) pr.encodings = [{}]; pr.encodings[0].maxBitrate = bps; sender.setParameters(pr).catch(() => {}); } catch (e) {} }
    const targetBitrate = () => { const m = parseInt(ls.get('hx11_br', 'auto')); if (m) return m; return S.screenStream ? 2600000 : (Q[S.quality] || Q['720']).br; };
    function refreshVideo() {
        const t = currentVideoTrack();
        videoSenders().forEach(([p, s]) => { s.replaceTrack(t).then(() => setBitrate(s, targetBitrate() * (p.slow ? 0.4 : 1))).catch(() => {}); });
        if (S.out) { S.out.getVideoTracks().forEach((x) => S.out.removeTrack(x)); S.out.addTrack(t); }
        const me = S.peers.get('me'); if (me && me.video) { me.video.srcObject = new MediaStream([t]); me.video.play().catch(() => {}); }
        updateTiles(); evt('cam', { on: !!(S.camOn && S.camTrack) }); evt('screen', { on: !!S.screenStream });
    }

    /* ── تجهيز الوسائط المحلية ── */
    async function prepareLocal(kind) {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { note('المتصفح لا يدعم المكالمات (يلزم HTTPS).'); return false; }
        let mic = null;
        try { mic = await getMic(); } catch (e) { note('تعذّر الميكروفون: ' + errMsg(e) + ' — ستدخل للاستماع فقط.'); S.micOn = false; }
        if (mic) S.micOn = true;
        setupAudio(mic);
        if (kind === 'video') { try { S.camTrack = await getCam(); S.camOn = true; } catch (e) { note('تعذّرت الكاميرا: ' + errMsg(e)); S.camOn = false; } }
        S.fxWas = needsFx(); buildOut(); return true;
    }

    /* ── بدء مكالمة ── */
    async function start(kind, targets) {
        if (S.active) { openUI(); return; }
        if (typeof peer === 'undefined' || !peer || !peer.open) { note('انتظر تجهيز الاتصال ثم أعد المحاولة.'); return; }
        targets = (targets || []).filter((p) => activeConnections[p] && activeConnections[p].open);
        if (!targets.length) { note('لا يوجد متصلون الآن. اربط صديقاً أولاً من القائمة الجانبية.'); return; }
        if (kind === 'screen' && !(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia)) { note('مشاركة الشاشة متاحة في متصفحات الحاسوب فقط.'); kind = 'audio'; }
        if (!(await prepareLocal(kind === 'video' ? 'video' : 'audio'))) return;
        S.cid = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); S.kind = kind === 'screen' ? 'audio' : kind; S.active = true;
        S.startedAt = Date.now(); openUI(); acquireWake();
        const members = [peer.id].concat(targets); targets.forEach((pid) => place(pid, members));
        note('جاري الاتصال...');
        if (kind === 'screen') shareScreen();
    }
    function place(pid, members) {
        if (S.peers.has(pid) || !activeConnections[pid]) return;
        let mc; try { mc = peer.call(pid, S.out, { metadata: { hd: 11, cid: S.cid, kind: S.kind, name: currentUser.username, members } }); } catch (e) { return; }
        if (!mc) return; addPeer(pid, mc, S.kind === 'video');
        const to = setTimeout(() => { const p = S.peers.get(pid); if (p && !p.stream) { note('لم يرد ' + p.name); dropPeer(pid); } }, 45000); S.timers.push(to);
    }
    function addPeer(pid, mc, cam) {
        const p = { mc, name: nameOf(pid), stream: null, cam: !!cam, mic: true, hand: false, screen: false, an: null, vol: 1, lastB: null, lastT: 0, lastL: 0, lastR: 0, slow: false, q: 3 };
        S.peers.set(pid, p);
        mc.on('stream', (st) => onRemote(pid, st)); mc.on('close', () => dropPeer(pid)); mc.on('error', () => dropPeer(pid));
        ensureTile(pid); layout();
    }
    function onRemote(pid, st) {
        const p = S.peers.get(pid); if (!p || (p.stream && p.stream.id === st.id)) return;
        p.stream = st; ensureTile(pid); p.video.srcObject = st; p.video.volume = p.vol; p.video.play().catch(() => {});
        if (S.ctx && st.getAudioTracks().length) { try { const src = S.ctx.createMediaStreamSource(st); p.an = analyser(src); src.connect(S.recDest); } catch (e) {} }
        if (S.devs.spk && p.video.setSinkId) p.video.setSinkId(S.devs.spk).catch(() => {});
        setTimeout(() => videoSenders().forEach(([q, s]) => setBitrate(s, targetBitrate())), 1500);
        if (!S.timers.some((t) => t === S.statIv)) { S.statIv = setInterval(pollStats, 3000); S.timers.push(S.statIv); }
        note(p.name + ' انضم للمكالمة'); syncStateTo(pid); layout();
    }
    function dropPeer(pid) {
        const p = S.peers.get(pid); if (!p) return; S.peers.delete(pid); S.expected.delete(pid);
        try { p.mc.close(); } catch (e) {} if (p.tile) p.tile.remove(); if (S.focus === pid) S.focus = null; delete S.recBy[pid];
        if (S.active) { note(p.name + ' غادر المكالمة'); layout(); updateRec(); if (S.peers.size === 1 && S.peers.has('me')) { const to = setTimeout(() => { if (S.active && S.peers.size === 1) { note('لا يوجد مشاركون — تم إنهاء المكالمة'); hangup(); } }, 30000); S.timers.push(to); } }
    }

    /* ── مكالمة واردة ── */
    const prevIn = typeof handleIncomingVoiceCall === 'function' ? handleIncomingVoiceCall : null;
    handleIncomingVoiceCall = function (call) {
        const m = call && call.metadata;
        if (!m || m.hd !== 11) return prevIn ? prevIn(call) : call.close();
        onIncoming(call);
    };
    function onIncoming(call) {
        const m = call.metadata || {}, pid = call.peer;
        if (!activeConnections[pid] || typeof m.cid !== 'string' || m.cid.length > 40) { try { call.close(); } catch (e) {} return; }
        if (HD.guard && HD.guard.allowCall && !HD.guard.allowCall(pid)) { note('حُجبت مكالمة من «' + nameOf(pid) + '» لأنك لم تتحقق من هويته (مستوى أقصى)'); declineNotify(call, m.cid); try { call.close(); } catch (e) {} return; }
        if (S.active) {
            if (S.locked && !S.peers.has(pid) && !S.expected.has(pid)) { note('المكالمة مقفلة — رُفض انضمام «' + nameOf(pid) + '»'); declineNotify(call, m.cid); try { call.close(); } catch (e) {} return; }
            if (m.cid === S.cid || S.expected.has(pid)) { answerCall(call); return; }
            note('مكالمة واردة من ' + nameOf(pid) + ' — أنت مشغول'); declineNotify(call, m.cid); try { call.close(); } catch (e) {} return;
        }
        if (S.pending.has(m.cid)) { S.pending.get(m.cid).calls.push(call); return; }
        const rec = { calls: [call], kind: m.kind === 'video' ? 'video' : 'audio', members: Array.isArray(m.members) ? m.members.filter((x) => typeof x === 'string' && x.length < 64).slice(0, 30) : [] };
        S.pending.set(m.cid, rec); ring(m.cid, pid, rec);
        try { showBrowserNotification('📞 مكالمة واردة', nameOf(pid) + (rec.kind === 'video' ? ' يتصل بك فيديو' : ' يتصل بك'), { tag: 'hd-call', cat: 'call', ttl: 40000, requireInteraction: true, actions: [{ action: 'answer', title: 'رد' }, { action: 'decline', title: 'رفض' }], data: { cid: m.cid, kind: rec.kind } }); } catch (e) {}
    }
    function stopRing() {
        if (S.ring) { clearInterval(S.ring.iv); try { S.ring.c.close(); } catch (e) {} S.ring = null; }
        if (S.ringUi) { S.ringUi.remove(); S.ringUi = null; } if (navigator.vibrate) navigator.vibrate(0);
    }
    function ring(cid, pid, rec) {
        stopRing();
        try {
            const AC = window.AudioContext || window.webkitAudioContext, c = new AC(), gn = c.createGain(); gn.gain.value = 0.07; gn.connect(c.destination);
            const beep = () => { [480, 620].forEach((f, i) => { const o = c.createOscillator(); o.type = 'sine'; o.frequency.value = f; o.connect(gn); const t = c.currentTime + i * 0.4; o.start(t); o.stop(t + 0.3); }); };
            beep(); S.ring = { c, iv: setInterval(beep, 2400) };
        } catch (e) {} if (navigator.vibrate) navigator.vibrate([300, 150, 300, 150, 300]);
        const card = el('div', 'hx11-ring'); card.setAttribute('role', 'alertdialog');
        const av = el('div', 'hx11-ring-av', nameOf(pid).slice(0, 1)); card.appendChild(av);
        const tx = el('div', 'hx11-ring-tx'); tx.appendChild(el('b', '', nameOf(pid))); tx.appendChild(el('small', '', rec.kind === 'video' ? 'مكالمة فيديو واردة' : 'مكالمة صوتية واردة' + (rec.members.length > 2 ? ' (جماعية)' : ''))); card.appendChild(tx);
        const acts = el('div', 'hx11-ring-act');
        const dec = iconBtn('hangup', 'رفض', () => decline(cid), 'red'); acts.appendChild(dec);
        if (rec.kind === 'video') acts.appendChild(iconBtn('phone', 'قبول بالصوت فقط', () => accept(cid, 'audio'), 'grey'));
        acts.appendChild(iconBtn(rec.kind === 'video' ? 'video' : 'phone', 'قبول', () => accept(cid, rec.kind), 'green'));
        card.appendChild(acts); document.body.appendChild(card); S.ringUi = card;
        const to = setTimeout(() => { if (S.pending.has(cid)) decline(cid); }, 40000); S.timers.push(to);
    }
    function declineNotify(call, cid) { const c = activeConnections[call.peer]; if (c) sendPacket(c, { type: 'call_evt', payload: { k: 'decline', cid } }); }
    function decline(cid) { const r = S.pending.get(cid); stopRing(); if (!r) return; r.calls.forEach((c) => { declineNotify(c, cid); try { c.close(); } catch (e) {} }); S.pending.delete(cid); }
    async function accept(cid, kind) {
        const r = S.pending.get(cid); stopRing(); if (!r) return; S.pending.delete(cid);
        if (!(await prepareLocal(kind === 'video' ? 'video' : 'audio'))) { r.calls.forEach((c) => { try { c.close(); } catch (e) {} }); return; }
        S.cid = cid; S.kind = kind; S.active = true; S.startedAt = Date.now(); openUI(); acquireWake();
        r.calls.forEach((c) => answerCall(c));
        r.members.forEach((m) => { if (m === peer.id || S.peers.has(m) || !activeConnections[m]) return; if (peer.id < m) place(m, r.members); else S.expected.add(m); });
    }
    function answerCall(call) {
        const pid = call.peer; if (S.peers.has(pid)) { try { call.close(); } catch (e) {} return; }
        try { call.answer(S.out); } catch (e) { return; } addPeer(pid, call, call.metadata && call.metadata.kind === 'video');
    }

    /* ── مشاركة الشاشة / سطح المكتب ── */
    async function shareScreen() {
        if (!S.active || S.screenStream) return;
        if (!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia)) { note('مشاركة الشاشة غير مدعومة على هذا الجهاز (تعمل في متصفحات الحاسوب).'); return; }
        const surf = ls.get('hx11_surface', 'monitor'), mode = ls.get('hx11_smode', 'detail'), wantAudio = ls.get('hx11_saudio', '1') === '1';
        const vid = { frameRate: { ideal: mode === 'detail' ? 15 : 30 }, width: { ideal: mode === 'detail' ? 2560 : 1920 }, height: { ideal: mode === 'detail' ? 1440 : 1080 } };
        if (surf !== 'any') vid.displaySurface = surf;
        let st;
        try { st = await navigator.mediaDevices.getDisplayMedia({ video: vid, audio: wantAudio ? { echoCancellation: false, noiseSuppression: false, autoGainControl: false } : false, selfBrowserSurface: 'exclude', systemAudio: 'include', surfaceSwitching: 'include', monitorTypeSurfaces: 'include' }); }
        catch (e) { if (e && e.name === 'NotAllowedError') return; try { st = await navigator.mediaDevices.getDisplayMedia({ video: true }); } catch (e2) { note('تعذّرت مشاركة الشاشة: ' + errMsg(e2)); return; } }
        const vt = st.getVideoTracks()[0]; try { vt.contentHint = mode === 'detail' ? 'detail' : 'motion'; } catch (e) {}
        vt.addEventListener('ended', stopScreen);
        const at = st.getAudioTracks()[0];
        if (at && S.ctx) { S.sysSrc = S.ctx.createMediaStreamSource(new MediaStream([at])); S.sysGain = S.ctx.createGain(); S.sysSrc.connect(S.sysGain); S.sysGain.connect(S.mixDest); S.sysGain.connect(S.recDest); }
        S.screenStream = st; refreshVideo(); S.mode = S.mode === 'mini' ? 'mini' : S.mode; note('بدأت مشاركة الشاشة' + (at ? ' مع الصوت' : '')); refreshCtrl();
    }
    function stopScreen() {
        if (!S.screenStream) return; S.screenStream.getTracks().forEach((t) => { try { t.stop(); } catch (e) {} });
        try { if (S.sysSrc) S.sysSrc.disconnect(); if (S.sysGain) S.sysGain.disconnect(); } catch (e) {} S.sysSrc = S.sysGain = null; S.screenStream = null;
        refreshVideo(); refreshCtrl(); note('توقفت مشاركة الشاشة');
    }

    /* ── ميكروفون / كاميرا ── */
    async function toggleMic() {
        if (!S.micStream) { try { const m = await getMic(); S.micStream = m; S.micSrc = S.ctx.createMediaStreamSource(m); S.micSrc.connect(S.fxIn); S.micOn = true; } catch (e) { note('تعذّر الميكروفون: ' + errMsg(e)); return; } }
        else S.micOn = !S.micOn;
        S.micGain.gain.value = S.micOn ? 1 : 0; evt('mic', { on: S.micOn }); refreshCtrl(); updateTiles();
    }
    async function toggleCam() {
        if (S.camOn && S.camTrack) { try { S.camTrack.stop(); } catch (e) {} S.camTrack = null; S.camOn = false; teardownFx(); }
        else { try { S.camTrack = await getCam(); S.camOn = true; } catch (e) { note('تعذّرت الكاميرا: ' + errMsg(e)); return; } }
        refreshVideo(); refreshCtrl();
    }
    async function flipCamera() {
        try {
            const devs = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput');
            if (S.devs.cam && devs.length > 1) { const i = devs.findIndex((d) => d.deviceId === S.devs.cam); S.devs.cam = devs[(i + 1) % devs.length].deviceId; ls.set('hx11_dcam', S.devs.cam); }
            else S.facing = S.facing === 'user' ? 'environment' : 'user';
            if (S.camTrack) { try { S.camTrack.stop(); } catch (e) {} } S.camTrack = await getCam(); S.camOn = true; refreshVideo(); refreshCtrl();
        } catch (e) { note('تعذّر تبديل الكاميرا: ' + errMsg(e)); }
    }

    /* ── التسجيل (فيديو مركّب + صوت الجميع) ── */
    function startRec() {
        if (S.rec || !S.active) return; if (!window.MediaRecorder) { note('التسجيل غير مدعوم في هذا المتصفح.'); return; }
        const cv = document.createElement('canvas'); cv.width = 1280; cv.height = 720; const c = cv.getContext('2d');
        const draw = () => {
            c.fillStyle = '#050505'; c.fillRect(0, 0, cv.width, cv.height);
            const vids = [...S.peers.entries()].filter(([id, p]) => p.video && p.video.videoWidth), n = Math.max(1, vids.length), cols = Math.ceil(Math.sqrt(n)), rows = Math.ceil(n / cols), w = cv.width / cols, h = cv.height / rows;
            vids.forEach(([id, p], i) => { const x = (i % cols) * w, y = Math.floor(i / cols) * h; try { if (p.cam || p.screen || id === 'me' && (S.camOn || S.screenStream)) c.drawImage(p.video, x, y, w, h); } catch (e) {} c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(x, y + h - 26, w, 26); c.fillStyle = '#fff'; c.font = '16px sans-serif'; c.fillText(id === 'me' ? 'أنت' : p.name, x + 8, y + h - 8); });
        };
        draw(); const iv = setInterval(draw, 66);
        const stream = new MediaStream([...cv.captureStream(15).getVideoTracks(), ...S.recDest.stream.getAudioTracks()]);
        const mt = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'].find((t) => MediaRecorder.isTypeSupported(t)) || '';
        let mr; try { mr = new MediaRecorder(stream, mt ? { mimeType: mt, videoBitsPerSecond: 2500000 } : undefined); } catch (e) { clearInterval(iv); note('تعذّر بدء التسجيل'); return; }
        const chunks = []; mr.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
        mr.onstop = () => {
            clearInterval(iv); if (!chunks.length) return; const ext = (mt.includes('mp4') ? 'mp4' : 'webm'), url = URL.createObjectURL(new Blob(chunks, { type: mt || 'video/webm' }));
            const a = document.createElement('a'); a.href = url; a.download = 'HDChat-call-' + new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-') + '.' + ext; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000);
        };
        mr.start(2000); S.rec = { mr, iv }; evt('rec', { on: true }); updateRec(); refreshCtrl(); note('بدأ التسجيل — تم إبلاغ الجميع');
    }
    function stopRec() { if (!S.rec) return; try { S.rec.mr.stop(); } catch (e) {} S.rec = null; evt('rec', { on: false }); updateRec(); refreshCtrl(); }

    /* ── الإحصائيات والتكيّف ── */
    async function pollStats() {
        for (const [pid, p] of S.peers) {
            const pc = p.mc && p.mc.peerConnection; if (!pc || !p.stream) continue;
            try {
                const rep = await pc.getStats(); let rtt = null, bytes = 0, lost = 0, recv = 0;
                rep.forEach((r) => { if (r.type === 'candidate-pair' && (r.nominated || r.selected) && r.state === 'succeeded' && r.currentRoundTripTime != null) rtt = r.currentRoundTripTime; if (r.type === 'inbound-rtp') { bytes += r.bytesReceived || 0; lost += r.packetsLost || 0; recv += r.packetsReceived || 0; } });
                const now = Date.now(), kbps = p.lastB != null ? Math.round((bytes - p.lastB) * 8 / ((now - p.lastT) / 1000) / 1000) : 0, dL = lost - p.lastL, dR = recv - p.lastR;
                p.lastB = bytes; p.lastT = now; p.lastL = lost; p.lastR = recv; const loss = (dL + dR) > 0 ? Math.max(0, dL) / (dL + dR) * 100 : 0, ms = rtt != null ? Math.round(rtt * 1000) : null;
                p.stat = { ms, kbps, loss }; p.q = ((ms != null && ms > 450) || loss > 12) ? 1 : ((ms != null && ms > 220) || loss > 4) ? 2 : 3;
                const slow = p.q === 1; if (slow !== p.slow) { p.slow = slow; const s = pc.getSenders().find((x) => x.track && x.track.kind === 'video'); if (s) setBitrate(s, targetBitrate() * (slow ? 0.4 : 1)); if (slow) note('شبكة ضعيفة مع ' + p.name + ' — تم خفض الجودة تلقائياً'); }
                if (p.statEl) p.statEl.textContent = (ms != null ? ms : '-') + ' ms · ' + kbps + ' kbps · فقد ' + loss.toFixed(1) + '%';
                if (p.bars) { p.bars.className = 'hx11-bars q' + p.q; p.bars.title = (ms != null ? ms + ' ms · ' : '') + kbps + ' kbps · فقد ' + loss.toFixed(1) + '%'; }
            } catch (e) {}
        }
    }

    /* ── الواجهة ── */
    const initial = (s) => (String(s || '؟').trim().slice(0, 1) || '؟');
    function ensureTile(pid) {
        const p = S.peers.get(pid); if (!p || p.tile) return;
        const t = el('div', 'hx11-tile'); t.dataset.pid = pid;
        const v = el('video'); v.autoplay = true; v.playsInline = true; if (pid === 'me') v.muted = true; v.setAttribute('playsinline', ''); t.appendChild(v); p.video = v;
        const av = el('div', 'hx11-av'); av.appendChild(el('span', '', initial(pid === 'me' ? currentUser.username : p.name))); t.appendChild(av); p.av = av;
        const bar = el('div', 'hx11-tbar'); const nm = el('span', 'hx11-nm', pid === 'me' ? 'أنت' : p.name); bar.appendChild(nm);
        p.micI = el('span', 'hx11-flag'); p.micI.appendChild(icon('micOff', 14)); bar.appendChild(p.micI);
        p.handI = el('span', 'hx11-flag hand'); p.handI.appendChild(icon('hand', 14)); bar.appendChild(p.handI);
        if (pid !== 'me') { p.bars = el('span', 'hx11-bars q3'); for (let i = 0; i < 3; i++) p.bars.appendChild(el('i')); bar.appendChild(p.bars); }
        t.appendChild(bar); p.statEl = el('div', 'hx11-statx'); t.appendChild(p.statEl);
        const act = el('div', 'hx11-tact');
        act.appendChild(iconBtn('spot', 'تركيز على هذا المشارك', () => { S.focus = S.focus === pid ? null : pid; if (S.focus && S.mode === 'grid') S.mode = 'spot'; layout(); refreshCtrl(); }, 'sm'));
        if (pid !== 'me') {
            act.appendChild(iconBtn('volume', 'كتم/تشغيل صوته عندي', (e) => { p.vol = p.vol ? 0 : 1; p.video.volume = p.vol; e.currentTarget.classList.toggle('on', !p.vol); }, 'sm'));
            act.appendChild(iconBtn('pip', 'نافذة عائمة', () => pip(p.video), 'sm'));
        }
        act.appendChild(iconBtn('camera', 'التقاط صورة', () => snapshot(pid), 'sm'));
        if (pid !== 'me') act.appendChild(iconBtn('videoOff', 'إيقاف فيديوه عندي (توفير بيانات)', (e) => { p.vOff = !p.vOff; if (p.stream) p.stream.getVideoTracks().forEach((x) => { x.enabled = !p.vOff; }); e.currentTarget.classList.toggle('on', p.vOff); updateTiles(); }, 'sm'));
        act.appendChild(iconBtn('full', 'ملء الشاشة', () => { if (t.requestFullscreen) t.requestFullscreen().catch(() => {}); }, 'sm'));
        t.appendChild(act); t.addEventListener('dblclick', () => { S.focus = S.focus === pid ? null : pid; if (S.focus && S.mode === 'grid') S.mode = 'spot'; layout(); });
        p.tile = t; updateTiles();
    }
    function pip(v) { try { if (document.pictureInPictureElement) document.exitPictureInPicture(); else if (v && v.requestPictureInPicture) v.requestPictureInPicture().catch(() => note('لا توجد صورة لعرضها الآن')); else note('الصورة العائمة غير مدعومة هنا'); } catch (e) {} }
    function updateTiles() {
        S.peers.forEach((p, pid) => {
            if (!p.tile) return; const isMe = pid === 'me', hasVid = isMe ? !!(S.screenStream || (S.camOn && S.camTrack)) : !!(p.stream && !p.vOff && p.stream.getVideoTracks().length && (p.cam || p.screen));
            p.tile.classList.toggle('novid', !hasVid); p.tile.classList.toggle('mine', isMe && !S.screenStream && ls.get('hx11_mirror', '1') === '1'); p.tile.classList.toggle('scr', isMe ? !!S.screenStream : p.screen);
            p.micI.style.display = (isMe ? !S.micOn : !p.mic) ? '' : 'none'; p.handI.style.display = (isMe ? S.handUp : p.hand) ? '' : 'none';
        });
        const me = S.peers.get('me'); if (me) me.tile.style.display = ls.get('hx11_hideme', '0') === '1' && S.peers.size > 1 ? 'none' : '';
    }
    function layout() {
        const u = S.ui; if (!u) return; const ids = [...S.peers.keys()].filter((id) => S.peers.get(id).tile);
        u.root.dataset.mode = S.mode === 'mini' ? 'mini' : S.mode; u.root.classList.toggle('mini', S.mode === 'mini');
        const pf = S.mode === 'present' ? presentFocus(ids) : null;
        const focusId = pf || ((S.mode === 'grid' || S.mode === 'mini' || S.mode === 'cinema') && !S.focus ? null : (S.focus && S.peers.has(S.focus) ? S.focus : ids.find((x) => x !== 'me') || ids[0]));
        u.main.textContent = ''; u.strip.textContent = '';
        if (S.mode === 'mini') { const f = (S.focus && S.peers.has(S.focus) ? S.focus : ids.find((x) => x !== 'me')) || ids[0]; ids.forEach((id) => { const t = S.peers.get(id).tile; t.classList.toggle('focus', id === f); u.main.appendChild(t); }); }
        else if (focusId) { ids.forEach((id) => { const t = S.peers.get(id).tile; t.classList.toggle('focus', id === focusId); (id === focusId ? u.main : u.strip).appendChild(t); }); }
        else ids.forEach((id) => { const t = S.peers.get(id).tile; t.classList.remove('focus'); u.main.appendChild(t); });
        const n = ids.length; u.main.style.setProperty('--cols', focusId || S.mode === 'mini' ? 1 : n <= 1 ? 1 : n === 2 ? (u.root.clientWidth > 700 ? 2 : 1) : n <= 4 ? 2 : n <= 9 ? 3 : 4);
        u.strip.style.display = focusId && u.strip.children.length ? '' : 'none';
        S.peers.forEach((p) => { if (p.video) p.video.play().catch(() => {}); }); u.count.textContent = (S.peers.size) + ' مشارك'; updateTiles();
    }
    function presentFocus(ids) {
        const sharer = ids.find((id) => id !== 'me' && S.peers.get(id).screen); if (sharer) return sharer; if (S.screenStream && ids.includes('me')) return 'me';
        if (S.lastSpeaker && ids.includes(S.lastSpeaker)) return S.lastSpeaker; return ids.find((x) => x !== 'me') || ids[0];
    }
    function updateRec() {
        const u = S.ui; if (!u) return; const who = Object.keys(S.recBy).filter((k) => S.recBy[k]).map((k) => nameOf(k)); if (S.rec) who.unshift('أنت');
        u.rec.style.display = who.length ? '' : 'none'; u.rec.lastChild.textContent = 'يتم تسجيل المكالمة: ' + who.join('، ');
    }
    function refreshCtrl() {
        const vb = g('hx11-call-btn'); if (vb) vb.classList.toggle('live', S.active);
        const u = S.ui; if (!u) return; const c = u.c, swap = (b, name, on) => { b.textContent = ''; b.appendChild(icon(name, 20)); b.classList.toggle('off', !!on); };
        swap(c.mic, S.micOn ? 'mic' : 'micOff', !S.micOn); swap(c.cam, S.camOn ? 'video' : 'videoOff', !S.camOn);
        if (u.lockB) u.lockB.style.display = S.locked ? '' : 'none'; u.root.classList.toggle('cine', S.mode === 'cinema');
        c.screen.classList.toggle('on', !!S.screenStream); c.rec.classList.toggle('on', !!S.rec); c.hand.classList.toggle('on', S.handUp);
        c.layout.textContent = ''; c.layout.appendChild(icon(S.mode === 'grid' ? 'grid' : 'spot', 20)); c.layout.title = 'نمط العرض: ' + (S.mode === 'grid' ? 'شبكة' : 'تركيز');
    }
    function openUI() {
        if (S.ui) { S.mode = S.mode === 'mini' ? 'grid' : S.mode; layout(); S.ui.root.style.display = ''; refreshCtrl(); return; }
        const root = el('div', 'hx11-call'); root.setAttribute('role', 'dialog'); root.setAttribute('aria-label', 'مكالمة');
        const top = el('div', 'hx11-ctop'); const title = el('b', '', S.kind === 'video' ? 'مكالمة فيديو' : 'مكالمة صوتية'); const timer = el('span', 'hx11-timer', '0:00'); const count = el('span', 'hx11-count', ''); const lock = el('span', 'hx11-enc'); lock.appendChild(icon('lock', 13)); lock.appendChild(el('span', '', 'مشفّرة'));
        const lockB = el('span', 'hx11-lockb'); lockB.appendChild(icon('lock', 12)); lockB.appendChild(el('span', '', 'مقفلة')); lockB.style.display = 'none';
        top.appendChild(title); top.appendChild(timer); top.appendChild(count); top.appendChild(lockB); top.appendChild(lock);
        const rec = el('div', 'hx11-recb'); rec.appendChild(icon('rec', 14)); rec.appendChild(el('span', '', '')); rec.style.display = 'none';
        const stage = el('div', 'hx11-stage'); const main = el('div', 'hx11-main'); const strip = el('div', 'hx11-strip'); stage.appendChild(main); stage.appendChild(strip);
        const bar = el('div', 'hx11-cbar'), c = {}; const add = (k, ico, ttl, fn, cls) => { c[k] = iconBtn(ico, ttl, fn, 'ctl' + (cls ? ' ' + cls : '')); bar.appendChild(c[k]); return c[k]; };
        add('mic', 'mic', 'الميكروفون (M)', toggleMic); add('cam', 'video', 'الكاميرا (V)', toggleCam);
        if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) add('screen', 'monitor', 'مشاركة الشاشة أو سطح المكتب (S)', () => S.screenStream ? stopScreen() : shareScreen());
        else c.screen = el('span');
        add('flip', 'flip', 'تبديل الكاميرا', flipCamera); add('react', 'smile', 'تفاعل', (e) => reactMenu(e.currentTarget)); add('hand', 'hand', 'رفع اليد', () => { S.handUp = !S.handUp; evt('hand', { on: S.handUp }); refreshCtrl(); updateTiles(); });
        add('layout', 'grid', 'نمط العرض', () => { S.mode = S.mode === 'grid' ? 'spot' : 'grid'; if (S.mode === 'grid') S.focus = null; layout(); refreshCtrl(); });
        add('modes', 'layers', 'أوضاع المكالمة', () => openModes());
        add('rec', 'rec', 'تسجيل المكالمة', () => S.rec ? stopRec() : startRec()); add('pip', 'pip', 'نافذة عائمة (PiP)', () => { const p = [...S.peers.entries()].find(([id, q]) => id !== 'me' && q.video && q.video.srcObject); pip(p ? p[1].video : null); });
        add('add', 'plus', 'إضافة مشارك', addMenu); add('chat', 'chat', 'دردشة المكالمة', toggleChat); add('set', 'sliders', 'الإعدادات', openSettings); add('mini', 'mini', 'تصغير', () => { S.mode = 'mini'; layout(); });
        add('full', 'full', 'ملء الشاشة (F)', () => { if (document.fullscreenElement) document.exitFullscreen(); else if (root.requestFullscreen) root.requestFullscreen().catch(() => {}); });
        add('end', 'hangup', 'إنهاء المكالمة', () => hangup(), 'end');
        const expand = iconBtn('full', 'تكبير المكالمة', () => { S.mode = 'grid'; layout(); refreshCtrl(); }, 'hx11-miniexp'); const handle = el('div', 'hx11-handle');
        root.appendChild(top); root.appendChild(rec); root.appendChild(stage); root.appendChild(bar); root.appendChild(expand); root.appendChild(handle); document.body.appendChild(root);
        S.ui = { root, main, strip, c, timer, count, rec, lockB };
        let cineT = null; S.cineWake = () => { root.classList.remove('ui-hide'); clearTimeout(cineT); if (S.mode === 'cinema') cineT = setTimeout(() => root.classList.add('ui-hide'), 3200); };
        ['pointermove', 'pointerdown', 'touchstart', 'keydown'].forEach((ev) => root.addEventListener(ev, S.cineWake, { passive: true })); root.classList.toggle('showstats', ls.get('hx11_stats', '0') === '1');
        const me = { mc: null, name: currentUser.username, stream: null, cam: false, mic: true, hand: false, screen: false }; S.peers.set('me', me); ensureTile('me'); me.video.srcObject = new MediaStream([currentVideoTrack()]); me.video.play().catch(() => {});
        S.peers.forEach((p, pid) => { if (pid !== 'me') ensureTile(pid); });
        dragMini(root, handle); layout(); refreshCtrl();
        S.timers.push(setInterval(() => { timer.textContent = fmtDur(Date.now() - S.startedAt); speaking(); }, 250));
        S.keyH = (e) => {
            if (!S.active || /^(input|textarea|select)$/i.test((e.target.tagName || ''))) return; if (e.ctrlKey || e.metaKey || e.altKey) return;
            const k = e.key.toLowerCase(); if (k === 'm') toggleMic(); else if (k === 'v') toggleCam(); else if (k === 's' && c.screen.click) c.screen.click(); else if (k === 'f') c.full.click();
        };
        document.addEventListener('keydown', S.keyH);
    }
    function speaking() {
        let best = null, bl = 0.08;
        S.peers.forEach((p, pid) => { const an = pid === 'me' ? S.meAn : p.an, lv = pid === 'me' && !S.micOn ? 0 : level(an); if (p.tile) p.tile.classList.toggle('speaking', lv > 0.08); if (pid !== 'me' && lv > bl) { bl = lv; best = pid; } });
        if (best) { if (S.mode === 'present') { if (S.lastSpeaker !== best && Date.now() - S.lastSpkT > 1800) { S.lastSpeaker = best; S.lastSpkT = Date.now(); layout(); } } else S.lastSpeaker = best; }
        if (best && ls.get('hx11_autospot', '0') === '1' && S.mode !== 'grid' && S.mode !== 'mini' && S.focus !== best) { S.speakT = (S.speakT && S.speakT.id === best) ? S.speakT : { id: best, t: Date.now() }; if (Date.now() - S.speakT.t > 1200) { S.focus = best; layout(); } } else S.speakT = null;
    }
    function dragMini(root, handle) {
        let sx, sy, ox, oy, on = false;
        handle.addEventListener('pointerdown', (e) => { if (S.mode !== 'mini') return; on = true; const r = root.getBoundingClientRect(); sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top; handle.setPointerCapture(e.pointerId); });
        handle.addEventListener('pointermove', (e) => { if (!on) return; const x = Math.min(innerWidth - 80, Math.max(0, ox + e.clientX - sx)), y = Math.min(innerHeight - 80, Math.max(0, oy + e.clientY - sy)); root.style.left = x + 'px'; root.style.top = y + 'px'; root.style.right = 'auto'; root.style.bottom = 'auto'; });
        handle.addEventListener('pointerup', () => { on = false; });
    }
    function reactMenu(anchor) {
        const old = g('hx11-react-menu'); if (old) { old.remove(); return; }
        const m = el('div', 'hx11-reactmenu'); m.id = 'hx11-react-menu';
        REACTS.forEach((e) => { const b = el('button', '', e); b.type = 'button'; b.onclick = () => { evt('react', { e }); floatReact('me', e); m.remove(); }; m.appendChild(b); });
        S.ui.root.appendChild(m); setTimeout(() => document.addEventListener('click', function f() { m.remove(); document.removeEventListener('click', f); }, { once: true }), 0);
    }
    function floatReact(pid, e) { const p = S.peers.get(pid); if (!p || !p.tile) return; const f = el('span', 'hx11-float', e); f.style.insetInlineStart = (20 + Math.random() * 60) + '%'; p.tile.appendChild(f); setTimeout(() => f.remove(), 2200); }
    function addMenu() {
        const free = Object.keys(activeConnections).filter((pid) => activeConnections[pid].open && !S.peers.has(pid));
        sheet('إضافة مشارك للمكالمة', (b) => {
            if (!free.length) { b.appendChild(el('p', 'hx-muted', 'كل المتصلين معك في المكالمة بالفعل.')); return; }
            free.forEach((pid) => { const r = el('div', 'hx11-row'); r.appendChild(el('span', '', nameOf(pid))); const x = el('button', 'hx11-chipbtn', 'اتصال'); x.type = 'button'; x.onclick = () => { place(pid, [peer.id].concat([...S.peers.keys()].filter((k) => k !== 'me'), [pid])); x.textContent = 'جاري...'; x.disabled = true; }; r.appendChild(x); b.appendChild(r); });
        });
    }
    /* ── رمز أمان المكالمة: بصمات DTLS للطرفين (يكشف اعتراض مسار الوسائط) ── */
    const fpOf = (sdp) => { const m = /a=fingerprint:(\S+)\s+([0-9A-Fa-f:]+)/.exec(sdp || ''); return m ? m[1].toLowerCase() + ' ' + m[2].toUpperCase() : null; };
    async function sasFromPc(pc) {
        const l = fpOf(pc.localDescription && pc.localDescription.sdp), r = fpOf(pc.remoteDescription && pc.remoteDescription.sdp); if (!l || !r) return null;
        const o = [l, r].sort(), h = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode('hdc11-sas|' + o[0] + '|' + o[1]))); let big = 0n; for (let i = 0; i < 10; i++) big = (big << 8n) | BigInt(h[i]);
        return big.toString().padStart(24, '0').slice(0, 20).match(/.{4}/g).join(' ');
    }
    /* ── أوضاع المكالمة ── */
    const MODES = [['grid', 'شبكة', 'grid', 'الجميع بحجم متساوٍ'], ['spot', 'تركيز', 'spot', 'مشارك كبير والبقية صغار'], ['present', 'محاضرة', 'monitor', 'يتبع الشاشة المشاركة أو المتحدث'], ['side', 'جانبي', 'layers', 'شريط جانبي دائم'], ['cinema', 'سينما', 'full', 'الأزرار تختفي تلقائياً'], ['mini', 'مصغّرة', 'mini', 'نافذة عائمة']];
    const PROFS = [['normal', 'عادي', 'sliders', '720p تلقائي'], ['data', 'توفير بيانات', 'globe', '240p · 15fps · بلا فيديو واردة'], ['audio', 'صوت فقط', 'phone', 'يوقف الكاميرا والفيديو الوارد'], ['privacy', 'خصوصية', 'eyeOff', 'تمويه كامل لصورتي'], ['max', 'أعلى جودة', 'video', '1080p · 30fps']];
    function setMode(id) {
        if (!MODES.some((m) => m[0] === id)) return; S.mode = id; if (id === 'grid' || id === 'cinema') S.focus = null; layout(); refreshCtrl(); if (S.cineWake) S.cineWake();
        if (id !== 'cinema' && S.ui) S.ui.root.classList.remove('ui-hide');
    }
    async function applyProfile(id) {
        const P = { normal: { q: '720', fps: 0, br: 'auto', rv: false }, data: { q: '240', fps: 15, br: '300000', rv: true, fx: 'none' }, audio: { q: '240', fps: 15, br: '300000', rv: true, cam: false }, privacy: { q: '720', fps: 0, br: 'auto', rv: false, fx: 'privacy' }, max: { q: '1080', fps: 30, br: '3000000', rv: false, fx: 'none' } }, cfg = P[id]; if (!cfg) return;
        S.prof = id; ls.set('hx11_cprof', id); S.quality = cfg.q; ls.set('hx11_q', cfg.q); S.fps = cfg.fps; ls.set('hx11_fps', String(cfg.fps)); ls.set('hx11_br', cfg.br);
        if (cfg.fx) { S.vfx = cfg.fx; ls.set('hx11_vfx', cfg.fx); } else if (S.vfx === 'privacy') { S.vfx = 'none'; ls.set('hx11_vfx', 'none'); }
        S.peers.forEach((p, pid) => { if (pid !== 'me') { p.vOff = cfg.rv; if (p.stream) p.stream.getVideoTracks().forEach((t) => { t.enabled = !cfg.rv; }); } });
        if (cfg.cam === false) { if (S.camOn) await toggleCam(); } else if (S.camOn) { try { if (S.camTrack) S.camTrack.stop(); S.camTrack = await getCam(); teardownFx(); } catch (e) { note('تعذّر تطبيق إعدادات الكاميرا'); } }
        S.fxWas = needsFx(); refreshVideo(); videoSenders().forEach(([p, s]) => setBitrate(s, targetBitrate())); updateTiles(); note('تم تفعيل ملف «' + PROFS.find((x) => x[0] === id)[1] + '»');
    }
    function openModes() {
        if (!S.active) { note('ابدأ مكالمة أولاً'); return; }
        sheet('أوضاع المكالمة', (b) => {
            section(b, 'نمط العرض'); const g1 = el('div', 'hx11-tiles');
            MODES.forEach(([id, label, ic, hint]) => { const t = el('button', 'hx11-tile2' + (S.mode === id ? ' sel' : '')); t.type = 'button'; t.appendChild(icon(ic, 22)); t.appendChild(el('b', '', label)); t.appendChild(el('small', '', hint)); t.onclick = () => { const w = g('hx-sheet'); if (w) w.remove(); setMode(id); }; g1.appendChild(t); }); b.appendChild(g1);
            section(b, 'ملف الاتصال (الجودة والخصوصية)'); const g2 = el('div', 'hx11-tiles');
            PROFS.forEach(([id, label, ic, hint]) => { const t = el('button', 'hx11-tile2' + (S.prof === id ? ' sel' : '')); t.type = 'button'; t.appendChild(icon(ic, 22)); t.appendChild(el('b', '', label)); t.appendChild(el('small', '', hint)); t.onclick = async () => { const w = g('hx-sheet'); if (w) w.remove(); await applyProfile(id); }; g2.appendChild(t); }); b.appendChild(g2);
            section(b, 'أمان المكالمة');
            row(b, 'قفل المكالمة', toggle(S.locked, (v) => { S.locked = v; evt('lock', { on: v }); refreshCtrl(); note(v ? 'المكالمة مقفلة: لن ينضم أحد جديد' : 'تم فتح المكالمة'); }), 'يمنع انضمام أي شخص جديد.');
            b.appendChild(el('p', 'hx-muted', 'رمز أمان المكالمة: اقرأه بصوتك مع كل مشارك. إن اختلف الرمز عندكما فهناك من يعترض الاتصال.'));
            const box = el('div'); b.appendChild(box); let any = false;
            [...S.peers.entries()].filter(([id, p]) => id !== 'me' && p.mc && p.mc.peerConnection).forEach(async ([id, p]) => {
                any = true; const r = el('div', 'hx11-peer'); r.appendChild(el('b', '', p.name)); const code = el('code', 'hx11-fp', 'جاري الحساب...'); r.appendChild(code); box.appendChild(r);
                try { const v = await sasFromPc(p.mc.peerConnection); code.textContent = v || 'غير جاهز بعد — أعد الفتح بعد اتصال الصوت'; } catch (e) { code.textContent = 'تعذّر الحساب'; }
            });
            if (!any) box.appendChild(el('p', 'hx-muted', 'لا يوجد مشاركون متصلون بعد.'));
        }, { wide: true });
    }
    /* ── التقاط صورة من أي مربع ── */
    function snapshot(pid) {
        const p = S.peers.get(pid), v = p && p.video; if (!v || !v.videoWidth) { note('لا توجد صورة لالتقاطها الآن'); return; }
        const cv = document.createElement('canvas'); cv.width = v.videoWidth; cv.height = v.videoHeight; cv.getContext('2d').drawImage(v, 0, 0);
        cv.toBlob((bl) => { if (!bl) return; const u = URL.createObjectURL(bl), a = document.createElement('a'); a.href = u; a.download = 'HDChat-' + (pid === 'me' ? 'me' : 'peer') + '-' + Date.now() + '.png'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 20000); note('تم حفظ الصورة'); }, 'image/png');
    }
    /* ── دردشة داخل المكالمة ── */
    function addChat(who, text, mine) {
        S.chat.push({ who, text, mine }); if (S.chat.length > 100) S.chat.shift();
        const u = S.ui; if (!u) return; if (u.chatList) { const m = el('div', 'hx11-cm' + (mine ? ' me' : '')); m.appendChild(el('b', '', who)); m.appendChild(el('span', '', text)); u.chatList.appendChild(m); u.chatList.scrollTop = u.chatList.scrollHeight; }
        if (!mine && !(u.chatBox && u.chatBox.style.display !== 'none')) { S.unreadChat++; const b = u.c && u.c.chat; if (b) b.dataset.n = String(S.unreadChat); }
    }
    function toggleChat() {
        const u = S.ui; if (!u) return;
        if (!u.chatBox) {
            const box = el('div', 'hx11-cchat'); const list = el('div', 'hx11-clist'); const form = el('div', 'hx11-cform'); const inp = el('input'); inp.type = 'text'; inp.maxLength = 200; inp.placeholder = 'اكتب للمشاركين...'; inp.setAttribute('aria-label', 'رسالة داخل المكالمة');
            const sendIt = () => { const t = inp.value.trim(); if (!t) return; inp.value = ''; addChat('أنت', t, true); evt('chat', { t }); };
            inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); sendIt(); } e.stopPropagation(); }); form.appendChild(inp); form.appendChild(iconBtn('send', 'إرسال', sendIt, 'sm'));
            box.appendChild(list); box.appendChild(form); u.root.appendChild(box); u.chatBox = box; u.chatList = list; S.chat.forEach((m) => { const d = el('div', 'hx11-cm' + (m.mine ? ' me' : '')); d.appendChild(el('b', '', m.who)); d.appendChild(el('span', '', m.text)); list.appendChild(d); }); box.style.display = 'none';
        }
        const show = u.chatBox.style.display === 'none'; u.chatBox.style.display = show ? '' : 'none'; if (show) { S.unreadChat = 0; delete u.c.chat.dataset.n; u.chatList.scrollTop = u.chatList.scrollHeight; const i = u.chatBox.querySelector('input'); if (i) i.focus(); }
    }
    function acquireWake() { try { if (navigator.wakeLock) navigator.wakeLock.request('screen').then((w) => { S.wake = w; }).catch(() => {}); } catch (e) {} }

    /* ── إعدادات المكالمة ── */
    async function openSettings() {
        let devs = []; try { devs = await navigator.mediaDevices.enumerateDevices(); } catch (e) {}
        const list = (kind) => [['', 'الافتراضي']].concat(devs.filter((d) => d.kind === kind).map((d, i) => [d.deviceId, d.label || (kind + ' ' + (i + 1))]));
        sheet('إعدادات المكالمة', (b) => {
            section(b, 'الأجهزة');
            row(b, 'الميكروفون', select(list('audioinput'), S.devs.mic, async (v) => { S.devs.mic = v; ls.set('hx11_dmic', v); if (!S.active) return; try { const m = await getMic(); if (S.micSrc) S.micSrc.disconnect(); if (S.micStream) S.micStream.getTracks().forEach((t) => t.stop()); S.micStream = m; S.micSrc = S.ctx.createMediaStreamSource(m); S.micSrc.connect(S.fxIn); } catch (e) { note('تعذّر تغيير الميكروفون'); } }));
            row(b, 'الكاميرا', select(list('videoinput'), S.devs.cam, async (v) => { S.devs.cam = v; ls.set('hx11_dcam', v); if (S.active && S.camOn) { try { S.camTrack && S.camTrack.stop(); S.camTrack = await getCam(); refreshVideo(); } catch (e) { note('تعذّر تغيير الكاميرا'); } } }));
            if (HTMLMediaElement.prototype.setSinkId) row(b, 'مخرج الصوت', select(list('audiooutput'), S.devs.spk, (v) => { S.devs.spk = v; ls.set('hx11_dspk', v); S.peers.forEach((p) => { if (p.video && p.video.setSinkId) p.video.setSinkId(v).catch(() => {}); }); }));
            section(b, 'جودة الصوت');
            row(b, 'إلغاء الضوضاء', toggle(ls.get('hx11_ns', '1') === '1', (v) => { ls.set('hx11_ns', v ? '1' : '0'); applyAudioC(); }));
            row(b, 'إلغاء الصدى', toggle(ls.get('hx11_ec', '1') === '1', (v) => { ls.set('hx11_ec', v ? '1' : '0'); applyAudioC(); }));
            row(b, 'ضبط المستوى تلقائياً', toggle(ls.get('hx11_agc', '1') === '1', (v) => { ls.set('hx11_agc', v ? '1' : '0'); applyAudioC(); }));
            row(b, 'مؤثر صوتي', select(FX, S.fx, (v) => { S.fx = v; ls.set('hx11_fx', v); if (S.ctx) applyFx(v); }), 'يغيّر صوتك للجميع.');
            section(b, 'جودة الفيديو');
            row(b, 'دقة الكاميرا', select([['240', '240p — توفير بيانات'], ['360', '360p'], ['720', '720p HD'], ['1080', '1080p Full HD']], S.quality, async (v) => { S.quality = v; ls.set('hx11_q', v); if (S.camTrack) { try { await S.camTrack.applyConstraints({ width: { ideal: Q[v].w }, height: { ideal: Q[v].h }, frameRate: { ideal: Q[v].f } }); } catch (e) {} } videoSenders().forEach(([p, s]) => setBitrate(s, targetBitrate())); }));
            section(b, 'تأثيرات الفيديو والصورة');
            const pv = document.createElement('video'); pv.className = 'hx11-pv'; pv.muted = true; pv.autoplay = true; pv.playsInline = true; const setPv = () => { try { pv.srcObject = new MediaStream([currentVideoTrack()]); pv.play().catch(() => {}); } catch (e) {} }; setPv(); b.appendChild(pv); const _vx = () => { applyVfx(); setPv(); };
            row(b, 'المؤثر', select(FXV, S.vfx, (v) => { S.vfx = v; ls.set('hx11_vfx', v); _vx(); }), S.camOn ? 'يظهر لك ولجميع المشاركين.' : 'شغّل الكاميرا لتراه.');
            const sl = (key, prop, min, max, step) => { const i = document.createElement('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = S[prop]; i.oninput = () => { S[prop] = +i.value; ls.set(key, String(S[prop])); _vx(); }; return i; };
            row(b, 'السطوع', sl('hx11_vb', 'vb', 50, 150, 5)); row(b, 'التباين', sl('hx11_vc', 'vc', 50, 150, 5)); row(b, 'تكبير الصورة', sl('hx11_vz', 'vz', 100, 200, 5));
            const rs = document.createElement('button'); rs.className = 'hx11-chipbtn'; rs.type = 'button'; rs.textContent = 'إعادة'; rs.onclick = () => { S.vfx = 'none'; S.vb = S.vc = S.vz = 100; ['hx11_vfx', 'hx11_vb', 'hx11_vc', 'hx11_vz'].forEach((k) => ls.del(k)); applyVfx(); const w = g('hx-sheet'); if (w) w.remove(); openSettings(); }; row(b, 'إعادة ضبط التأثيرات', rs);
            section(b, 'الأداء والشبكة');
            row(b, 'معدل الإطارات', select([['0', 'تلقائي'], ['15', '15 (توفير)'], ['24', '24'], ['30', '30'], ['60', '60 (أعلى سلاسة)']], String(S.fps), async (v) => { S.fps = +v; ls.set('hx11_fps', v); if (S.active && S.camOn) { try { S.camTrack && S.camTrack.stop(); S.camTrack = await getCam(); teardownFx(); refreshVideo(); setPv(); } catch (e) { note('تعذّر تغيير معدل الإطارات'); } } }));
            row(b, 'سقف استهلاك البيانات', select([['auto', 'تلقائي'], ['300000', '300 kbps'], ['800000', '800 kbps'], ['1500000', '1.5 Mbps'], ['3000000', '3 Mbps']], ls.get('hx11_br', 'auto'), (v) => { ls.set('hx11_br', v); videoSenders().forEach(([p, s]) => setBitrate(s, targetBitrate())); }));
            row(b, 'إظهار إحصائيات الشبكة على المربعات', toggle(ls.get('hx11_stats', '0') === '1', (v) => { ls.set('hx11_stats', v ? '1' : '0'); if (S.ui) S.ui.root.classList.toggle('showstats', v); }));
            section(b, 'مشاركة الشاشة وسطح المكتب');
            row(b, 'ما الذي تفضّل مشاركته', select([['monitor', 'الشاشة كاملة (سطح المكتب)'], ['window', 'نافذة تطبيق'], ['browser', 'تبويب متصفح'], ['any', 'دع المتصفح يسأل']], ls.get('hx11_surface', 'monitor'), (v) => ls.set('hx11_surface', v)), 'هذا تفضيل فقط؛ المتصفح يعرض اختياره دائماً.');
            row(b, 'نمط الجودة', select([['detail', 'نصوص ومستندات (وضوح أعلى)'], ['motion', 'فيديو وألعاب (سلاسة أعلى)']], ls.get('hx11_smode', 'detail'), (v) => ls.set('hx11_smode', v)));
            row(b, 'مشاركة صوت الجهاز/التبويب', toggle(ls.get('hx11_saudio', '1') === '1', (v) => ls.set('hx11_saudio', v ? '1' : '0')), 'يعتمد على المتصفح ونوع المشاركة.');
            section(b, 'العرض');
            row(b, 'عكس صورتي (مرآة)', toggle(ls.get('hx11_mirror', '1') === '1', (v) => { ls.set('hx11_mirror', v ? '1' : '0'); updateTiles(); }));
            row(b, 'إخفاء صورتي عني', toggle(ls.get('hx11_hideme', '0') === '1', (v) => { ls.set('hx11_hideme', v ? '1' : '0'); updateTiles(); }));
            row(b, 'تركيز تلقائي على المتحدث', toggle(ls.get('hx11_autospot', '0') === '1', (v) => ls.set('hx11_autospot', v ? '1' : '0')), 'في نمط التركيز فقط.');
        });
    }
    function applyAudioC() { if (S.micStream) { const t = S.micStream.getAudioTracks()[0]; if (t && t.applyConstraints) t.applyConstraints({ echoCancellation: ls.get('hx11_ec', '1') === '1', noiseSuppression: ls.get('hx11_ns', '1') === '1', autoGainControl: ls.get('hx11_agc', '1') === '1' }).catch(() => {}); } }

    /* ── إنهاء ── */
    function hangup() {
        if (!S.active && !S.pending.size) return;
        const dur = S.startedAt ? Date.now() - S.startedAt : 0; try { evt('leave'); } catch (e) {} stopRec(); stopRing(); S.pending.forEach((r) => r.calls.forEach((c) => { try { c.close(); } catch (e) {} })); S.pending.clear();
        S.peers.forEach((p, pid) => { if (p.mc) try { p.mc.close(); } catch (e) {} }); S.peers.clear(); S.expected.clear();
        [S.micStream, S.screenStream].forEach((s) => { if (s) s.getTracks().forEach((t) => { try { t.stop(); } catch (e) {} }); }); if (S.camTrack) try { S.camTrack.stop(); } catch (e) {} if (S.blackTrack) try { S.blackTrack.stop(); } catch (e) {}
        teardownFx(); S.chat = []; S.unreadChat = 0; S.locked = false; S.mode = 'grid'; S.timers.forEach((t) => { clearInterval(t); clearTimeout(t); }); S.timers = []; if (S.keyH) document.removeEventListener('keydown', S.keyH);
        if (S.ctx) try { S.ctx.close(); } catch (e) {} if (S.wake) try { S.wake.release(); } catch (e) {} if (document.fullscreenElement) try { document.exitFullscreen(); } catch (e) {}
        if (S.ui) S.ui.root.remove(); const rm = g('hx11-react-menu'); if (rm) rm.remove();
        Object.assign(S, { active: false, cid: null, ctx: null, micStream: null, micSrc: null, fxIn: null, fxOut: null, fxNodes: [], micGain: null, mixDest: null, recDest: null, camTrack: null, camOn: false, micOn: true, screenStream: null, sysSrc: null, sysGain: null, blackTrack: null, blackCv: null, out: null, ui: null, rec: null, recBy: {}, wake: null, meAn: null, handUp: false, focus: null, mode: 'grid', startedAt: 0, statIv: null });
        refreshCtrl(); if (dur > 2000) { try { appendSystemMessage('انتهت المكالمة — المدة ' + fmtDur(dur)); } catch (e) {} }
    }
    HD.call.hangup = hangup; HD.call.start = start; HD.call.openModes = () => openModes(); HD.call.sas = sasFromPc; HD.call.applyProfile = (id) => applyProfile(id); HD.call.setMode = (id) => setMode(id); HD.call.openSettings = openSettings; HD.call.openStart = openStart;
    HD.call.acceptPending = (cid, kind) => { const r = S.pending.get(cid); if (r) accept(cid, kind || r.kind); }; HD.call.declinePending = (cid) => decline(cid);

    /* ── أحداث المكالمة الواردة من الآخرين ── */
    const KINDS = new Set(['cam', 'mic', 'screen', 'react', 'hand', 'rec', 'leave', 'decline', 'chat', 'lock']);
    HD.on('call_evt', (p, conn) => {
        if (!S.active || !p || typeof p.k !== 'string' || !KINDS.has(p.k) || p.cid !== S.cid) return; const rec = S.peers.get(conn.peer); if (!rec) return;
        switch (p.k) {
            case 'cam': rec.cam = !!p.on; break;
            case 'mic': rec.mic = !!p.on; break;
            case 'screen': rec.screen = !!p.on; if (p.on) { S.focus = conn.peer; if (S.mode === 'grid') S.mode = 'spot'; note(rec.name + ' يشارك شاشته'); } else if (S.focus === conn.peer) S.focus = null; layout(); refreshCtrl(); break;
            case 'react': if (REACTS.includes(p.e)) floatReact(conn.peer, p.e); break;
            case 'hand': rec.hand = !!p.on; if (p.on) note(rec.name + ' رفع يده'); break;
            case 'rec': S.recBy[conn.peer] = !!p.on; updateRec(); if (p.on) note(rec.name + ' بدأ تسجيل المكالمة'); break;
            case 'lock': note(rec.name + (p.on ? ' قفل المكالمة' : ' فتح المكالمة')); break;
            case 'chat': if (typeof p.t === 'string') { addChat(rec.name, p.t.slice(0, 200), false); } return;
            case 'leave': dropPeer(conn.peer); return;
            case 'decline': note(rec.name + ' لم يقبل المكالمة'); S.peers.delete(conn.peer); if (rec.tile) rec.tile.remove(); try { rec.mc.close(); } catch (e) {} layout(); return;
        }
        updateTiles();
    });

    /* ── نقاط الدخول من الواجهة ── */
    function openStart(kind) {
        if (S.active) { openUI(); return; }
        const ids = Object.keys(activeConnections || {}).filter((pid) => activeConnections[pid] && activeConnections[pid].open);
        sheet(kind === 'screen' ? 'مشاركة الشاشة مع...' : kind === 'video' ? 'مكالمة فيديو' : 'مكالمة صوتية', (b) => {
            if (!ids.length) { b.appendChild(el('p', 'hx-muted', 'لا يوجد متصلون الآن. افتح القائمة الجانبية وانسخ رابط الدعوة أو اربط معرّف صديقك أولاً.')); return; }
            const chosen = new Set(ids);
            section(b, 'اختر المشاركين (' + ids.length + ' متصل)');
            ids.forEach((pid) => { const r = el('div', 'hx11-row'); r.appendChild(el('span', '', nameOf(pid))); r.appendChild(toggle(true, (v) => { if (v) chosen.add(pid); else chosen.delete(pid); })); b.appendChild(r); });
            b.appendChild(el('p', 'hx-muted', 'التواصل مباشر بين الأجهزة ومشفّر. يمكنك تبديل الكاميرا والمشاركة أثناء المكالمة.'));
            button(b, kind === 'screen' ? 'ابدأ المشاركة' : 'ابدأ المكالمة', () => { const w = g('hx-sheet'); if (w) w.remove(); start(kind, [...chosen]); }, kind === 'video' ? 'video' : kind === 'screen' ? 'monitor' : 'phone');
        });
    }
    function installHeader() {
        const hdr = document.querySelector('#chat-main-area > header .flex.items-center.gap-3'); if (!hdr || g('hx11-call-btn')) return;
        const first = hdr.firstChild;
        const vb = iconBtn('video', 'مكالمة فيديو', () => openStart('video'), 'hx11-hdr'); vb.id = 'hx11-call-btn';
        const pb = iconBtn('phone', 'مكالمة صوتية', () => openStart('audio'), 'hx11-hdr');
        hdr.insertBefore(vb, first); hdr.insertBefore(pb, first);
        if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) hdr.insertBefore(iconBtn('monitor', 'مشاركة الشاشة', () => { if (S.active) { openUI(); S.screenStream ? stopScreen() : shareScreen(); } else openStart('screen'); }, 'hx11-hdr'), first);
    }
    function init() { installHeader(); window.addEventListener('beforeunload', () => { try { hangup(); } catch (e) {} }); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
