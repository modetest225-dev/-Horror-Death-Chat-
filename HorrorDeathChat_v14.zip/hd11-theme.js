/* ============================================================
   HD Chat v11 — السمات والمظهر: قوالب جاهزة + تحكم كامل + إصلاح changeTheme
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, iconBtn, sheet, section, row, toggle, select, button } = HD;

    const PRESETS = {
        'theme-darkness': { n: 'ظلام دامس', bg: '#020204', panel: '#0c0a09', line: '#292524', text: '#a8a29e', acc: '#b91c1c' },
        'theme-ash': { n: 'رماد حزين', bg: '#0f1115', panel: '#171b23', line: '#2a303c', text: '#a6b0c0', acc: '#64748b' },
        'theme-blood': { n: 'دماء داكنة', bg: '#0a0202', panel: '#170606', line: '#4a1212', text: '#c9a3a3', acc: '#dc2626' },
        'theme-amoled': { n: 'أسود خالص (AMOLED)', bg: '#000000', panel: '#050505', line: '#1c1c1c', text: '#a3a3a3', acc: '#e5e5e5' },
        'theme-midnight': { n: 'منتصف الليل', bg: '#050816', panel: '#0b1226', line: '#1c2a52', text: '#9db0d8', acc: '#38bdf8' },
        'theme-forest': { n: 'غابة مظلمة', bg: '#030a05', panel: '#08140c', line: '#17381f', text: '#9cc3a5', acc: '#22c55e' },
        'theme-violet': { n: 'ليل بنفسجي', bg: '#07030d', panel: '#110820', line: '#35195e', text: '#b9a3d9', acc: '#a855f7' },
        'theme-amber': { n: 'شاشة قديمة', bg: '#080600', panel: '#120d00', line: '#3d2e00', text: '#d6b45a', acc: '#f59e0b' },
        'theme-rose': { n: 'وردي معتم', bg: '#0b030a', panel: '#180612', line: '#4d1239', text: '#d4a0c4', acc: '#ec4899' },
        'theme-paper': { n: 'ورق (فاتح)', bg: '#f1ece2', panel: '#fbf8f1', line: '#d9d0bd', text: '#44403c', acc: '#9f1239', light: true },
        'theme-contrast': { n: 'تباين عالٍ', bg: '#000000', panel: '#000000', line: '#ffffff', text: '#ffffff', acc: '#ffeb3b' }
    };
    const FONTS = { amiri: ["'Amiri', serif", 'أميري (الافتراضي)'], system: ["system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif", 'خط النظام'], mono: ["'Courier Prime', ui-monospace, monospace", 'آلة كاتبة'], cinzel: ["'Cinzel Decorative', 'Amiri', serif", 'زخرفي'], tahoma: ['Tahoma, Arial, sans-serif', 'تاهوما'] };
    const WALLS = { none: ['بدون', ''], fog: ['ضباب', 'radial-gradient(ellipse at 50% 0%, rgba(120,120,140,.14), transparent 60%), radial-gradient(ellipse at 20% 100%, rgba(80,80,100,.12), transparent 55%)'], blood: ['وهج دموي', 'radial-gradient(circle at 50% 120%, rgba(185,28,28,.28), transparent 60%)'], moon: ['ضوء قمر', 'radial-gradient(circle at 85% 8%, rgba(190,200,255,.16), transparent 30%)'], grid: ['شبكة', 'linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px)'], dots: ['نقاط', 'radial-gradient(rgba(255,255,255,.06) 1px, transparent 1px)'] };
    const ACCENTS = ['#b91c1c', '#dc2626', '#f97316', '#f59e0b', '#22c55e', '#14b8a6', '#38bdf8', '#6366f1', '#a855f7', '#ec4899', '#e5e5e5'];
    const K = { theme: 'hx11_theme', acc: 'hx11_acc', font: 'hx11_font', fs: 'hx11_fs2', rad: 'hx11_rad', dens: 'hx11_dens', wall: 'hx11_wall', motion: 'hx11_motion', glow: 'hx11_glow', bubbles: 'hx11_bub', sidebar: 'hx11_sbw' };
    const cur = () => ls.get(K.theme, 'theme-darkness');
    const hexOk = (v) => /^#[0-9a-f]{6}$/i.test(v);

    function apply() {
        const b = document.body, root = document.documentElement; if (!b) return;
        const id = PRESETS[cur()] ? cur() : 'theme-darkness', p = PRESETS[id];
        [...b.classList].filter((c) => c.startsWith('theme-')).forEach((c) => b.classList.remove(c)); b.classList.add(id);
        if (!b.classList.contains('app-shell')) b.classList.add('app-shell');
        const acc = hexOk(ls.get(K.acc, '')) ? ls.get(K.acc) : p.acc;
        const s = root.style; s.setProperty('--t-bg', p.bg); s.setProperty('--t-panel', p.panel); s.setProperty('--t-line', p.line); s.setProperty('--t-text', p.text); s.setProperty('--hx-accent', acc); s.setProperty('--t-acc', acc);
        s.setProperty('--bg-main', p.bg); s.setProperty('--bg-panel', p.panel); s.setProperty('--text-accent', acc); b.style.setProperty('--bg-main', p.bg); b.style.setProperty('--bg-panel', p.panel); b.style.setProperty('--text-accent', acc); b.style.setProperty('--border-color', p.line);
        b.classList.toggle('hx11-light', !!p.light); b.classList.toggle('hx11-themed', true);
        const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.content = p.bg;
        s.setProperty('--hx11-font', (FONTS[ls.get(K.font, 'amiri')] || FONTS.amiri)[0]);
        s.setProperty('--msg-fs', ls.get(K.fs, '13') + 'px'); s.setProperty('--hx11-rad', ls.get(K.rad, '10') + 'px');
        b.classList.toggle('hx11-compact', ls.get(K.dens, 'normal') === 'compact'); b.classList.toggle('hx11-roomy', ls.get(K.dens, 'normal') === 'roomy');
        b.classList.toggle('hx11-nomotion', ls.get(K.motion, '1') === '0'); b.classList.toggle('hx11-glow', ls.get(K.glow, '0') === '1'); b.classList.toggle('hx11-bub', ls.get(K.bubbles, '1') === '1');
        const w = (WALLS[ls.get(K.wall, 'none')] || WALLS.none)[1], main = g('chat-main-area');
        if (main && !(main.dataset.customBg)) { main.style.backgroundImage = w; main.style.backgroundSize = ls.get(K.wall, 'none') === 'grid' ? '28px 28px' : ls.get(K.wall, 'none') === 'dots' ? '18px 18px' : 'cover'; }
        s.setProperty('--hx11-sbw', ls.get(K.sidebar, '288') + 'px');
        document.querySelectorAll('#theme-selector, #theme-selector-settings').forEach((x) => { if (x.value !== id) x.value = id; });
    }
    /* يستبدل الدالة القديمة التي كانت تحذف كلاسات الجسم وتكسر التخطيط */
    changeTheme = function (theme) { if (PRESETS[theme]) { ls.set(K.theme, theme); apply(); } };
    const _wp = typeof changeChatWallpaper === 'function' ? changeChatWallpaper : null;
    changeChatWallpaper = function () {
        const inp = g('chat-bg-url'), url = inp ? inp.value.trim() : '';
        if (!url) { const m = g('chat-main-area'); if (m) { delete m.dataset.customBg; m.style.backgroundImage = ''; } apply(); return; }
        if (!/^https:\/\/[^\s'"()<>]+$/i.test(url)) { note('الرابط يجب أن يبدأ بـ https:// ولا يحتوي رموزاً غريبة'); return; }
        const m = g('chat-main-area'); if (m) { m.dataset.customBg = '1'; m.style.backgroundImage = "url('" + url + "')"; m.style.backgroundSize = 'cover'; } note('تم تطبيق الخلفية');
    };

    function fillSelects() {
        document.querySelectorAll('#theme-selector, #theme-selector-settings').forEach((s) => {
            if (s.dataset.hx11) return; s.dataset.hx11 = '1'; s.textContent = '';
            Object.entries(PRESETS).forEach(([id, p]) => { const o = el('option', '', p.n); o.value = id; s.appendChild(o); }); s.value = cur();
        });
    }

    function swatch(id, p) {
        const b = el('button', 'hx11-theme' + (cur() === id ? ' on' : '')); b.type = 'button'; b.setAttribute('aria-label', p.n); b.style.background = p.bg; b.style.borderColor = p.line;
        const pn = el('i'); pn.style.background = p.panel; pn.style.borderColor = p.line; const ac = el('u'); ac.style.background = p.acc; const t = el('span', '', p.n); t.style.color = p.text;
        b.appendChild(pn); b.appendChild(ac); b.appendChild(t); return b;
    }
    function openTheme() {
        sheet('المظهر والسمات', (box) => {
            section(box, 'السمات الجاهزة');
            const grid = el('div', 'hx11-themes'); Object.entries(PRESETS).forEach(([id, p]) => { const b = swatch(id, p); b.onclick = () => { ls.set(K.theme, id); ls.del(K.acc); apply(); grid.querySelectorAll('.hx11-theme').forEach((x) => x.classList.remove('on')); b.classList.add('on'); accRow.refresh && accRow.refresh(); }; grid.appendChild(b); }); box.appendChild(grid);
            section(box, 'لون التمييز');
            const accRow = el('div', 'hx11-accs'); const draw = () => { accRow.textContent = ''; const now = (getComputedStyle(document.documentElement).getPropertyValue('--hx-accent') || '').trim().toLowerCase();
                ACCENTS.forEach((c) => { const b = el('button', 'hx11-acc' + (now === c ? ' on' : '')); b.type = 'button'; b.style.background = c; b.setAttribute('aria-label', c); b.onclick = () => { ls.set(K.acc, c); apply(); draw(); }; accRow.appendChild(b); });
                const ci = el('input'); ci.type = 'color'; ci.value = hexOk(now) ? now : '#b91c1c'; ci.className = 'hx11-colorin'; ci.title = 'لون مخصص'; ci.oninput = () => { ls.set(K.acc, ci.value); apply(); }; accRow.appendChild(ci); }; accRow.refresh = draw; draw(); box.appendChild(accRow);
            section(box, 'الخط والحجم');
            row(box, 'نوع الخط', select(Object.entries(FONTS).map(([k, v]) => [k, v[1]]), ls.get(K.font, 'amiri'), (v) => { ls.set(K.font, v); apply(); }));
            const fs = el('input'); fs.type = 'range'; fs.min = 11; fs.max = 22; fs.value = ls.get(K.fs, '13'); fs.oninput = () => { ls.set(K.fs, fs.value); apply(); }; row(box, 'حجم خط الرسائل', fs);
            row(box, 'الكثافة', select([['compact', 'مضغوطة'], ['normal', 'عادية'], ['roomy', 'مريحة']], ls.get(K.dens, 'normal'), (v) => { ls.set(K.dens, v); apply(); }));
            const rd = el('input'); rd.type = 'range'; rd.min = 0; rd.max = 22; rd.value = ls.get(K.rad, '10'); rd.oninput = () => { ls.set(K.rad, rd.value); apply(); }; row(box, 'استدارة الزوايا', rd);
            section(box, 'الخلفية والتأثيرات');
            row(box, 'خلفية المحادثة', select(Object.entries(WALLS).map(([k, v]) => [k, v[0]]), ls.get(K.wall, 'none'), (v) => { ls.set(K.wall, v); const m = g('chat-main-area'); if (m) delete m.dataset.customBg; apply(); }));
            row(box, 'توهج اللون المميز', toggle(ls.get(K.glow, '0') === '1', (v) => { ls.set(K.glow, v ? '1' : '0'); apply(); }));
            row(box, 'فقاعات الرسائل المحسّنة', toggle(ls.get(K.bubbles, '1') === '1', (v) => { ls.set(K.bubbles, v ? '1' : '0'); apply(); }));
            row(box, 'الحركات والانتقالات', toggle(ls.get(K.motion, '1') === '1', (v) => { ls.set(K.motion, v ? '1' : '0'); apply(); }), 'أوقفها لتوفير البطارية أو إن كانت تزعجك.');
            button(box, 'إعادة الضبط الافتراضي', () => { Object.values(K).forEach((k) => ls.del(k)); apply(); const w = g('hx-sheet'); if (w) w.remove(); note('تمت إعادة المظهر الافتراضي'); }, 'flip');
        }, { wide: true });
    }
    HD.openTheme = openTheme; HD.applyTheme = apply;

    function installHeader() {
        const hdr = document.querySelector('#chat-main-area > header .flex.items-center.gap-3'); if (!hdr || g('hx11-theme-btn')) return;
        const b = iconBtn('palette', 'المظهر والسمات', openTheme, 'hx11-hdr'); b.id = 'hx11-theme-btn'; hdr.insertBefore(b, hdr.firstChild);
    }
    function init() { apply(); fillSelects(); installHeader(); if (window.matchMedia) matchMedia('(prefers-reduced-motion: reduce)').addEventListener && matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', apply); if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches && ls.get(K.motion, '') === '') ls.set(K.motion, '0'), apply(); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
