/* ============================================================
   HD Chat v11 — خيارات الكتابة: تنسيق، أنماط حروف، قوالب، إملاء صوتي،
   إرسال مؤجل، اقتراح الأوامر والإشارات، سطور متعددة.
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, iconBtn, sheet, section, row, toggle, select, button } = HD;
    const inp = () => g('msg-input');
    const grapheme = (s) => Array.from(String(s));

    /* ============ محوّلات الحروف (دوال نقية قابلة للاختبار) ============ */
    const cp = (n) => String.fromCodePoint(n);
    function mapLatin(s, upper0, lower0, digit0) {
        return grapheme(s).map((ch) => {
            const c = ch.codePointAt(0);
            if (c >= 65 && c <= 90 && upper0) return cp(upper0 + c - 65);
            if (c >= 97 && c <= 122 && lower0) return cp(lower0 + c - 97);
            if (c >= 48 && c <= 57 && digit0) return cp(digit0 + c - 48);
            return ch;
        }).join('');
    }
    const FLIP = { a: 'ɐ', b: 'q', c: 'ɔ', d: 'p', e: 'ǝ', f: 'ɟ', g: 'ƃ', h: 'ɥ', i: 'ᴉ', j: 'ɾ', k: 'ʞ', m: 'ɯ', n: 'u', p: 'd', q: 'b', r: 'ɹ', t: 'ʇ', u: 'n', v: 'ʌ', w: 'ʍ', y: 'ʎ', A: '∀', C: 'Ɔ', D: 'ᗡ', E: 'Ǝ', F: 'Ⅎ', G: '⅁', J: 'ſ', L: '˥', M: 'W', P: 'Ԁ', T: '⊥', U: '∩', V: 'Λ', W: 'M', Y: '⅄', '1': 'Ɩ', '2': 'ᄅ', '3': 'Ɛ', '4': 'ㄣ', '5': 'ϛ', '6': '9', '7': 'ㄥ', '9': '6', '?': '¿', '!': '¡', '.': '˙', ',': '\'', '(': ')', ')': '(', '[': ']', ']': '[', '<': '>', '>': '<' };
    const SMALLCAPS = { a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ', i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ', s: 'ꜱ', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ' };
    const ZUP = ['\u030d', '\u030e', '\u0304', '\u0305', '\u033f', '\u0311', '\u0306', '\u0310', '\u0352', '\u0357', '\u0351', '\u0307', '\u0308', '\u030a', '\u0342', '\u0343', '\u0344', '\u034a', '\u034b', '\u034c', '\u0303', '\u0302', '\u030c', '\u0350', '\u0300', '\u0301', '\u030b', '\u030f', '\u0312', '\u0313', '\u0314', '\u033d', '\u0309', '\u0363'];
    const ZMID = ['\u0315', '\u031b', '\u0340', '\u0341', '\u0358', '\u0321', '\u0322', '\u0327', '\u0328', '\u0334', '\u0335', '\u0336', '\u034f', '\u035c', '\u035d', '\u035e', '\u035f', '\u0360', '\u0362', '\u0338', '\u0337', '\u0361', '\u0489'];
    const ZDN = ['\u0316', '\u0317', '\u0318', '\u0319', '\u031c', '\u031d', '\u031e', '\u031f', '\u0320', '\u0324', '\u0325', '\u0326', '\u0329', '\u032a', '\u032b', '\u032c', '\u032d', '\u032e', '\u032f', '\u0330', '\u0331', '\u0332', '\u0333', '\u0339', '\u033a', '\u033b', '\u033c', '\u0345', '\u0347', '\u0348', '\u0349', '\u034d', '\u034e', '\u0353', '\u0354', '\u0355', '\u0356', '\u0359', '\u035a', '\u0323'];
    const rnd = (n) => { const b = new Uint32Array(1); (window.crypto || { getRandomValues: (a) => { a[0] = Math.random() * 4294967296; return a; } }).getRandomValues(b); return b[0] % n; };
    const pickFrom = (a) => a[rnd(a.length)];
    function zalgo(s, level) {
        const [u, m, d] = level === 1 ? [1, 0, 1] : level === 3 ? [8, 3, 8] : [3, 1, 3];
        return grapheme(s).map((ch) => { if (/\s/.test(ch)) return ch; let o = ch; for (let i = 0; i < 1 + rnd(u); i++) o += pickFrom(ZUP); for (let i = 0; i < rnd(m + 1); i++) o += pickFrom(ZMID); for (let i = 0; i < 1 + rnd(d); i++) o += pickFrom(ZDN); return o; }).join('');
    }
    const NOJOIN = 'ادذرزوؤءأإآةى';
    function kashida(s, n) {
        const A = /[\u0621-\u064A]/, out = [], g2 = grapheme(s), rep = '\u0640'.repeat(n || 2);
        for (let i = 0; i < g2.length; i++) { out.push(g2[i]); const a = g2[i], b = g2[i + 1]; if (b && A.test(a) && A.test(b) && !NOJOIN.includes(a)) out.push(rep); }
        return out.join('');
    }
    const stripTashkeel = (s) => s.replace(/[\u064B-\u0652\u0670\u0640]/g, '');
    const toIndic = (s) => s.replace(/[0-9]/g, (d) => '٠١٢٣٤٥٦٧٨٩'[+d]);
    const toWestern = (s) => s.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
    const combine = (s, mark) => grapheme(s).map((ch) => /\s/.test(ch) ? ch : ch + mark).join('');
    const STYLES = [
        ['zalgo', 'مرعب (تشويش)', (s) => zalgo(s, 2), 'هنا يسكن الظلام'],
        ['zalgo3', 'مرعب جداً', (s) => zalgo(s, 3)],
        ['gothic', 'قوطي', (s) => mapLatin(s, 0x1D56C, 0x1D586, 0)],
        ['script', 'خط مخطوط', (s) => mapLatin(s, 0x1D4D0, 0x1D4EA, 0)],
        ['bold', 'عريض', (s) => mapLatin(s, 0x1D5D4, 0x1D5EE, 0x1D7EC)],
        ['mono', 'آلة كاتبة', (s) => mapLatin(s, 0x1D670, 0x1D68A, 0x1D7F6)],
        ['bubble', 'دوائر', (s) => grapheme(s).map((ch) => { const c = ch.codePointAt(0); if (c >= 65 && c <= 90) return cp(0x24B6 + c - 65); if (c >= 97 && c <= 122) return cp(0x24D0 + c - 97); if (c >= 49 && c <= 57) return cp(0x2460 + c - 49); if (c === 48) return '⓪'; return ch; }).join('')],
        ['smallcaps', 'أحرف صغيرة كبيرة', (s) => grapheme(s).map((ch) => SMALLCAPS[ch] || ch).join('')],
        ['flip', 'مقلوب', (s) => grapheme(s).map((ch) => FLIP[ch] || ch).reverse().join('')],
        ['reverse', 'عكس النص', (s) => grapheme(s).reverse().join('')],
        ['kashida', 'تطويل عربي', (s) => kashida(s, 2)],
        ['spaced', 'متباعد', (s) => grapheme(s).join(' ')],
        ['under', 'خط تحته', (s) => combine(s, '\u0332')],
        ['strike', 'يتوسطه خط', (s) => combine(s, '\u0336')],
        ['notash', 'إزالة التشكيل والتطويل', stripTashkeel],
        ['indic', 'أرقام هندية ٠١٢', toIndic],
        ['west', 'أرقام إنجليزية 012', toWestern]
    ];
    const STYLE_MAP = Object.fromEntries(STYLES.map(([id, , fn]) => [id, fn]));
    const CMD_ALIAS = { zalgo: 'zalgo', gothic: 'gothic', flip: 'flip', bubble: 'bubble', mono: 'mono', script: 'script', kashida: 'kashida', spaced: 'spaced', reverse: 'reverse', under: 'under', strike: 'strike', smallcaps: 'smallcaps' };
    HD.text = { STYLES, STYLE_MAP, zalgo, kashida, mapLatin, stripTashkeel, toIndic, toWestern };

    /* ============ مساعدات الإدخال ============ */
    function grow() { const i = inp(); if (!i) return; i.style.height = 'auto'; i.style.height = Math.min(i.scrollHeight + 2, 150) + 'px'; counter(); }
    function setVal(v, a, b) { const i = inp(); i.value = v; if (a != null) i.setSelectionRange(a, b == null ? a : b); i.focus(); i.dispatchEvent(new Event('input', { bubbles: true })); grow(); }
    function wrapSel(l, r) {
        const i = inp(); if (!i) return; const a = i.selectionStart, b = i.selectionEnd, v = i.value, sel = v.slice(a, b);
        if (r === undefined) r = l;
        if (sel && v.slice(a - l.length, a) === l && v.slice(b, b + r.length) === r) { setVal(v.slice(0, a - l.length) + sel + v.slice(b + r.length), a - l.length, b - l.length); return; }
        setVal(v.slice(0, a) + l + sel + r + v.slice(b), sel ? a + l.length : a + l.length, sel ? b + l.length : a + l.length);
    }
    function quoteSel() {
        const i = inp(); const a = i.selectionStart, b = i.selectionEnd, v = i.value, s = v.lastIndexOf('\n', a - 1) + 1, e0 = v.indexOf('\n', b), e = e0 < 0 ? v.length : e0;
        const block = v.slice(s, e), all = block.split('\n').every((x) => x.startsWith('> ')), out = block.split('\n').map((x) => all ? x.slice(2) : '> ' + x).join('\n');
        setVal(v.slice(0, s) + out + v.slice(e), s, s + out.length);
    }
    function applyStyle(id) {
        const i = inp(), fn = STYLE_MAP[id]; if (!fn || !i) return; const a = i.selectionStart, b = i.selectionEnd; S.undo = i.value;
        if (a !== b) setVal(i.value.slice(0, a) + fn(i.value.slice(a, b)) + i.value.slice(b), a, a + fn(i.value.slice(a, b)).length); else setVal(fn(i.value));
    }
    const S = { undo: null, rec: null, sched: [], sug: null };

    /* ============ عرض الرسائل: مائل _x_ واقتباس > ============ */
    const ITALIC = /(^|[\s(\[{«"'])_([^_\n]{1,200})_(?=$|[\s.,!?؟،:;)\]}»"'])/g;
    function decorate(card) {
        if (!card.classList || !card.classList.contains('msg-card') || card.dataset.hx11) return; card.dataset.hx11 = '1';
        const body = card.querySelector('.msg-body'); if (!body) return; body.setAttribute('dir', 'auto');
        const w = document.createTreeWalker(body, NodeFilter.SHOW_TEXT, { acceptNode: (n) => n.parentNode.closest('a,code,.hx-spoiler,.hx11-q,i') && n.parentNode !== body ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
        const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
        nodes.forEach((n) => {
            let t = n.nodeValue; if (!t || (t.indexOf('_') < 0 && t.indexOf('> ') < 0)) return;
            const frag = document.createDocumentFragment(); let changed = false;
            const lines = t.split('\n');
            lines.forEach((ln, idx) => {
                const last = idx === lines.length - 1;
                if (ln.startsWith('> ') && ln.length > 2) { const q = el('span', 'hx11-q'); italicInto(q, ln.slice(2)); frag.appendChild(q); changed = true; }
                else { italicInto(frag, ln + (last ? '' : '\n')); }
            });
            function italicInto(parent, text) {
                let m, lastI = 0; ITALIC.lastIndex = 0; let any = false;
                while ((m = ITALIC.exec(text))) { any = true; if (m.index + m[1].length > lastI) parent.appendChild(document.createTextNode(text.slice(lastI, m.index) + m[1])); const it = el('i', 'hx11-it', m[2]); parent.appendChild(it); lastI = m.index + m[0].length; changed = true; }
                if (lastI < text.length) parent.appendChild(document.createTextNode(text.slice(lastI)));
                if (!any && lastI === 0 && !text) return;
            }
            if (changed) n.parentNode.replaceChild(frag, n);
        });
    }

    /* ============ القوائم ============ */
    function openStyles() {
        const i = inp(); const a = i.selectionStart, b = i.selectionEnd, sample = ((a !== b ? i.value.slice(a, b) : i.value) || 'Horror Death رعب').replace(/\n/g, ' ').slice(0, 36);
        sheet('أنماط الكتابة', (box) => {
            box.appendChild(el('p', 'hx-muted', a !== b ? 'سيُطبَّق النمط على النص المحدد فقط.' : 'سيُطبَّق النمط على كل ما كتبته. حدّد جزءاً منه لتغيير الجزء فقط.'));
            const grid = el('div', 'hx11-styles');
            STYLES.forEach(([id, name, fn]) => {
                const c = el('button', 'hx11-style'); c.type = 'button'; c.appendChild(el('small', '', name)); c.appendChild(el('span', '', fn(sample)));
                c.onclick = () => { const w = g('hx-sheet'); if (w) w.remove(); applyStyle(id); }; grid.appendChild(c);
            });
            box.appendChild(grid);
            if (S.undo != null) button(box, 'تراجع عن آخر نمط', () => { const w = g('hx-sheet'); if (w) w.remove(); setVal(S.undo); S.undo = null; }, 'flip');
            box.appendChild(el('p', 'hx-muted', 'اختصارات: /zalgo نص  ·  /gothic نص  ·  /flip نص  ·  /bubble نص  ·  /mono نص  ·  /kashida نص'));
        }, { wide: true });
    }
    function tplList() { try { const a = JSON.parse(ls.get('hx11_tpl', '[]')); return Array.isArray(a) ? a.filter((x) => typeof x === 'string').slice(0, 30) : []; } catch (e) { return []; } }
    function openTemplates() {
        sheet('القوالب السريعة', (box) => {
            const listEl = el('div'); const draw = () => {
                listEl.textContent = ''; const t = tplList(); if (!t.length) listEl.appendChild(el('p', 'hx-muted', 'لا توجد قوالب بعد. احفظ العبارات التي تكررها.'));
                t.forEach((x, idx) => { const r = el('div', 'hx11-row tpl'); const ins = el('button', 'hx11-tplbtn', x); ins.type = 'button'; ins.onclick = () => { const w = g('hx-sheet'); if (w) w.remove(); const i = inp(); const a = i.selectionStart; setVal(i.value.slice(0, a) + x + i.value.slice(i.selectionEnd), a + x.length); }; r.appendChild(ins); r.appendChild(iconBtn('trash', 'حذف', () => { const n = tplList(); n.splice(idx, 1); ls.set('hx11_tpl', JSON.stringify(n)); draw(); }, 'sm')); listEl.appendChild(r); });
            };
            const f = el('textarea', 'hx-input hx11-ta'); f.rows = 2; f.maxLength = 300; f.placeholder = 'اكتب قالباً جديداً (حتى 300 حرف)';
            box.appendChild(f); button(box, 'حفظ القالب', () => { const v = f.value.trim(); if (!v) return; const n = tplList(); if (n.length >= 30) { note('وصلت للحد الأقصى (30 قالباً)'); return; } n.unshift(v); ls.set('hx11_tpl', JSON.stringify(n)); f.value = ''; draw(); }, 'plus');
            const cur = inp().value.trim(); if (cur) button(box, 'احفظ ما كتبته الآن كقالب', () => { const n = tplList(); n.unshift(cur.slice(0, 300)); ls.set('hx11_tpl', JSON.stringify(n.slice(0, 30))); draw(); }, 'template');
            section(box, 'قوالبك'); box.appendChild(listEl); draw();
        });
    }
    function openSchedule() {
        sheet('إرسال مؤجل', (box) => {
            const txt = inp().value.trim();
            box.appendChild(el('p', 'hx-muted', 'تُرسل الرسالة تلقائياً بعد المدة المحددة. يجب أن تبقى هذه الصفحة مفتوحة حتى يحين الوقت.'));
            const ta = el('textarea', 'hx-input hx11-ta'); ta.rows = 3; ta.value = txt; ta.placeholder = 'نص الرسالة المؤجلة'; box.appendChild(ta);
            const sel = select([['10', 'بعد 10 ثوانٍ'], ['60', 'بعد دقيقة'], ['300', 'بعد 5 دقائق'], ['900', 'بعد 15 دقيقة'], ['1800', 'بعد 30 دقيقة'], ['3600', 'بعد ساعة']], '60', () => {}); box.appendChild(sel);
            button(box, 'جدولة الإرسال', () => {
                const v = ta.value.trim(); if (!v) { note('اكتب نص الرسالة أولاً'); return; } if (S.sched.length >= 10) { note('الحد الأقصى 10 رسائل مؤجلة'); return; }
                const secs = parseInt(sel.value) || 60, item = { id: Date.now() + Math.random(), text: v.slice(0, 1000), at: Date.now() + secs * 1000 };
                item.timer = setTimeout(() => { S.sched = S.sched.filter((x) => x !== item); sendNow(item.text); }, secs * 1000); S.sched.push(item);
                if (ta.value.trim() === inp().value.trim()) setVal(''); const w = g('hx-sheet'); if (w) w.remove(); note('تمت الجدولة');
            }, 'clock');
            if (S.sched.length) { section(box, 'مؤجلة الآن'); S.sched.forEach((it) => { const r = el('div', 'hx11-row'); r.appendChild(el('span', '', it.text.slice(0, 40) + ' — ' + new Date(it.at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }))); r.appendChild(iconBtn('trash', 'إلغاء', () => { clearTimeout(it.timer); S.sched = S.sched.filter((x) => x !== it); r.remove(); }, 'sm')); box.appendChild(r); }); }
        });
    }
    function sendNow(text) { const i = inp(), keep = i.value; i.value = text; try { sendBroadcastMessage(); } catch (e) {} i.value = keep; grow(); }
    function openWriteSettings() {
        sheet('إعدادات الكتابة', (box) => {
            row(box, 'Enter يضيف سطراً جديداً', toggle(ls.get('hx11_enternl', matchMedia('(pointer:coarse)').matches ? '1' : '0') === '1', (v) => ls.set('hx11_enternl', v ? '1' : '0')), 'عند التفعيل: الإرسال بزر «بث» أو Ctrl+Enter.');
            row(box, 'التدقيق الإملائي', toggle(ls.get('hx11_spell', '1') === '1', (v) => { ls.set('hx11_spell', v ? '1' : '0'); inp().spellcheck = v; }));
            row(box, 'لغة الإملاء الصوتي', select([['ar-EG', 'العربية (مصر)'], ['ar-SA', 'العربية (السعودية)'], ['ar-AE', 'العربية (الإمارات)'], ['en-US', 'English (US)']], ls.get('hx11_sr', 'ar-EG'), (v) => ls.set('hx11_sr', v)));
            row(box, 'شريط التنسيق ظاهر', toggle(ls.get('hx11_fmt', '1') === '1', (v) => { ls.set('hx11_fmt', v ? '1' : '0'); showFmt(); }));
            section(box, 'صيغ التنسيق');
            ['*غامق*', '_مائل_', '`كود`', '~مشطوب~', '||مخفي||', '> اقتباس (في بداية السطر)', '@اسم لإشارة شخص', ':skull: :ghost: إيموجي سريع'].forEach((t) => box.appendChild(el('div', 'hx11-code', t)));
        });
    }

    /* ============ الإملاء الصوتي ============ */
    function dictate(btn) {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) { note('الإملاء الصوتي غير مدعوم في هذا المتصفح (يعمل في Chrome وSafari).'); return; }
        if (S.rec) { try { S.rec.stop(); } catch (e) {} return; }
        const i = inp(), base = i.value; let fin = ''; const r = new SR(); r.lang = ls.get('hx11_sr', 'ar-EG'); r.interimResults = true; r.continuous = true;
        r.onresult = (e) => { let it = ''; for (let k = e.resultIndex; k < e.results.length; k++) { const x = e.results[k]; if (x.isFinal) fin += x[0].transcript + ' '; else it += x[0].transcript; } i.value = (base + (base && !/\s$/.test(base) ? ' ' : '') + fin + it).trimStart(); grow(); };
        r.onerror = (e) => { if (e.error !== 'no-speech' && e.error !== 'aborted') note('الإملاء: ' + (e.error === 'not-allowed' ? 'لم تمنح إذن الميكروفون' : e.error)); };
        r.onend = () => { S.rec = null; btn.classList.remove('on'); i.dispatchEvent(new Event('input', { bubbles: true })); };
        try { r.start(); S.rec = r; btn.classList.add('on'); note('تحدّث الآن...'); } catch (e) { note('تعذّر بدء الإملاء'); }
    }

    /* ============ اقتراحات الأوامر والإشارات ============ */
    const CMDS = [['/roll', 'رمي نرد'], ['/flip', 'ملك أو كتابة'], ['/me', 'رسالة حدث'], ['/shrug', 'تجاهل'], ['/boo', 'رعشة للجميع'], ['/users', 'عرض المتصلين'], ['/clear', 'مسح الشاشة'], ['/poll', 'استطلاع: سؤال | خيار | خيار'], ['/pin', 'تثبيت (للمالك)'], ['/8ball', 'كرة الأسئلة'], ['/truth', 'سؤال صراحة'], ['/dare', 'تحدٍّ'], ['/scary', 'جملة مرعبة'], ['/burn', 'رسالة تحترق: /burn 30 نص'], ['/zalgo', 'نص مرعب'], ['/gothic', 'خط قوطي'], ['/flip', 'نص مقلوب'], ['/bubble', 'دوائر'], ['/mono', 'آلة كاتبة'], ['/script', 'مخطوط'], ['/kashida', 'تطويل'], ['/spaced', 'متباعد'], ['/reverse', 'عكس'], ['/help', 'المساعدة']];
    function suggest() {
        const i = inp(), host = g('input-area'); if (!i || !host) return; const v = i.value, caret = i.selectionStart; let items = [], kind = '';
        const m = v.slice(0, caret).match(/(^|\s)(@[\w\u0600-\u06FF]*)$/);
        if (/^\/[^\s]*$/.test(v)) { kind = 'cmd'; items = CMDS.filter((c, idx, arr) => c[0].startsWith(v.toLowerCase()) && arr.findIndex((x) => x[0] === c[0]) === idx).slice(0, 6).map(([c, d]) => [c, c + '  —  ' + d]); }
        else if (m) { kind = 'men'; const q = m[2].slice(1).toLowerCase(); items = Object.keys(peerNames || {}).filter((p) => activeConnections[p]).map((p) => peerNames[p]).filter((n) => n.toLowerCase().startsWith(q)).slice(0, 6).map((n) => ['@' + n, '@' + n]); }
        let box = g('hx11-sug'); if (!items.length) { if (box) box.remove(); return; }
        if (!box) { box = el('div', 'hx11-sug'); box.id = 'hx11-sug'; host.appendChild(box); } box.textContent = '';
        items.forEach(([ins, label]) => { const b = el('button', '', label); b.type = 'button'; b.onmousedown = (e) => e.preventDefault(); b.onclick = () => { if (kind === 'cmd') setVal(ins + ' ', ins.length + 1); else { const st = v.slice(0, caret).replace(/@[\w\u0600-\u06FF]*$/, ''); setVal(st + ins + ' ' + v.slice(caret), (st + ins + ' ').length); } box.remove(); }; box.appendChild(b); });
    }

    /* ============ إرسال: أوامر الأنماط ============ */
    const _s = sendBroadcastMessage;
    sendBroadcastMessage = function () {
        const i = inp(); if (i && currentUser) { const m = i.value.trim().match(/^\/(\w+)\s+([\s\S]+)$/); if (m && CMD_ALIAS[m[1].toLowerCase()]) { const id = CMD_ALIAS[m[1].toLowerCase()], fn = STYLE_MAP[id] || STYLE_MAP[id + '3']; if (fn) i.value = fn(m[2]); } }
        _s(); setTimeout(grow, 0);
    };

    /* ============ تركيب الواجهة ============ */
    function counter() { const c = g('hx11-count'), i = inp(); if (!c || !i) return; const n = i.value.length; c.textContent = n > 700 ? n + '/1000' : ''; c.classList.toggle('warn', n > 950); }
    function showFmt() { const f = g('hx11-fmt'); if (f) f.style.display = ls.get('hx11_fmt', '1') === '1' ? '' : 'none'; }
    function build() {
        const area = g('input-area'), i = inp(); if (!area || !i) return false;
        if (g('hx11-fmt')) return true;
        i.setAttribute('dir', 'auto'); i.spellcheck = ls.get('hx11_spell', '1') === '1'; i.setAttribute('enterkeyhint', 'send'); i.setAttribute('autocomplete', 'off');
        const f = el('div', 'hx11-fmt'); f.id = 'hx11-fmt'; f.setAttribute('role', 'toolbar'); f.setAttribute('aria-label', 'أدوات الكتابة');
        const add = (ico, ttl, fn) => { const b = iconBtn(ico, ttl, fn, 'fm'); b.onmousedown = (e) => e.preventDefault(); f.appendChild(b); return b; };
        add('bold', 'غامق *نص*', () => wrapSel('*')); add('italic', 'مائل _نص_', () => wrapSel('_')); add('code', 'كود `نص`', () => wrapSel('`')); add('strike', 'مشطوب ~نص~', () => wrapSel('~'));
        add('eyeOff', 'نص مخفي ||نص||', () => wrapSel('||')); add('quote', 'اقتباس', quoteSel);
        f.appendChild(el('span', 'sep')); add('wand', 'أنماط الكتابة (مرعب، قوطي، مقلوب…)', openStyles); add('template', 'القوالب السريعة', openTemplates);
        const mic = add('mic2', 'إملاء صوتي', () => dictate(mic)); add('clock', 'إرسال مؤجل', openSchedule); add('type', 'إعدادات الكتابة', openWriteSettings);
        const c = el('span', 'hx11-count'); c.id = 'hx11-count'; f.appendChild(c);
        const bar = g('hx-bar'); const rowEl = i.parentElement; area.insertBefore(f, rowEl);
        i.addEventListener('input', () => { grow(); suggest(); }); i.addEventListener('click', suggest); i.addEventListener('blur', () => setTimeout(() => { const b = g('hx11-sug'); if (b) b.remove(); }, 200));
        i.addEventListener('keyup', (e) => { if (['ArrowLeft', 'ArrowRight', 'Backspace'].includes(e.key)) suggest(); });
        /* لا تتعارض مع معالج Enter القديم: نعترض في مرحلة الالتقاط */
        document.addEventListener('keydown', (e) => {
            if (e.target !== i || e.key !== 'Enter' || e.isComposing) return;
            const nl = ls.get('hx11_enternl', matchMedia('(pointer:coarse)').matches ? '1' : '0') === '1';
            if (nl) { e.stopImmediatePropagation(); if (e.ctrlKey || e.metaKey) { e.preventDefault(); sendBroadcastMessage(); } }
        }, true);
        showFmt(); grow(); return true;
    }
    function svgBar() {
        const bar = g('hx-bar'); if (!bar) return false; const map = { 'إيموجي': 'smile', 'بحث': 'search', 'الأدوات': 'sliders', 'المزيد': 'plus', 'أدوات إضافية': 'grid', 'المتصلون': 'users' };
        let done = 0;
        bar.querySelectorAll('.hx-tb').forEach((b) => {
            const n = map[b.title]; if (!n || b.dataset.hx11) return; b.dataset.hx11 = '1'; const old = b.title; b.textContent = ''; b.classList.add('hx11-tb'); b.appendChild(icon(n, 18)); b.setAttribute('aria-label', old);
            if (old === 'المتصلون') { b.title = 'المتصلون الآن'; const bd = el('span', 'hx11-badge-n'); bd.id = 'hx11-users-n'; b.appendChild(bd); }
            done++;
        });
        const bd = g('hx11-users-n'); if (bd) { const n = Object.keys(activeConnections || {}).length; bd.textContent = n ? String(n + 1) : ''; }
        return done > 0;
    }
    HD.write = { wrapSel, quoteSel, openStyles, openTemplates, openSchedule, dictate, openWriteSettings, applyStyle, setVal, grow };
    function init() {
        let tries = 0; const iv = setInterval(() => { tries++; const ok = build(); svgBar(); if ((ok && g('hx-bar') && g('hx-bar').querySelectorAll('.hx-tb').length >= 5 && tries > 3) || tries > 100) { clearInterval(iv); } }, 300);
        setInterval(svgBar, 2500);
        const box = g('chat-box'); if (box) new MutationObserver((ms) => ms.forEach((r) => r.addedNodes.forEach(decorate))).observe(box, { childList: true });
        else setTimeout(init, 400);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
