/* ============================================================
   HD Chat v11 — نظام الحماية المتقدّم
   هوية موقَّعة + تثبيت الهوية (TOFU) + موافقة على الغرباء + حظر +
   حماية الأسماء من الانتحال + فاحص الروابط + حماية الملفات +
   رسائل ذاتية الحذف + عنوان IP + مركز أمان بدرجة حماية.
   ============================================================ */
(function () {
    'use strict';
    const HD = window.HD11; if (!HD) return;
    const { g, el, ls, note, icon, iconBtn, sheet, section, row, toggle, select, button } = HD;
    const jget = (k, d) => { try { const v = JSON.parse(ls.get(k, '')); return v == null ? d : v; } catch (e) { return d; } };
    const jset = (k, v) => ls.set(k, JSON.stringify(v));

    /* ── مستويات الحماية الجاهزة ── */
    const LV = {
        std: { n: 'متوازن', d: 'حماية قوية دون إزعاج: تشفير طرفي، كشف انتحال، فحص الروابط والملفات.', requireId: 0, approve: 0, blockChanged: 0, attVerified: 0, callVerified: 0, link: 1, att: 1, name: 1, blur: 0, idle: 0, disappear: 0 },
        high: { n: 'عالٍ', d: 'يطلب هوية موقَّعة، ويسألك قبل قبول غريب، ويمنع تغيّر الهوية صامتاً.', requireId: 1, approve: 1, blockChanged: 1, attVerified: 0, callVerified: 0, link: 1, att: 1, name: 1, blur: 1, idle: 5, disappear: 0 },
        max: { n: 'أقصى', d: 'للحالات الحساسة: موافقة في كل جلسة، لا ملفات ولا مكالمات إلا ممن تحققت منه، ورسائل تُمحى بعد 15 دقيقة.', requireId: 1, approve: 2, blockChanged: 1, attVerified: 1, callVerified: 1, link: 1, att: 1, name: 1, blur: 1, idle: 5, disappear: 15 }
    };
    const level = () => (LV[ls.get('hx11_g_level', 'std')] ? ls.get('hx11_g_level', 'std') : (ls.get('hx11_g_level', '') === 'custom' ? 'custom' : 'std'));
    const gv = (k) => { const v = ls.get('hx11_g_' + k, ''); if (v !== '') return +v; const base = LV[level()] || LV.std; return base[k]; };
    const gset = (k, v) => { ls.set('hx11_g_' + k, String(v)); ls.set('hx11_g_level', 'custom'); };
    function applyLevel(id) {
        const c = LV[id]; ['requireId', 'approve', 'blockChanged', 'attVerified', 'callVerified', 'link', 'att', 'name', 'blur', 'idle', 'disappear'].forEach((k) => ls.set('hx11_g_' + k, String(c[k])));
        ls.set('hx11_g_level', id); ls.set('hx11_strict', '1'); ls.set('hx11_blur', c.blur ? '1' : '0'); ls.set('hx11_idle', String(c.idle)); document.body.classList.toggle('hx11-privacy', !!c.blur); armDisappear();
    }

    /* ── أسماء آمنة ضد الانتحال (bidi / أحرف غير مرئية / تطبيع) ── */
    const BAD = /[\u0000-\u001f\u007f<>\u00ad\u061c\u180e\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\ufff9-\ufffb]/g;
    const cleanName = (s) => { let t = String(s == null ? '' : s); try { t = t.normalize('NFKC'); } catch (e) {} return t.replace(BAD, '').replace(/\s+/g, ' ').trim().slice(0, 24); };
    sanitizeName = function (s) { return cleanName(s); };
    const keyOf = (n) => cleanName(n).toLowerCase();
    function uniqueName(name, conn, s) {
        if (!gv('name')) return name; const taken = new Set(Object.keys(peerNames || {}).filter((p) => p !== conn.peer).map((p) => keyOf(peerNames[p])));
        try { if (currentUser) taken.add(keyOf(currentUser.username)); } catch (e) {}
        if (!taken.has(keyOf(name))) return name; const tag = (s.idFp ? s.idFp.replace(/ /g, '').slice(0, 4) : conn.peer.replace(/[^a-z0-9]/gi, '').slice(-4)); return (name.slice(0, 18) + ' #' + tag).slice(0, 24);
    }

    /* ── قوائم: حظر / تثبيت هويات / موافقات ── */
    const blocks = () => jget('hx11_block', []); const isBlocked = (n) => blocks().some((b) => keyOf(b) === keyOf(n));
    function block(n) { if (!n || isBlocked(n)) return; jset('hx11_block', blocks().concat([cleanName(n)]).slice(-100)); }
    function unblock(n) { jset('hx11_block', blocks().filter((b) => keyOf(b) !== keyOf(n))); }
    const pins = () => jget('hx11_pins', {}); const setPin = (n, fp) => { const p = pins(); p[keyOf(n)] = fp; const ks = Object.keys(p); if (ks.length > 200) delete p[ks[0]]; jset('hx11_pins', p); };
    const allowKey = (n, s) => keyOf(n) + '|' + (s.idFp || '-');
    const allowed = () => jget('hx11_allow', []);
    HD.guard = { level, gv, isBlocked, block, unblock, pins, LV, applyLevel, cleanName };

    /* ── نافذة سؤال (لا تُغلق نوافذ أخرى) ── */
    function ask(title, lines, actions, ms) {
        return new Promise((resolve) => {
            let box = g('hx11-askhost'); if (!box) { box = el('div', 'hx11-askhost'); box.id = 'hx11-askhost'; document.body.appendChild(box); }
            const card = el('div', 'hx11-ask'); card.setAttribute('role', 'alertdialog');
            const h = el('div', 'hx11-ask-h'); h.appendChild(icon('shield', 20)); h.appendChild(el('b', '', title)); card.appendChild(h);
            lines.forEach((l) => card.appendChild(el('p', l.cls || '', l.t)));
            const act = el('div', 'hx11-ask-a'); let done = false;
            const fin = (v) => { if (done) return; done = true; clearTimeout(to); card.remove(); resolve(v); };
            actions.forEach(([v, label, cls]) => { const b = el('button', 'hx11-ask-b ' + (cls || ''), label); b.type = 'button'; b.onclick = () => fin(v); act.appendChild(b); });
            card.appendChild(act); box.appendChild(card); const to = setTimeout(() => fin(actions[0][0]), ms || 45000);
            if (navigator.vibrate) navigator.vibrate(120);
        });
    }

    /* ── منع إغراق الأسئلة: رفض مؤقت + سؤال واحد لكل جهاز ── */
    const denied = new Map(), pendingAsk = new Set();
    const isDenied = (k) => { const t = denied.get(k); if (!t) return false; if (Date.now() > t) { denied.delete(k); return false; } return true; };
    const denyFor = (k, ms) => denied.set(k, Date.now() + (ms || 300000));
    /* ── قلب النظام: فحص كل اتصال قبل قبوله ── */
    HD.guardHello = async function (conn, s, clean, encOk) {
        const name = cleanName(clean.username); if (!name) return { ok: false, why: 'اتصال باسم غير صالح.' };
        if (isBlocked(name)) return { ok: false, why: 'محاولة اتصال من مستخدم محظور: ' + name };
        const dk = keyOf(name) + '|' + (s.idFp || conn.peer); if (isDenied(dk)) return { ok: false, why: '' }; if (pendingAsk.has(dk) || pendingAsk.size >= 5) return { ok: false, why: '' };
        clean.username = uniqueName(name, conn, s); const shown = clean.username;
        if (gv('requireId') && !s.idOk) return { ok: false, why: 'رُفض «' + shown + '»: بلا هوية موقَّعة (نسخة قديمة أو مزوَّرة).' };
        let state = 'none';
        if (s.idOk) {
            const pin = pins()[keyOf(name)];
            if (!pin) { setPin(name, s.idFp); state = 'new'; } else if (pin === s.idFp) state = 'trusted'; else state = 'changed';
        }
        s.idState = state;
        if (state === 'changed') {
            appendSafe('⚠️ تحذير: هوية «' + shown + '» تختلف عن المسجّلة سابقاً — قد يكون شخصاً ينتحل اسمه.');
            if (gv('blockChanged')) {
                pendingAsk.add(dk); const r = await ask('تغيّرت هوية «' + shown + '»', [{ t: 'جهاز هذا الاسم يختلف عن الجهاز الذي عرفته سابقاً. قد يكون استبدل جهازه، وقد يكون منتحلاً.' }, { t: 'رمز الهوية الجديد: ' + s.idFp, cls: 'hx11-ask-code' }, { t: 'تأكد منه عبر وسيلة أخرى قبل أن تثق.', cls: 'hx11-ask-note' }], [['deny', 'رفض', 'red'], ['block', 'حظر'], ['once', 'السماح هذه المرة'], ['trust', 'الوثوق بالجهاز الجديد', 'green']]); pendingAsk.delete(dk);
                if (r === 'block') { block(name); return { ok: false, why: 'تم حظر «' + shown + '».' }; }
                if (r === 'deny') { denyFor(dk); return { ok: false, why: 'رُفض «' + shown + '» بسبب تغيّر هويته.' }; }
                if (r === 'trust') { setPin(name, s.idFp); s.idState = 'trusted'; }
            }
        }
        const ap = gv('approve');
        if (ap && !(ap === 1 && allowed().includes(allowKey(name, s)))) {
            pendingAsk.add(dk); const r = await ask('طلب اتصال من «' + shown + '»', [{ t: s.idState === 'trusted' ? 'هوية موثوقة سابقاً.' : s.idState === 'new' ? 'هوية جديدة لم تتعامل معها من قبل.' : 'بدون هوية موقَّعة.' }, s.idFp ? { t: 'رمز الهوية: ' + s.idFp, cls: 'hx11-ask-code' } : { t: '' }], [['deny', 'رفض', 'red'], ['block', 'حظر'], ['ok', 'قبول مرة'], ...(ap === 1 ? [['always', 'قبول دائم', 'green']] : [])]); pendingAsk.delete(dk);
            if (r === 'block') { block(name); return { ok: false, why: 'تم حظر «' + shown + '».' }; }
            if (r === 'deny') { denyFor(dk); return { ok: false, why: 'رفضت اتصال «' + shown + '».' }; }
            if (r === 'always') jset('hx11_allow', allowed().concat([allowKey(name, s)]).slice(-200));
        }
        return { ok: true };
    };
    function appendSafe(t) { try { appendSystemMessage(t); } catch (e) {} }

    /* ── تصفية الحزم الحساسة ── */
    HD.guardFilter = function (pk, conn, s) {
        const nm = (typeof peerNames !== 'undefined' && peerNames[conn.peer]) || ''; if (nm && isBlocked(nm)) { try { conn.close(); } catch (e) {} return false; }
        if (gv('attVerified') && !s.verified) {
            if (pk.type === 'att_chunk') return false;
            if (pk.type === 'chat' && pk.payload && (parseInt(pk.payload.attachmentTotal) || 0) > 0) { appendSafe('🛡️ حُجب مرفق من «' + nm + '» لأنك لم تتحقق من هويته (مستوى أقصى).'); return false; }
        }
        return true;
    };
    HD.guard.allowCall = (pid) => { if (!gv('callVerified')) return true; const c = activeConnections[pid]; return !!(c && c.__hd && c.__hd.verified); };

    /* ── فاحص الروابط ── */
    const DEFAULT_TRUST = ['horror2024death.workers.dev', 'mohamedhamdyr.github.io'];
    const SHORT = ['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'cutt.ly', 'is.gd', 'rb.gy', 'shorturl.at', 'ow.ly', 'tiny.cc', 'rebrand.ly', 'lnkd.in'];
    const BADTLD = ['zip', 'mov', 'tk', 'ml', 'ga', 'cf', 'gq', 'top', 'click', 'country', 'work'];
    function riskOf(u) {
        const f = [], h = u.hostname.toLowerCase(); let sev = 0;
        if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h) || h.includes(':')) { f.push('عنوان IP مباشر بدل اسم موقع'); sev = 2; }
        if (h.includes('xn--')) { f.push('اسم موقع مُرمَّز (Punycode) قد يقلّد موقعاً معروفاً'); sev = 2; }
        if (/[^\x00-\x7f]/.test(u.hostname)) { f.push('أحرف غير لاتينية في الاسم (خدعة تشابه الحروف)'); sev = 2; }
        if (u.username || u.password) { f.push('يحتوي بيانات دخول مخفية قبل اسم الموقع'); sev = 2; }
        if (u.protocol === 'http:') { f.push('غير مشفّر (http)'); sev = Math.max(sev, 1); }
        if (SHORT.includes(h)) { f.push('رابط مختصر يخفي الوجهة الحقيقية'); sev = Math.max(sev, 1); }
        const tld = h.split('.').pop(); if (BADTLD.includes(tld)) { f.push('امتداد «.' + tld + '» يكثر في الاحتيال'); sev = Math.max(sev, tld === 'zip' || tld === 'mov' ? 2 : 1); }
        if (h.split('.').length > 4) { f.push('نطاقات فرعية كثيرة (طريقة شائعة للتمويه)'); sev = Math.max(sev, 1); }
        if (u.href.length > 220) { f.push('رابط طويل جداً'); sev = Math.max(sev, 1); }
        return { f, sev };
    }
    const trustedDoms = () => DEFAULT_TRUST.concat(jget('hx11_trust_dom', []));
    const isTrusted = (h) => trustedDoms().some((d) => h === d || h.endsWith('.' + d));
    HD.guard.riskOf = riskOf;
    function linkSheet(u) {
        const r = riskOf(u);
        sheet('فحص الرابط قبل الفتح', (b) => {
            const st = el('div', 'hx11-status ' + (r.sev >= 2 ? 'bad' : r.sev === 1 ? 'warn' : 'ok')); st.appendChild(icon(r.sev ? 'panic' : 'shield', 20)); const t = el('div');
            t.appendChild(el('b', '', r.sev >= 2 ? 'رابط مشبوه — لا يُنصح بفتحه' : r.sev === 1 ? 'انتبه قبل الفتح' : 'لم تُكتشف علامات خطر واضحة')); t.appendChild(el('small', '', 'لا يمكن لأي فاحص ضمان أمان موقع بالكامل.')); st.appendChild(t); b.appendChild(st);
            b.appendChild(el('div', 'hx11-dom', u.hostname)); b.appendChild(el('code', 'hx11-fp hx11-url', u.href.slice(0, 400)));
            if (r.f.length) { section(b, 'علامات الخطر'); r.f.forEach((x) => b.appendChild(el('div', 'hx11-flag-li', '• ' + x))); }
            button(b, 'فتح في تبويب جديد', () => { const w = g('hx-sheet'); if (w) w.remove(); window.open(u.href, '_blank', 'noopener,noreferrer'); }, 'link', r.sev >= 2 ? 'danger' : '');
            button(b, 'نسخ الرابط', () => { try { navigator.clipboard.writeText(u.href); note('تم النسخ'); } catch (e) { note('تعذّر النسخ'); } }, 'template');
            if (r.sev === 0) button(b, 'الوثوق بهذا الموقع دائماً', () => { jset('hx11_trust_dom', jget('hx11_trust_dom', []).concat([u.hostname]).slice(-100)); const w = g('hx-sheet'); if (w) w.remove(); window.open(u.href, '_blank', 'noopener,noreferrer'); }, 'check');
        });
    }
    document.addEventListener('click', (e) => {
        if (!gv('link')) return; const a = e.target && e.target.closest && e.target.closest('a[href]'); if (!a) return;
        const href = a.getAttribute('href') || ''; if (!a.closest('#chat-box, #private-chats-list, .msg-card, [id^="private"], .hx11-pcard')) return;
        if (/^\s*(javascript|vbscript):/i.test(href)) { e.preventDefault(); e.stopPropagation(); note('تم حجب رابط خطير'); return; }
        if (/^(blob:|data:|#|mailto:|tel:)/i.test(href) || a.hasAttribute('download')) return;
        let u; try { u = new URL(a.href, location.href); } catch (x) { return; } if (!/^https?:$/.test(u.protocol)) { e.preventDefault(); e.stopPropagation(); note('تم حجب رابط غير مدعوم'); return; }
        if (u.origin === location.origin || isTrusted(u.hostname.toLowerCase())) return;
        e.preventDefault(); e.stopPropagation(); linkSheet(u);
    }, true);

    /* ── حماية الملفات المرفقة ── */
    const RISKY = new Set('exe msi bat cmd com scr pif vbs vbe js jse jar apk ipa ps1 psm1 sh hta lnk dll reg wsf cpl msc gadget iso dmg appimage deb rpm svg html htm xhtml xml swf'.split(' '));
    const extOf = (n) => { const m = /\.([a-z0-9]{1,10})\s*$/i.exec(String(n || '')); return m ? m[1].toLowerCase() : ''; };
    HD.guard.extOf = extOf; HD.guard.RISKY = RISKY;
    if (typeof buildAttachmentElement === 'function') {
        const _b = buildAttachmentElement;
        buildAttachmentElement = function (type, data, name) {
            if (gv('att')) {
                const ex = extOf(name), dbl = /\.[a-z0-9]{1,5}\.(exe|bat|cmd|scr|js|vbs|apk|msi)\s*$/i.test(String(name || ''));
                if (RISKY.has(ex) || dbl) { const s = el('span', 'hx11-blocked'); s.appendChild(icon('shield', 14)); s.appendChild(el('span', '', ' حُجب ملف خطير (.' + ex + ') لحمايتك')); return s; }
                const kind = String(data || '').slice(5, String(data || '').indexOf('/'));
                if (kind !== 'image' && kind !== 'audio' && kind !== 'video') { const el0 = _b(type, data, name); if (el0 && el0.tagName === 'A') { el0.addEventListener('click', (e) => { if (!confirm('ملف مرسَل من متصل: ' + (name || 'ملف') + '\nلا تفتحه إلا إذا كنت تثق بمرسله. متابعة التحميل؟')) { e.preventDefault(); } }, true); } return el0; }
            }
            return _b(type, data, name);
        };
    }

    /* ── رسائل ذاتية الحذف ── */
    let sweepIv = null;
    function stamp(c) { if (c.classList && c.classList.contains('msg-card') && !c.dataset.hx11t) c.dataset.hx11t = String(Date.now()); }
    function dbDel(id) { try { if (typeof db !== 'undefined' && db) { const tx = db.transaction(['messages', 'attachments'], 'readwrite'); tx.objectStore('messages').delete(id); tx.objectStore('attachments').delete(id); } } catch (e) {} }
    function sweep() {
        const mins = gv('disappear'); if (!mins) return; const lim = Date.now() - mins * 60000, box = g('chat-box'); if (!box) return;
        box.querySelectorAll('.msg-card').forEach((c) => { stamp(c); if (+c.dataset.hx11t < lim) { const id = c.id && c.id.startsWith('msg-') ? c.id.slice(4) : null; c.remove(); if (id) { dbDel(isNaN(+id) ? id : +id); dbDel(id); } } });
    }
    function armDisappear() { clearInterval(sweepIv); sweepIv = null; if (gv('disappear')) { sweepIv = setInterval(sweep, 10000); sweep(); } }
    HD.guard.sweep = sweep;

    /* ── خصوصية الشبكة (إخفاء IP عبر TURN) ── */
    function applyNet() {
        const t = jget('hx11_turn', null); const extra = [];
        if (t && /^(turns?|stuns?):/i.test(t.url || '')) { const o = { urls: t.url }; if (t.user) o.username = t.user; if (t.cred) o.credential = t.cred; extra.push(o); }
        window.HDC_ICE_EXTRA = extra; window.HDC_ICE_POLICY = (ls.get('hx11_relay', '0') === '1' && extra.length) ? 'relay' : 'all';
    }
    applyNet();

    /* ── درجة الحماية ── */
    function score() {
        const sum = HD.peersSummary(), items = []; let pts = 0;
        const add = (ok, w, label, tip) => { items.push({ ok, w, label, tip }); if (ok) pts += w; };
        add(!!HD.e2e, 25, 'تشفير طرفي للرسائل', 'يلزم HTTPS ومتصفح حديث.');
        add(sum.total === 0 || sum.enc === sum.total, 10, 'كل الاتصالات الحالية مشفّرة', 'افصل أي اتصال غير مشفّر.');
        add(!!(HD.identity && HD.idPersisted), 10, 'هوية جهاز دائمة موقَّعة', 'تعذّر حفظ الهوية: تأكد أن التخزين غير محظور.');
        add(ls.get('hx11_strict', '1') === '1', 10, 'وضع منع التخفيض الصارم', 'فعّله من مستويات الحماية.');
        add(!!gv('name'), 5, 'حماية الأسماء من الانتحال', '');
        add(!!gv('link'), 5, 'فاحص الروابط', '');
        add(!!gv('att'), 5, 'حجب الملفات الخطرة', '');
        add(gv('approve') > 0, 8, 'موافقة على الغرباء', 'اختر مستوى «عالٍ» أو «أقصى».');
        add(gv('requireId') > 0, 7, 'اشتراط هوية موقَّعة', 'يمنع النسخ القديمة والمزوَّرة.');
        let lock = false; try { const s = getAppSettings(); lock = !!(s.lockEnabled && (s.lockHash || s.lockPassword)); } catch (e) {} add(lock, 8, 'قفل التطبيق بكلمة سر', 'فعّله من الإعدادات الجانبية.');
        add(ls.get('hx11_blur', '0') === '1', 4, 'تمويه عند مغادرة النافذة', '');
        add((+ls.get('hx11_idle', '0')) > 0, 3, 'قفل تلقائي عند الخمول', '');
        return { pts: Math.min(100, pts), items };
    }
    HD.guard.score = score;

    /* ── مركز الأمان ── */
    const STATE = { trusted: ['موثوق', 'ok'], new: ['هوية جديدة', 'warn'], changed: ['هوية تغيّرت!', 'bad'], none: ['بلا هوية موقَّعة', 'bad'] };
    function openSecurity() {
        sheet('مركز الحماية', (b) => {
            const sc = score(), ring = el('div', 'hx11-score'); const col = sc.pts >= 80 ? '#22c55e' : sc.pts >= 55 ? '#eab308' : '#ef4444'; ring.style.setProperty('--p', sc.pts); ring.style.setProperty('--c', col);
            const n = el('div', 'hx11-score-n'); n.appendChild(el('b', '', String(sc.pts))); n.appendChild(el('small', '', 'من 100')); ring.appendChild(n);
            const head = el('div', 'hx11-score-head'); head.appendChild(ring); const tx = el('div', 'hx11-score-tx'); tx.appendChild(el('b', '', sc.pts >= 80 ? 'حمايتك قوية' : sc.pts >= 55 ? 'حمايتك جيدة وتحتاج لمسات' : 'حمايتك تحتاج تعزيزاً'));
            tx.appendChild(el('small', '', HD.e2e ? 'ECDH + AES-256-GCM + توقيع ECDSA لكل اتصال.' : 'التشفير الطرفي غير متاح هنا.')); head.appendChild(tx); b.appendChild(head);
            const todo = sc.items.filter((i) => !i.ok && i.tip); if (todo.length) { const tb = el('div', 'hx11-tipbox'); todo.slice(0, 3).forEach((i) => tb.appendChild(el('p', '', '• ' + i.label + ': ' + i.tip))); b.appendChild(tb); }

            section(b, 'مستوى الحماية');
            const lv = el('div', 'hx11-levels'); Object.entries(LV).forEach(([id, c]) => { const x = el('button', 'hx11-lv' + (level() === id ? ' on' : '')); x.type = 'button'; x.appendChild(el('b', '', c.n)); x.appendChild(el('small', '', c.d)); x.onclick = () => { applyLevel(id); const w = g('hx-sheet'); if (w) w.remove(); openSecurity(); note('تم تطبيق مستوى «' + c.n + '»'); }; lv.appendChild(x); }); b.appendChild(lv);
            if (level() === 'custom') b.appendChild(el('p', 'hx-muted', 'مستواك مخصّص حالياً (عدّلت خياراً بنفسك).'));

            section(b, 'الاتصالات الحالية');
            const sum = HD.peersSummary(); if (!sum.ids.length) b.appendChild(el('p', 'hx-muted', 'لا يوجد متصلون الآن.'));
            sum.ids.forEach((pid) => {
                const c = activeConnections[pid], s = c.__hd || {}, nm = (peerNames && peerNames[pid]) || 'مجهول', card = el('div', 'hx11-peer'); const top = el('div', 'hx11-peer-top');
                top.appendChild(icon(s.mode === 'enc' ? 'lock' : 'panic', 16)); top.appendChild(el('b', '', nm)); const st = STATE[s.idState] || STATE.none; top.appendChild(el('span', 'hx11-badge ' + st[1], st[0])); card.appendChild(top);
                if (s.idFp) { card.appendChild(el('small', 'hx-muted', 'رمز هويته')); card.appendChild(el('code', 'hx11-fp', s.idFp)); }
                if (s.fp) { card.appendChild(el('small', 'hx-muted', 'رمز الجلسة (قارنه صوتياً)')); card.appendChild(el('code', 'hx11-fp', s.fp)); }
                const acts = el('div', 'hx11-inline'); const vb = el('button', 'hx11-chipbtn' + (s.verified ? ' on' : ''), s.verified ? 'تم التحقق ✓' : 'تحقّقنا من الرمز'); vb.type = 'button'; vb.onclick = () => { s.verified = !s.verified; vb.classList.toggle('on', s.verified); vb.textContent = s.verified ? 'تم التحقق ✓' : 'تحقّقنا من الرمز'; };
                const bb = el('button', 'hx11-chipbtn red', 'حظر'); bb.type = 'button'; bb.onclick = () => { block(nm); try { c.close(); } catch (e) {} note('تم حظر ' + nm); const w = g('hx-sheet'); if (w) w.remove(); openSecurity(); };
                acts.appendChild(vb); acts.appendChild(bb); card.appendChild(acts); b.appendChild(card);
            });

            section(b, 'طبقات الحماية');
            const T = (label, key, hint) => row(b, label, toggle(!!gv(key), (v) => { gset(key, v ? 1 : 0); if (key === 'blur') { ls.set('hx11_blur', v ? '1' : '0'); document.body.classList.toggle('hx11-privacy', v); } }), hint);
            T('اشتراط هوية موقَّعة', 'requireId', 'يرفض النسخ القديمة وأي جهاز بلا توقيع.'); T('منع تغيّر الهوية صامتاً', 'blockChanged', 'يسألك قبل قبول جهاز جديد بنفس الاسم.');
            row(b, 'الموافقة على المتصلين', select([['0', 'بدون'], ['1', 'مرة واحدة وأتذكّر'], ['2', 'في كل جلسة']], String(gv('approve')), (v) => gset('approve', +v)), 'يسألك قبل دخول أي شخص.');
            T('حماية الأسماء من الانتحال', 'name', 'يزيل الأحرف المخفية ويمنع تكرار الاسم.'); T('فاحص الروابط', 'link', 'يعرض مخاطر أي رابط قبل فتحه.'); T('حجب الملفات الخطرة', 'att', 'exe وapk وهكذا لا تُعرض ولا تُحمَّل.');
            T('رفض ملفات ومكالمات غير الموثَّقين', 'attVerified', 'لا تصلك مرفقات إلا ممن ضغطت «تحقّقنا» له.'); T('تمويه عند مغادرة النافذة', 'blur', '');
            row(b, 'قفل تلقائي عند الخمول', select([['0', 'معطّل'], ['1', 'دقيقة'], ['5', '5 دقائق'], ['15', '15 دقيقة']], ls.get('hx11_idle', '0'), (v) => { ls.set('hx11_idle', v); gset('idle', +v); }), 'يعمل مع قفل التطبيق.');
            row(b, 'رسائل ذاتية الحذف', select([['0', 'معطّلة'], ['5', 'بعد 5 دقائق'], ['15', 'بعد 15 دقيقة'], ['60', 'بعد ساعة'], ['1440', 'بعد يوم']], String(gv('disappear')), (v) => { gset('disappear', +v); armDisappear(); }), 'تُمحى من شاشتك وجهازك فقط.');

            section(b, 'هويتك أنت');
            if (HD.identity) { b.appendChild(el('small', 'hx-muted', 'رمز هوية جهازك — اطلب من أصدقائك مقارنته')); b.appendChild(el('code', 'hx11-fp', HD.identity.fp)); b.appendChild(el('small', 'hx-muted', HD.idPersisted ? 'محفوظة على هذا الجهاز ولا يمكن استخراجها.' : 'غير محفوظة (تخزين المتصفح محظور) — ستتغيّر كل جلسة.')); }
            button(b, 'تصفير هويتي', async () => { if (!confirm('سيراك أصدقاؤك بهوية جديدة وقد يظهر لهم تحذير تغيّر الهوية. متابعة؟')) return; await HD.resetIdentity(); const w = g('hx-sheet'); if (w) w.remove(); openSecurity(); note('تم إنشاء هوية جديدة'); }, 'flip');

            section(b, 'هويات موثوقة (' + Object.keys(pins()).length + ')');
            Object.entries(pins()).slice(-8).forEach(([k, fp]) => { const r = el('div', 'hx11-row'); const l = el('div', 'hx11-lbl'); l.appendChild(el('span', '', k)); l.appendChild(el('small', 'hx-ltr', fp)); r.appendChild(l); r.appendChild(iconBtn('trash', 'نسيان هذه الهوية', () => { const p = pins(); delete p[k]; jset('hx11_pins', p); r.remove(); }, 'sm')); b.appendChild(r); });

            section(b, 'المحظورون (' + blocks().length + ')');
            if (!blocks().length) b.appendChild(el('p', 'hx-muted', 'لا أحد محظور.'));
            blocks().forEach((n) => { const r = el('div', 'hx11-row'); r.appendChild(el('span', '', n)); const u = el('button', 'hx11-chipbtn', 'إلغاء الحظر'); u.type = 'button'; u.onclick = () => { unblock(n); r.remove(); }; r.appendChild(u); b.appendChild(r); });

            section(b, 'خصوصية الشبكة (إخفاء عنوان IP)');
            b.appendChild(el('p', 'hx-muted', 'الاتصال المباشر يكشف عنوان IP لمن تتحدث معه. لإخفائه مرّر الاتصال عبر خادم TURN تملكه أو تثق به (مثل خدمة TURN في Cloudflare أو coturn). الإعداد يسري بعد إعادة تحميل الصفحة.'));
            const t = jget('hx11_turn', {}); const f = (ph, k, type) => { const i = el('input', 'hx-input'); i.type = type || 'text'; i.placeholder = ph; i.value = t[k] || ''; i.autocomplete = 'off'; i.dir = 'ltr'; i.oninput = () => { t[k] = i.value.trim(); jset('hx11_turn', t); applyNet(); }; b.appendChild(i); };
            f('turn:turn.example.com:3478', 'url'); f('اسم المستخدم', 'user'); f('كلمة السر', 'cred', 'password');
            row(b, 'تمرير كل الاتصالات عبر TURN فقط', toggle(ls.get('hx11_relay', '0') === '1', (v) => { ls.set('hx11_relay', v ? '1' : '0'); applyNet(); note(v ? 'سيسري بعد إعادة التحميل — تأكد من صحة بيانات TURN وإلا لن تتصل' : 'تم الإيقاف'); }), 'بدون TURN صالح لن ينجح أي اتصال.');
            b.appendChild(el('p', 'hx-muted', 'ما لا يحميه أي تشفير: لقطة الشاشة، أو شخص تثق به خطأً، أو جهاز مصاب.'));
            button(b, 'زر الطوارئ: مسح الرسائل وقطع الاتصالات', () => document.dispatchEvent(new KeyboardEvent('keydown', { key: 'X', ctrlKey: true, shiftKey: true })), 'panic', 'danger');
        }, { wide: true });
    }
    HD.openSecurity = openSecurity;

    function init() {
        const box = g('chat-box'); if (box) new MutationObserver((ms) => ms.forEach((r) => r.addedNodes.forEach(stamp))).observe(box, { childList: true });
        armDisappear(); if (ls.get('hx11_g_level', '') === '') { ls.set('hx11_g_level', 'std'); }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
